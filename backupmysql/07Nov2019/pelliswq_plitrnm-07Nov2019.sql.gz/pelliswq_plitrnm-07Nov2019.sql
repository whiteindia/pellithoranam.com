-- MySQL dump 10.13  Distrib 5.6.41-84.1, for Linux (x86_64)
--
-- Host: localhost    Database: pelliswq_plitrnm
-- ------------------------------------------------------
-- Server version	5.6.41-84.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `active_members`
--

DROP TABLE IF EXISTS `active_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `active_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `active_members`
--

LOCK TABLES `active_members` WRITE;
/*!40000 ALTER TABLE `active_members` DISABLE KEYS */;
INSERT INTO `active_members` VALUES (47,16912,'2019-06-19 15:28:10'),(48,46690,'2019-06-19 17:27:55'),(49,10249,'2019-08-21 16:00:40'),(50,42566,'2019-06-24 14:21:57'),(51,69285,'2019-11-07 19:18:24'),(52,16380,'2019-08-28 21:49:18'),(53,16791,'2019-08-23 14:50:51'),(54,29516,'2019-08-09 11:15:34'),(55,28380,'2019-07-20 17:06:28'),(56,29653,'2019-07-29 11:55:50'),(57,13629,'2019-07-31 13:51:33'),(58,11125,'2019-08-20 10:25:01'),(59,10560,'2019-08-07 18:12:03'),(60,15809,'2019-08-13 15:37:09'),(61,15258,'2019-08-22 13:36:28'),(62,22525,'2019-08-28 13:51:24'),(63,13950,'2019-09-06 21:16:13'),(64,11946,'2019-08-29 14:46:32'),(65,24032,'2019-08-29 15:15:08'),(66,16636,'2019-09-25 18:40:47');
/*!40000 ALTER TABLE `active_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_tokens`
--

DROP TABLE IF EXISTS `app_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `app_tokens` (
  `token_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `token_unique` varchar(100) NOT NULL,
  `token_user` int(30) unsigned NOT NULL,
  `token_active` int(11) unsigned NOT NULL,
  PRIMARY KEY (`token_id`)
) ENGINE=InnoDB AUTO_INCREMENT=425 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_tokens`
--

LOCK TABLES `app_tokens` WRITE;
/*!40000 ALTER TABLE `app_tokens` DISABLE KEYS */;
INSERT INTO `app_tokens` VALUES (1,'34f5437275eb5bca6ec82cf683f81681',6539442,1),(2,'d9828d5fff44cad0049e3660585016f1',6539442,1),(3,'3a6ec2e5c17005e1407d8b36f9f328b8',6539442,1),(4,'591f19a2376c1e0c44e8e192c1d520d9',6539442,1),(5,'b9762c8a073648f3f8014ae050c0ee88',6539442,1),(6,'3613c786607d91f4971b43aa4aa39aab',6539442,1),(7,'0a6662b80b01693bf9fde7a6c65ddd4e',6539442,1),(8,'9b0c5b8e7f3b5ba50a9d47f5a4a3d77c',6539442,1),(9,'d457b5fc0607d78e68748a792812f7a7',6539442,1),(10,'4e01d18b02582cd646f7a0401fd0c09a',6539442,1),(17,'fc1fd82bc992aae407dc88c12aa868b9',3593565,1),(18,'40ce61c9c1f2ded43ff7f05352bbd1e7',1000228,1),(19,'df4b43cefdf87a3519add287147966f5',9229214,1),(20,'12b31001c47d7b2cc6250e81c6d3b651',3846529,1),(21,'8339764f0d460a7305bdd8600c3fc741',1000228,1),(22,'b8fafbe493323a2b89422db4f6cef9f9',7577796,1),(23,'76e23d327de338ac601c340705db1068',1000228,1),(24,'f7b8f6fa5d4d5418848ea574d117e24f',7577796,1),(25,'75845b0d53ee749b2097b0fd9d3da9e8',7577796,1),(26,'fd245f1f8ec0e5cc9cdc8d8a9bf99853',7577796,1),(27,'2b60ae04f6271447e5fe1fc62a8436d2',7577796,1),(28,'be123a501e0578c4b1f3b2a96b7b5b10',7577796,1),(29,'d1d9b81e7b4e721b469e6ba6c661cd02',7577796,1),(30,'fd96343363e5687e72863fcb66d85b5d',7577796,1),(31,'14c4e4bff537512dccb686da91fc4cae',7577796,1),(32,'ff5ec4af6e815e072562654b2ca5630e',7577796,1),(33,'ae112a407ccabfe8e5983591c233b477',8726489,1),(34,'3b2c715a7b57d9f64469f5bf971c29e9',8518006,1),(35,'6e1c225cb98063a753e8665dbb3c1539',8348562,1),(36,'5578ee2f6261bfefd1d6a443dd76d4a3',9151541,1),(37,'44c39d6b48036ff9e085adcb44c7da65',4120165,1),(38,'c99c759a735594739543b272126728f8',8943196,1),(39,'53ea178f4a8c33007edc1ffa5272eecb',2267403,1),(40,'857a3f2daaaa0216dc97bd16a5666127',9840726,1),(41,'454f209766fd85d112d9077689328284',6876814,1),(42,'ac6c164c9c389bbc522a9c01236cb6c3',8859573,1),(43,'974a1b67b017a3547368223e05395681',7577796,1),(44,'c92a6487dad2d30c16d006312bb67d39',8859573,1),(45,'39be2e1ef97a94cf32c4230b24694b0c',4921067,1),(46,'6277db08cb012e7ddcddb237f047f802',8859573,1),(47,'1d3cf402dd0d214d8b84bec0154992ef',1923511,1),(48,'1acae08ad746fbe9f983b0b20eabf684',6539442,1),(49,'53f85f8d298824129ced975dbf526115',8624954,1),(50,'6207ef1005dbc92d2b5e2df30cdf5349',7577796,1),(51,'e5cf86fabecfe368303821aad01f643e',7577796,1),(52,'4979def6842c2727cce0a6834b5f0653',8624954,1),(53,'1bdb3048718324d2095f651e14935def',8624954,1),(54,'3ceb9e3f4a2ece531a8cb7ffb107b224',8624954,1),(55,'aeee9968e1fdd1488d23a45273d59e83',7776784,1),(56,'366804f9edf73800e8a110cbccb0aaef',7572943,1),(57,'af1b17b1729664d62f20845dead72650',7136853,1),(58,'357ff60b826b7fa031a21370aa248c16',3663911,1),(59,'272e80936d2dfa54d0cf62bc5637e999',6427253,1),(60,'9531ce5b220f3b1f69cabdba20f4e8f1',5400379,1),(61,'2ae6c13c913ca99ec9114c267b037778',8702356,1),(62,'b30265fab6f21f427d65b214cb91bbc0',4959795,1),(63,'d0c901942095b680f53423b500b90ea2',1660450,1),(64,'8a1a266b028b7e06c07edd5a5afcb8d3',1990850,1),(65,'621825c0cd02bf3d68ff933235580065',5703735,1),(66,'19f3c97b610004fe6ac00927b2718797',7577796,1),(67,'c4b8439069a210b5a0f687916374cb58',8199372,1),(68,'80547765f74581ad50229429f5277d7f',3283770,1),(69,'48d5d8bd45160283f82e8ec2d0b780c1',7848443,1),(70,'89efaf9eb249453c2e6da502c8d621fc',2834671,1),(71,'d71e8e7b08855c84c67f6128c061fd48',4053649,1),(72,'be532b7a6bbdd985f39901255d7f5e9f',6954190,1),(73,'517b76ae79bad9c9ccffadd45fa4ed64',1345081,1),(74,'dd96ba42cb41a058a66810efdb086fd8',7754611,1),(75,'4decd8ef2c35c84ef1a871aa93d3e570',4033110,1),(76,'3626a39f0d52baa4d700e804de5a534b',6057810,1),(77,'86dbea180deadfeb1e5a2bcdfa91db4e',7466668,1),(78,'1c01260ed259d3e318b93f88ae3ef212',9342283,1),(79,'49d7c456ba5bfd904423498c11632b62',3438393,1),(80,'a5f2a1c0da08bf89289017c83314ccf3',1384518,1),(81,'c1fe97fb68def79654c7e075fea3a586',1815459,1),(82,'f3ffefb90784a76ef3f5a566b600c7a3',7974577,1),(83,'48967fdb332cb7ca2150dbc10ef5a7e5',9777935,1),(84,'709bff6cbc4373c530cba5e4653e99bf',3507744,1),(85,'27802a40d98962457f35779c39485160',2067377,1),(86,'74003a90ae462bac1f921707de04111e',2923417,1),(87,'b740946b35ef4826bda032f0bacb2f0e',8623008,1),(88,'f77dd8b9c3dd0c45ed140cc7c7d70c08',5311154,1),(89,'b08e7eaa3ca03a0c65baceac5073bd70',5311154,1),(90,'31937ad8180caa7719706b9ad1c77d63',5311154,1),(91,'ded6c8f3431773375377e029c53cf8bd',5311154,1),(92,'77b1027027909949122a12a4c9f5c983',5311154,1),(93,'b48f10904d090ecda35933d9f312bea2',5311154,1),(94,'1e6148359ce0be71590560b73709a6f4',5311154,1),(95,'c573fd59fe0ea41aa8def6ae43f1b4df',5311154,1),(96,'9d99cdbdffe320483cdbbbd9fa5c83b7',5311154,1),(97,'dac67a04635d78eba0d8a749f6644dec',5311154,1),(98,'93b8bed6d0e70530371e34bffafbdf90',5311154,1),(99,'bea13f8d3327c957dd610649f058aca8',5311154,1),(100,'518ad7020cd3a6cb0346195371e7982d',5311154,1),(101,'cd55b69ef4d0ba8f9a06624ac73bf540',5311154,1),(102,'cb3d630f473b5f06039e593afcb25d8d',5311154,1),(103,'b955d97d366fe258a05c644e16632c64',5311154,1),(104,'a8b74f094cb742315491105d00d88525',5311154,1),(105,'8471ca5e896c6e0be30ffbcfaf8eb5fc',5311154,1),(106,'0be3002843ef386b3e6e38fcfce48906',5311154,1),(107,'28cdb52a7f3399100e8aa8fd911832d2',5311154,1),(108,'5172d2db8ec45e66fd64aa8cebb7473b',5311154,1),(109,'e60aadfddffbfe6ffe5a079e0e4ba15b',4629392,1),(110,'eb84476d2df164d867757c3e6b666b0b',4629392,1),(111,'8787a4551bcc1b90319da3dfee5a42f9',4629392,1),(112,'ffb0323a6e499aedff898172d223284f',4629392,1),(113,'e28c1ac986057ddf9d5698b39bdaee58',4629392,1),(114,'6e7237fd365b5754967e96bcb374dbc3',4629392,1),(115,'1448ed8a7e65a80f04c9c1372df9ae51',4629392,1),(116,'717fe5c68db6f7c330e91f984c285dc7',4629392,1),(117,'b5bd3f1e57f94b7704f21ab1e40c4313',4629392,1),(118,'e65a1e3026184d57d3ad46116ecee3c5',4629392,1),(119,'7ab715e22733f34eb5a93bfd3c4ba311',4629392,1),(120,'d6c493ab802eb395907738433f340c85',4629392,1),(121,'ac64ebf597e763cca528f9117e1d9daf',4629392,1),(122,'6cda434d5887ec4f85b0f7b0e2d3b6ca',4629392,1),(123,'3ea2d6e98261866c433fb10f85f04109',9564319,1),(124,'f04eb914245e7c817da868059fe79231',4629392,1),(125,'26a9588b900b50bf0973ee76115b9bd3',4629392,1),(126,'e3ea6032fd4be64e348313bf9579cc41',9247732,1),(127,'ac72505c68c7e16331f2ebc101216fcd',4629392,1),(128,'2455ceaba75fd613ee036be893aa505b',6509859,1),(129,'b1cb61fa6501a0d5698b428edbf2de66',6458979,1),(130,'213944744e5d85e016eb51c338172e0a',6698394,1),(131,'d0def3ce92e3ba61ecbea296da51fd90',5664416,1),(132,'1ff0c2a6bdae2cec5f04ca7ef93b8398',2434679,1),(133,'4985b48df796261f0c31fd747428b2f3',7342216,1),(134,'453c2cdc58f1ca5eb92bdb0ac54f63c6',4629392,1),(135,'6d393dca4b713e7e767a391e60b2527b',3467505,1),(136,'b953fbd6c0f005e96de0bb9c49c0e0db',4629392,1),(137,'fb652b16d5494e3f15d39fb170643576',8489922,1),(138,'8c97d5e6d7c07067ad3d95396dff2320',8624954,1),(139,'6d69719152c8ba0b90d0658cae0a196c',4629392,1),(140,'23a415c12d32bbe13b5735d3e85ab381',4801982,1),(141,'b8286b3ac481eb9252add81ccabcc90f',4629392,1),(142,'b0936722313fff20ab2771b35354d8b4',4629392,1),(143,'96ab51d192f48bc68f4358c94d5ccd5d',4629392,1),(144,'c3e58477bc020049e54b9925e7f1ac11',4629392,1),(145,'2217c658563bad27dc90251166b5b68b',4629392,1),(146,'003cd9ad93eb8ba94ab115912f28bd92',4629392,1),(147,'1655e538c300c86180cc605c8e6ad09f',2853970,1),(148,'c1a5e06f23943fd891679ee72beeafda',4629392,1),(149,'f6a4a875bd869a8850ed01dbf7ef2030',4629392,1),(150,'468be54ef4625c616be087155577fd65',4629392,1),(151,'c01a58abafd157f835b607e3f1c0a29a',4629392,1),(152,'6f692e90ccfed1df935a0a4015356e83',4629392,1),(153,'4b054ca65aba4ac7bb4994254b8e1a08',4629392,1),(154,'9724b2af78b12338e718ca99bc37f59f',4629392,1),(155,'d19e74d776a4830bbc110403af0d29b9',9264210,1),(156,'b127933acf3f92ac202be57fb1bed8ba',1035131,1),(157,'87e7cb5fdb4e4d7d3c813ffb3660909c',7256591,1),(158,'7ec2ba9cb772a38ac801972ff0684d8d',2390478,1),(159,'682b38df9994318f20c8a4970a6a207a',1347299,1),(160,'f17522d6c0a693c5e01a183ddd1527dd',6917346,1),(161,'2b170ace1f0b084b79c39aa6b4d3de87',4629392,1),(162,'d3c6d2919dba1fc9f3d0079b50ff44da',4629392,1),(163,'424f96046c7a8e0a9c78cfaec2a95c84',4629392,1),(164,'81eb8f0c62e5323af2f7478ea382e0c4',1035131,1),(165,'be6ef7ba36f7b3c6a31ca5c80688b791',4629392,1),(166,'78304903e989878ec5981e278d592fa4',1035131,1),(167,'aca02a28e680f2cbf906f0ada07c68b0',6265502,1),(168,'d92e1190306549baa1fca2ae1b30a46c',6265502,1),(169,'7b6ff21976a888ca88360f7237d38564',6265502,1),(170,'292a231f587619564faf6136e0acff88',8840620,1),(171,'fd2d1274866d2b8589a6f95e8e092f0c',8840620,1),(172,'9d9f8b0a8c8639d408148e7cf1d4936d',8840620,1),(173,'44716f976429b8abd01529e9375a1b9d',8840620,1),(174,'a155959e3ad1942592f3fdb5b6c83eaf',8840620,1),(175,'6c9bb5c71b142e30d26451e64a831691',8840620,1),(176,'29656c894393ba0aec086305029b6410',8840620,1),(177,'37811e0e66a6ebe49b7e04ab487ba8a2',8840620,1),(178,'6ca5e7ab58d81c46d98d394a659d54da',8840620,1),(179,'e7865302497a7fbec0a41d7875d04715',8840620,1),(180,'5b2ee610befdf8a9549da16c3bc38ff6',7577796,1),(181,'8776fbc267e108fceedb7a1a27974009',8840620,1),(182,'18a8f05dbac4fb7929a8a28ff9b6ad99',8840620,1),(183,'935210bcd271ab54715eefe7aed9ba11',8840620,1),(184,'a154ad6cddd6085557003248372148a0',8840620,1),(185,'703397d8a094e38efdd7529ffff6430e',8840620,1),(186,'7c83a63c97f100d86867a08f15d23e5c',8840620,1),(187,'16b37bc55150752a9efd3c82e2039cd5',8840620,1),(188,'db3b1a5da188909d81b330081c6f3c4b',8840620,1),(189,'809c83dbc3f140deb931ff91247dce0b',8840620,1),(190,'72000117127c2b01f7f3cc2cf92476af',8840620,1),(191,'7218bd12353e826f43e9c7e49bd94e46',8840620,1),(192,'4055d160dc080e04d32bda97b9cae962',8840620,1),(193,'d2de598a65679d0b56a27a89485058b2',8840620,1),(194,'2305c7219e4e85cf42f535c5488e2343',7577796,1),(195,'77b03651d14b263b5b4ad5dc1e7729e7',8840620,1),(196,'cc6cdebbd3d4222519c4d7fccb687908',8840620,1),(197,'6c7f62993d1e304ed68dbef1d20184d6',8840620,1),(198,'16aaa86efd48c15bd8a58ea76350e5ef',8840620,1),(199,'1ea41c016d1acf21eae7792ffb88d88b',8840620,1),(200,'36f8c0798f16b84bd6741af4ca39a1c6',8840620,1),(201,'2054bb279c583b8e87a6ceed91195a08',8840620,1),(202,'9a4e776246815615451a897db87edd5b',8840620,1),(203,'88ba49e740eb7881e2fd18d40f56f5c5',8840620,1),(204,'5a34bb10690af25745eed12a1e295846',8840620,1),(205,'1b916dda113bcf01c5c15d2a6a63c9b7',8840620,1),(206,'3567c6ab00ec3d5e9b13cc6c994af7eb',8840620,1),(207,'346f6632115e58c29fbf87ec92f9ce8e',8840620,1),(208,'4144f0a5a504326cd3e42c28bb035f4c',8840620,1),(209,'63f30c38ca06ee964777ebb7a064bb30',8840620,1),(210,'2bebac8d33e2b6eba3413a33c2aae6f1',8840620,1),(211,'eb2751a281c9fca88a7087b7dec6fc37',1035131,1),(212,'5fd7ab3f1ebbcaae8773ec2918296454',8624954,1),(213,'f88948e919df26075645502d82f0b025',8840620,1),(214,'010da757c864e0461457eaa63b6852f3',8840620,1),(215,'5cff0844de1d23b7f5b08e532b28b165',8840620,1),(216,'aa9d57b54a62c1a06abe78dce6defe52',8840620,1),(217,'031837d29281b3a84c9597150e881622',8840620,1),(218,'4e90b042a7f977c4b8e2ea740af82f40',8840620,1),(219,'27a98bf1af92ff4dd1c0d4642d49c07b',8840620,1),(220,'51563b8f94b505f3453b8042b9904e26',8840620,1),(221,'3712d694e9215f9e20a3352a3a28d4e3',8840620,1),(222,'1259e270fc18d3dfdf7ccf72a513aa3e',8840620,1),(223,'9a0accb85d7565154f8de5bf730ecf8e',8840620,1),(224,'4cb5d275f10db31c9670943a98b598c4',8840620,1),(225,'01786805987aff788efaaf51ae54b587',8840620,1),(226,'59a1f228a546470fc612793d06126155',8840620,1),(227,'2b8bb0fbc46888a229927068de3bb097',8840620,1),(228,'da8a00ac9e5d75a486d3d21220dbd17c',8840620,1),(229,'18422b939ef2fddc6c0b9d624451b410',8840620,1),(230,'534deaf76b176fac76361286e4fdf12d',8840620,1),(231,'df9988dc1fd8f30acb29494a20523fc3',8840620,1),(232,'85cc88eaa7bc1a98c49ed27450bd0783',8840620,1),(233,'1a70e714cba6047dd72572548944da49',8840620,1),(234,'3048f6d6d84a7a05d7cd96885d6ec840',8840620,1),(235,'fd06120beb776e27ecac60fb322e2778',8840620,1),(236,'970e0e96742fd6ede08d2929dbac6e8d',8840620,1),(237,'4b4f2c91771480c141d0ac3d6ee63809',8840620,1),(238,'b324de1f438854800af296ce2dd193dd',8840620,1),(239,'38d13830d4454cd384f27eccffe7a801',8840620,1),(240,'3a5d6c7c88a179221a241978c7e648b9',8840620,1),(241,'d89f84956a266d813cd1d48fab9c7992',8840620,1),(242,'b5b1ad12b72cbc7052109ef42b53fb78',8840620,1),(243,'73faf184594ad453d50837b4421e8463',8840620,1),(244,'df7cd18467e73c1cf1c34a74b266871b',8840620,1),(245,'f23efb09deadf26b5fecf3c72350c81f',8840620,1),(246,'14cea15a348140bd1241572b3b48bbf2',8840620,1),(247,'b1f727a9780fa7573fe8769866241d3e',8840620,1),(248,'a8a83c1f517b27d89b5790156dffd02e',8840620,1),(249,'90594200ecb7125d205c08258ed56aee',8840620,1),(250,'c1ac97e042ac553c685f66cd9cee679b',8840620,1),(251,'cd3882590c72ac03dfc742736b823936',8840620,1),(252,'8a05d25c3076ac3cb27cdfa00e860e9c',8840620,1),(253,'5d3672ae8c36f5382b85d736c6154b4d',8840620,1),(254,'fd03c1954c286a71b85a0d52b164e05c',8840620,1),(255,'987cfeec5d947cbf373481b2cb518773',8840620,1),(256,'8ba2c8ae219d6eb409f4c589503b233c',8840620,1),(257,'605f31f35a04efcbf55bfd27c3d3a3df',8840620,1),(258,'03d9b0674a22733792be15493d070ee2',8840620,1),(259,'95c8e07584e77a4c83d192de0b444780',8840620,1),(260,'ffbfb8e0845329a441512e3ee7c28c4a',8840620,1),(261,'cfc2e137cb92da8c4ddf5b0ad57c5bda',8840620,1),(262,'bcb16428d1f993b49019600289a25b7d',7577796,1),(263,'36bfa7ba463d6b86bb6bd807f8d1e5e6',8840620,1),(264,'c0aa16c843bfe25e97e2a6cd44cc1e56',8840620,1),(265,'8dbe7a4ec2408280da429f0d70daa386',8840620,1),(266,'85d891630a1735f94ee0dcfd79d0a48b',8840620,1),(267,'388155294cfb2e991ef24531c4a2cf64',8840620,1),(268,'616471ad6806329f0013a9b6f8536b15',8840620,1),(269,'71d9c89b8e2c620c046d22b9322a3e52',8840620,1),(270,'bf87dd63b073b6f35395854beae90da9',8840620,1),(271,'dc478b115142fb7a806c2d1197a79594',8840620,1),(272,'3869cd5f25118f82bad3a24e31789e1e',8840620,1),(273,'978cf4c75a4c5665d60570188905295c',8840620,1),(274,'00ff5c8adf6e96608e3a666408ccf241',8840620,1),(275,'601350daf88611400fc829468657b912',8840620,1),(276,'8efd4d4f74a4602c49428b687cebd214',8840620,1),(277,'325d3862b5ad742de46f08cc53ac14f8',8840620,1),(278,'19c0bd324f1374bf4d5934cc1cb6a431',8840620,1),(279,'e96e27baa4d48a03930cd8adccac5203',8840620,1),(280,'5044307e56b190642428cc3d8c631071',8840620,1),(281,'5aeb795120390e186e7a792786036d8a',8840620,1),(282,'860c24cbcb495991b4e9ed35c3c2f12a',8840620,1),(283,'e0aefce5f6400315bc1eddc7e3452b21',8840620,1),(284,'285db627013e6f7bdad62cefcdb4a96d',8840620,1),(285,'a934088d8019a9f3acb8dc130c94e825',8840620,1),(286,'c0e0ae44d6460365ab76bb0dbcd79122',8840620,1),(287,'47211dfe2927f98bab60b261f6ee2632',8840620,1),(288,'ab9153a6b4e94c228e420f3ca7c4ba60',8840620,1),(289,'1b7dfd2c7a83746e4a9edc2909e8357a',8840620,1),(290,'2d01410c61e3e312f198566902a7d3d7',8840620,1),(291,'95b97e580d74c7adaa609879f9f07629',8840620,1),(292,'68f74c76f096f1f31694c318e03e02bb',8840620,1),(293,'e316ac29daf9c69d70d71ec9632c0e15',8840620,1),(294,'d0cf875c908c1a0fdeaabf10a50a4582',8840620,1),(295,'5e9eb8759146305945571b657fb3d69d',8840620,1),(296,'77d1b504c0bc2d5c535d10f0b39b2058',8840620,1),(297,'bf5afdda9644e0c8f5f58ba0e2d8349d',8840620,1),(298,'9582de99853a774f0f9a73f3e07afbe4',8840620,1),(299,'ef33863f14dc90ad8948f12958c0dc18',8840620,1),(300,'5a1613c667a77276be999b1d78de2a43',8840620,1),(301,'b55c37c7243d165220c831be85f91072',8840620,1),(302,'87d38ebd654ae0ce960d7321ec1bc07a',8840620,1),(303,'09eb82a7f28b7e6f930c170e52994033',8840620,1),(304,'ac4b87a8d454ca32f034a3d41d1bab79',8840620,1),(305,'6bee9d5d0cc6c36adc941f06c52241f5',8840620,1),(306,'e2074f9c99397459c403e88dc8db60ed',8840620,1),(307,'c8dc9ad605e1e5358e2e0106f4541fc7',8840620,1),(308,'2c5fa7112c1f7bfa6ae0896f97147daf',8840620,1),(309,'9d28bd00574d5bcd1d6216db09ec0f8d',8840620,1),(310,'be54daf148e4786a6e47c7fb43ed1cda',8840620,1),(311,'e40b3cd573f9d2e78c0bd6996218dbbc',8840620,1),(312,'1b12c66e715c8afa8a99a1b8be90066f',8840620,1),(313,'965de6cda65a8439f4d6356fad3911b2',8840620,1),(314,'fbe786a4d727db31f3a56dbf2db8c6a5',8840620,1),(315,'5a2ac27d58d173d89f41f0b3107c691e',8840620,1),(316,'d1b6317f87a3745a81226863239e7394',8840620,1),(317,'fac4d7a5adb70d0a475351c3fd612daf',8840620,1),(318,'c83c10deca812db7f4bbacf246595d39',8840620,1),(319,'7eb93c189716396a6ddf0ad5fea0e69e',8840620,1),(320,'7e7fc3971dbfc82d6e9d75c5a621ba4e',8840620,1),(321,'86a70f3ca1d4821f9e3f22997939b789',8840620,1),(322,'004c742723f4afd28e1fd7e8d339a233',8840620,1),(323,'b09fbf71e55d559db0c7761679fe6974',8840620,1),(324,'2e9c59b4ce55090cae189cc354ec9fb2',8840620,1),(325,'a36edae5f6a587ea8341db8bc6e30d2f',8840620,1),(326,'7df4acda6c24db3eff0e0f398ddbff1a',8840620,1),(327,'085798d116e43885d9e02a8de069f204',7577796,1),(328,'0764a88abeb323e5b3990a68713cd2ff',8840620,1),(329,'ea4bfc85b04a10374a28faece68482f8',8840620,1),(330,'2a4fe41fc956f21b01306701e6306f01',4689972,1),(331,'3a9b7bef34b1fb537b5f696766fc7503',8840620,1),(332,'cba5fa48d44240e501d174320e83efcc',8624954,1),(333,'0fa5b1f365f5b84d6ee8972a56847018',7577796,1),(334,'1beb6e17d4ccd3a36cd952f094d0d889',9361701,1),(335,'b028c05644df1da8039a89e71e3a0a7c',8840620,1),(336,'7b3f4bee3aa9e6d23531c2980ffbdea1',9361701,1),(337,'fd6387a4c75799d9be6a3edf1c4bd28a',9361701,1),(338,'865dc4ece1b2a174fd52bd779f9c0631',7577796,1),(339,'11862866188e54cba4001c655edc42e4',9361701,1),(340,'75f97fc0efd3ece76b05217c18d6ce8e',9361701,1),(341,'67f0cf480614228f715c42e2241d6cbb',3617298,1),(342,'22772df75c911e77c9be4931bec42e9c',9361701,1),(343,'b5ca2eea4e953df930be68814aee720a',7577796,1),(344,'c5a4435300df41e8ee315dcbd1c7c9d7',3400038,1),(345,'322eeae86f45d4d5f1ff6880c878b8fb',2795557,1),(346,'822f49871ca3573de127ad7fbaec21cd',8072240,1),(347,'214ccfb355874470aec16e2aa052d9ce',7848788,1),(348,'a5f1b9dadb07d16f20faf4baf86dab02',7848788,1),(349,'452164de581580f494c46dbe84c06cd0',3617298,1),(350,'82b78551bbec9800695ebcd21f69d9e8',8624954,1),(351,'2d1a2f37f68d7c60011c3440a0b42dd5',3617298,1),(352,'5f525590574942e8bd73f26c29e8b9ce',8624954,1),(353,'c5692db91c135e4a456e606466400f8f',7577796,1),(354,'0f06ab8d977278c615a5e82728cbfbac',3617298,1),(355,'6f9a5dae6cfa922630b9f09293093479',5464799,1),(356,'eebd5363ffdedd68de69c54bf318e0bb',8624954,1),(357,'6756fe93c2640cbb58aca91fcbb224da',7577796,1),(358,'8f6aa9ed450af4f2948a251161f28af9',7577796,1),(359,'f54da974803912fe0ba3f9cdc07256bc',1035131,1),(360,'da1fa90310a5aaf0866d6b25a6da85c5',7848788,1),(361,'7679b09a7354926d6669125680a005b1',1035131,1),(362,'f681242a55a5fc5296f132275aef2d44',8840620,1),(363,'57665e7af7c94835755e81f7f33a56fa',8840620,1),(364,'d82b93d8ede6262122e5df727aeedaaa',8840620,1),(365,'9a0c646de576658df8eedbc1e81d5c19',8840620,1),(366,'4f20ff029b064605da3012116bc06dbe',8840620,1),(367,'08951b5ca4afeb697fd99dd6abbbabb4',8840620,1),(368,'5b71b5b55634afdad0945f2978b9b953',4352108,1),(369,'8097dfe1ff8ccfed971b73c873312d4a',7577796,1),(370,'aca5e0292dd391022a9cb221cb494664',4352108,1),(371,'c393cf9a87a45254f280d0bd09c98622',4352108,1),(372,'0ca5ee8fdc74a70b9d391def355ec13f',7246089,1),(373,'f7505f3d84780d4277b7e81561572d63',6929097,1),(374,'b9f6b68ac0c28021f6be5b41d7198f37',4352108,1),(375,'7049b4649817cf60dd488fd5ac3db1ed',7577796,1),(376,'3132c0e3094167a7b3b91a5f9f97dea5',7577796,1),(377,'976bb7c4bd48cc1e4d88179a150bcea7',7577796,1),(378,'354229ac53bc2cc3626813e24664cd78',7577796,1),(379,'224428477fc9f6918e23abc3ec5ec0b7',7577796,1),(380,'72ac479cf3c34376efa0e00c2097e256',4988492,1),(381,'f0d634a5183b10bdea74e83359861031',7577796,1),(382,'e47d292f52c9625df1afd274f2d7e4a1',8624954,1),(383,'70b7ec77d0edd0df96a3ea9863131582',7577796,1),(384,'f1b9623ebd9496aa1f0c037f02bee2a0',7577796,1),(385,'bcfced0287daa149daf436d54874ad4c',1057664,1),(386,'0804efa256e08146ca124a496a91ce48',4352108,1),(387,'19811c15104ac620ca62bbd0cf4b0ac2',4352108,1),(388,'40d2416f1f7b2e4a418f774c5ce92674',4352108,1),(389,'3b9d26b0fd6a7a0499bfd2236d4a787d',4352108,1),(390,'470b4fe7bacfd2f3340516248f1279af',4352108,1),(391,'a19ef964c0f022020ee9c29f1e27c958',7577796,1),(392,'e5c5d3667abd994fd5405c894cd1e8e2',7577796,1),(393,'d49e247ed8e03e07680f3d2302bbf560',7577796,1),(394,'81a7dbe02e4cddc0d22d39f31b4e32c4',7577796,1),(395,'8bcd586ca85e994d39bdac5bca49ccf4',7577796,1),(396,'c170ce7e2a99d2b63a1453dcced4399d',7577796,1),(397,'7b647a6e8e50cddd0c37007ad5c03ee5',7577796,1),(398,'14bbad918811824d640ddb2eb340226e',7442202,1),(399,'74c51e52850db8762f53844875444b4f',7577796,1),(400,'193018890e82783d3d6defd65df5fcf7',8624954,1),(401,'1d276a0ede02fffb857f130668a4768d',8624954,1),(402,'5946fd3efab73c596f2d708722fa2b30',8624954,1),(403,'35f89a50179f22220d672576525052d1',8624954,1),(404,'edeb521239ebaebf442bd5d8db48b210',7577796,1),(405,'8963a8b5c9efd48842c2fabd6e3050aa',8624954,1),(406,'fbf225b30132ab7fa6484ba884776961',8624954,1),(407,'e6f1191ee088cf098ff8b83bda522e27',8624954,1),(408,'c1b5c40439340a2d2f033558d3adc888',8624954,1),(409,'8c95b178c4128b7561436cb1bb77b7ba',8624954,1),(410,'b474a13228e1472db30d83ba8357b3b1',8624954,1),(411,'a37c2f9a062e1214be191590970f6996',7577796,1),(412,'0010ce270ffefd221e100e33539ba280',8624954,1),(413,'76849463c37d379799c95326ac9aacd6',8624954,1),(414,'3beb41ba711cca6d02d712c685f5ef7a',8624954,1),(415,'fa2790dec5c6d7caee62ca646ad0dbb2',7577796,1),(416,'6ca3a9aff099195a2d977bcaf075f38b',8624954,1),(417,'0652dee77c2fb26d4fb3b5e67d0e4cee',7577796,1),(418,'bb325fe2cff7bc1b1d09abf615137094',7577796,1),(419,'24c40f1e29f255a146647f0c6308a716',8624954,1),(420,'4bfefdb56eb89c06b814bee256fcbfe7',8624954,1),(421,'d437cde1513fe4aa92b81d97053072b8',7577796,1),(422,'39d9f261c59c1995a29c0e1240914e82',8624954,1),(423,'d6e1d3172af9439d719689f390549f9d',8624954,1),(424,'341a04318c763f19277a5bebbd19d5df',8624954,1);
/*!40000 ALTER TABLE `app_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `badge`
--

DROP TABLE IF EXISTS `badge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `badge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) NOT NULL,
  `idproof` varchar(100) NOT NULL,
  `proof_path` varchar(750) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `badge`
--

LOCK TABLES `badge` WRITE;
/*!40000 ALTER TABLE `badge` DISABLE KEYS */;
INSERT INTO `badge` VALUES (1,'5136172','passport','assets/uploads/proofs/SM5136172-Aswathi-become-member.png','2017-05-10 12:25:38'),(2,'4005106','passport','assets/uploads/proofs/SM4005106-shankar-logo.png','2019-03-21 15:55:15'),(3,'10249','aadhar_card','assets/uploads/proofs/PT10249-Siva-boksl.png','2019-06-30 19:56:17');
/*!40000 ALTER TABLE `badge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bridal_collection`
--

DROP TABLE IF EXISTS `bridal_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bridal_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `short_desc` text NOT NULL,
  `img` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bridal_collection`
--

LOCK TABLES `bridal_collection` WRITE;
/*!40000 ALTER TABLE `bridal_collection` DISABLE KEYS */;
INSERT INTO `bridal_collection` VALUES (2,'Bridal Saree','Saree details here  ','3925c87342e961b928efa641d30419c0.jpeg');
/*!40000 ALTER TABLE `bridal_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `castes`
--

DROP TABLE IF EXISTS `castes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `castes` (
  `caste_id` int(11) NOT NULL AUTO_INCREMENT,
  `religion_id` int(11) NOT NULL,
  `caste_name` varchar(34) NOT NULL,
  `caste_status` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`caste_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2275 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `castes`
--

LOCK TABLES `castes` WRITE;
/*!40000 ALTER TABLE `castes` DISABLE KEYS */;
INSERT INTO `castes` VALUES (1,1,'Aaru Nattu Vellala',''),(2,1,'Ad Dharmi',''),(3,1,'Adi Andhra',''),(4,1,'Adi Dravidar',''),(5,1,'Adi Karnataka',''),(6,1,'Agamudayar/Arcot/Thuluva Vellala',''),(7,1,'Agaram Vellan Chettiar',''),(8,1,'Agarwal',''),(9,1,'Agnikula Kshatriya',''),(10,1,'Agrahari',''),(11,1,'Agri',''),(12,1,'Ahir Shimpi',''),(13,1,'Ahirwar',''),(14,1,'Ahom',''),(15,1,'Ambalavasi',''),(16,1,'Anjana (Chowdary)Patel',''),(17,1,'Aramari / Gabit',''),(18,1,'Arekatica',''),(19,1,'Arora',''),(20,1,'Arunthathiyar',''),(21,1,'Arya Vysya',''),(22,1,'Asathi',''),(23,1,'Ayira Vysya',''),(24,1,'Ayodhyavasi',''),(25,1,'Ayyaraka',''),(26,1,'Budaga',''),(27,1,'Bagdi',''),(28,1,'Baidya',''),(29,1,'Bairwa',''),(30,1,'Baishbnab',''),(31,1,'Baishya',''),(32,1,'Bajantri',''),(33,1,'Balai',''),(34,1,'Balija',''),(35,1,'Balija Naidu',''),(36,1,'Balija Reddy',''),(37,1,'Banayat Oriya',''),(38,1,'Banik',''),(39,1,'Baniya',''),(40,1,'Baniya - Bania',''),(41,1,'Baniya - KUmuti',''),(42,1,'Banjara',''),(43,1,'Barai',''),(44,1,'Barnwal',''),(45,1,'Barujibi',''),(46,1,'Beri Chettiar',''),(47,1,'Besta',''),(48,1,'Bhandari',''),(49,1,'Bhaia',''),(50,1,'Bhatraju',''),(51,1,'Bhavasar Vshatriya',''),(52,1,'Bhoi',''),(53,1,'Bhovi',''),(54,1,'Bhoyar',''),(55,1,'Billava',''),(56,1,'Bishnoi / Vishnoi',''),(57,1,'Bondili',''),(58,1,'Born Again',''),(59,1,'Boyar',''),(60,1,'Brahmbatt',''),(61,1,'Brahmin - Anavil',''),(62,1,'Brahmin - Anaviln Desai',''),(63,1,'Brahmin - Audichya',''),(64,1,'Brahmin - Baidhiki / Vaidhiki',''),(65,1,'Brahmin - Bardai',''),(66,1,'Brahmin - Barendra',''),(67,1,'Brahmin - Bhargav',''),(68,1,'Brahmin - Bhatt',''),(69,1,'Brahmin - Bhumihar',''),(70,1,'Brahmin - Dadhich',''),(71,1,'Brahmin - Daivadnya',''),(72,1,'Brahmin - Danua',''),(73,1,'Brahmin - Deshastha',''),(74,1,'Brahmin - Dhiman',''),(75,1,'Brahmin - Dravida',''),(76,1,'Brahmin - Embrandiri',''),(77,1,'Brahmin - Garhwali',''),(78,1,'Brahmin - Gaur',''),(79,1,'Brahmin - Goswami / Gosavi',''),(80,1,'Brahmin - Gujar Gaur',''),(81,1,'Brahmin - Gurakkal',''),(82,1,'Brahmin - Halua',''),(83,1,'Brahmin - Havyaka',''),(84,1,'Brahmin - Hoysala',''),(85,1,'Brahmin - Iyengar',''),(86,1,'Brahmin - Iyer',''),(87,1,'Brahmin - Jabgid',''),(88,1,'Brahmin - Jhadua',''),(89,1,'Brahmin - Jyotish',''),(90,1,'Brahmin - Kanyakubi',''),(91,1,'Brahmin - Karhade',''),(92,1,'Brahmin - Khadayata',''),(93,1,'Brahmin - Khandelwal',''),(94,1,'Brahmin - Khedaval',''),(95,1,'Brahmin - Kokanastha',''),(96,1,'Brahmin - Kota',''),(97,1,'Brahmin - Koteshwara /Kota(Madhwa)',''),(98,1,'Brahmin - Kulin',''),(99,1,'Brahmin - Kumaoni',''),(100,1,'Brahmin - Madhwa',''),(101,1,'Brahmin - Maithil',''),(102,1,'Brahmin - Meveda',''),(103,1,'Brahmin - Modh',''),(104,1,'Brahmin - Mohyal',''),(105,1,'Brahmin - Nagar',''),(106,1,'Brahmin - Namboodiri',''),(107,1,'Brahmin - Narmadiya',''),(108,1,'Brahmin - Niyogi',''),(109,1,'Brahmin - Others',''),(110,1,'Brahmin - Paliwal',''),(111,1,'Brahmin - Panda',''),(112,1,'Brahmin - Pandit',''),(113,1,'Brahmin - Panicker',''),(114,1,'Brahmin - Pareek',''),(115,1,'Brahmin - Pushkarna',''),(116,1,'Brahmin - Rajgor',''),(117,1,'Brahmin - Rarhi',''),(118,1,'Brahmin - Rarhi /Radhi',''),(119,1,'Brahmin - Rigvedi',''),(120,1,'Brahmin - Rudraj',''),(121,1,'Brahmin - Sakaldwipi',''),(122,1,'Brahmin - Sanadya',''),(123,1,'Brahmin - Sanketi',''),(124,1,'Brahmin - Saraswat',''),(125,1,'Brahmin - Sarua',''),(126,1,'Brahmin - Saeyuparin',''),(127,1,'Brahmin - Shivalli (Madhva)',''),(128,1,'Brahmin - Shivhalli',''),(129,1,'Brahmin - Shri Gaud',''),(130,1,'Brahmin - Shri Mali',''),(131,1,'Brahmin - Shrimali',''),(132,1,'Brahmin - Shukla Yajurvedi',''),(133,1,'Brahmin - Sikhwal',''),(134,1,'Brahmin - Smartha',''),(135,1,'Brahmin - Sri Vaishnava',''),(136,1,'Brahmin - Stanila',''),(137,1,'Brahmin - Tapodhan',''),(138,1,'Brahmin - Tyagi',''),(139,1,'Brahmin - Vaidiki',''),(140,1,'Brahmin - Vaikhanasa',''),(141,1,'Brahmin - Valam',''),(142,1,'Brahmin - Velanadu',''),(143,1,'Brahmin - Vyas',''),(144,1,'Brahmin - Zalora',''),(145,1,'Brajastha Maithil',''),(146,1,'Bunt (Shetty)',''),(147,1,'CKP',''),(148,1,'Chalawadi and Holeya',''),(149,1,'Chambhar',''),(150,1,'Chandravanishi Kahar',''),(151,1,'Chasa',''),(152,1,'Chattada Sri Vaishnava',''),(153,1,'Chaturth',''),(154,1,'Chaudary',''),(155,1,'Chaurasia',''),(156,1,'Chennadasar',''),(157,1,'Cjerukula Vellalar',''),(158,1,'Chettiar',''),(159,1,'Chhetri',''),(160,1,'Chippolu(Mera)',''),(161,1,'Choudary',''),(162,1,'Coorgi',''),(163,1,'Deshmukh',''),(164,1,'Desikar',''),(165,1,'Desikar Thanjuvur',''),(166,1,'Devadiga',''),(167,1,'Devandra Kula Vellalar',''),(168,1,'Devang Koshthi',''),(169,1,'Devanga',''),(170,1,'Devanga Chettiar',''),(171,1,'Devar / Thevar /Mukkulathor',''),(172,1,'Devrukhe Brahmin',''),(173,1,'Dhanak',''),(174,1,'Dhangar',''),(175,1,'Dheevara',''),(176,1,'Dhiman',''),(177,1,'Dhobi',''),(178,1,'Dhor /Dusra',''),(179,1,'Dumal',''),(180,1,'Dusadh (Paswan)',''),(181,1,'Ediga',''),(182,1,'Ediga / Goud (Balija)',''),(183,1,'Elur Chetty',''),(184,1,'Ezhava',''),(185,1,'Ezhava Panciker',''),(186,1,'Ezhava Thandan',''),(187,1,'Ezhuthachan',''),(188,1,'Gabit',''),(189,1,'Gahoi',''),(190,1,'Gajula / Kavarai',''),(191,1,'Ganda',''),(192,1,'Gandha Vanika',''),(193,1,'Gandla',''),(194,1,'Gandla / Ganiga',''),(195,1,'Ganiga',''),(196,1,'Garhwall',''),(197,1,'Gatti',''),(198,1,'Gavara',''),(199,1,'Gawali',''),(200,1,'Ghisadi',''),(201,1,'Ghumar',''),(202,1,'Goala',''),(203,1,'Goan',''),(204,1,'Gomantak',''),(205,1,'Gondhali',''),(206,1,'Goud',''),(207,1,'Gounder',''),(208,1,'Gounder - Kongu Vellala Gounder',''),(209,1,'Gounder - Nattu Guunder',''),(210,1,'Gounder - Others',''),(211,1,'Gounder - Urali Gounder',''),(212,1,'Gounder - Vanniya Kula Kshatriyar',''),(213,1,'Gounder - Vettuva Gounder',''),(214,1,'Gowda',''),(215,1,'Gowda - Kuruba gowda',''),(216,1,'Gramani',''),(217,1,'Gudia',''),(218,1,'Gujjar',''),(219,1,'Gulahre',''),(220,1,'Gupta',''),(221,1,'Guptan',''),(222,1,'Gurav',''),(223,1,'Gurjar',''),(224,1,'Haihavanshi',''),(225,1,'Halba Koshti',''),(226,1,'Helava',''),(227,1,'Hugar(Jeer)',''),(228,1,'IIIaththu Pillai',''),(229,1,'Intercaste',''),(230,1,'Irani',''),(231,1,'Isai Vellalar',''),(232,1,'Jaalari',''),(233,1,'Jaiswal',''),(234,1,'Jandra',''),(235,1,'Jangam',''),(236,1,'Jangra - Brahmin',''),(237,1,'Jat',''),(238,1,'Jatav',''),(239,1,'Jetty / Malla',''),(240,1,'Jhadav',''),(241,1,'Jijhotia Brahmin',''),(242,1,'Jogi (Nath)',''),(243,1,'Julaha',''),(244,1,'Kachara',''),(245,1,'Kadava Patel',''),(246,1,'Kaibarta',''),(247,1,'Kaikaala',''),(248,1,'Kalal',''),(249,1,'Kalanji',''),(250,1,'Kalar',''),(251,1,'Kalinga',''),(252,1,'Kalinga Vysya',''),(253,1,'Kalita',''),(254,1,'Kalwar',''),(255,1,'Kamboj',''),(256,1,'Kamma',''),(257,1,'Kamma Naidu',''),(258,1,'Kanakkan Padanna',''),(259,1,'Kandara',''),(260,1,'Kanasari',''),(261,1,'Kanykubj Bania',''),(262,1,'Kapu',''),(263,1,'Kapu Naidu',''),(264,1,'Kapu Reddy',''),(265,1,'Karakala Bhakthula',''),(266,1,'Karana',''),(267,1,'Karkathar',''),(268,1,'Karmakar',''),(269,1,'Karani Bhakthula',''),(270,1,'Karuneegar',''),(271,1,'Kasar',''),(272,1,'Kasaundhan',''),(273,1,'Kashyap',''),(274,1,'Kasukara',''),(275,1,'Katiya',''),(276,1,'Kavara',''),(277,1,'Kavuthiyya / Ezhavathy',''),(278,1,'Kayastha',''),(279,1,'Kayastha (Bengali)',''),(280,1,'Kerala Mudali',''),(281,1,'Keshri (Kesarwani)',''),(282,1,'Khandayat',''),(283,1,'Khandelwal',''),(284,1,'Kharwa',''),(285,1,'Kharwar',''),(286,1,'Khatik',''),(287,1,'Khatri',''),(288,1,'Kirar',''),(289,1,'Kodikal Pillai',''),(290,1,'Kokanastha Maratha',''),(291,1,'Koli',''),(292,1,'Koli Madhadev',''),(293,1,'Koli Patel',''),(294,1,'Komati / Arya Vaishya',''),(295,1,'Kongu Chettiar',''),(296,1,'Kongu Nadar',''),(297,1,'Kongu Vellala Gounder',''),(298,1,'Konkani',''),(299,1,'Korama',''),(300,1,'Kori',''),(301,1,'Kori / Koli',''),(302,1,'Kosthi',''),(303,1,'Krishnavaka',''),(304,1,'Kshatriya',''),(305,1,'Kshatriya Kurmi',''),(306,1,'Kshatriya Raju',''),(307,1,'Kudumbi',''),(308,1,'Kulal',''),(309,1,'Kulalar',''),(310,1,'Kilita',''),(311,1,'Kumaoni Rajput',''),(312,1,'Kumawat',''),(313,1,'Kumbhakar',''),(314,1,'Kumbhar',''),(315,1,'Kumhar',''),(316,1,'Kummari',''),(317,1,'Kunbi',''),(318,1,'Kunbi Lonari',''),(319,1,'Kunbi Maratha',''),(320,1,'Kunbi Tirale',''),(321,1,'Kuravan',''),(322,1,'Kurmi',''),(323,1,'Kurmi / Kurmi Kshatriya',''),(324,1,'Kurni',''),(325,1,'Kuruba',''),(326,1,'Kuruhina Shetty',''),(327,1,'Kuruhini CHetty',''),(328,1,'Kurumbar',''),(329,1,'Kuruva',''),(330,1,'Kushwaha (Koiri)',''),(331,1,'Kurchi',''),(332,1,'Lad',''),(333,1,'Lambadi',''),(334,1,'Leva patel',''),(335,1,'Linga Balija',''),(336,1,'Lingayath',''),(337,1,'Lodhi Rajput',''),(338,1,'Lohana',''),(339,1,'Lohar',''),(340,1,'Loniya',''),(341,1,'Lubana',''),(342,1,'Madhesiya / Kani / Halwai',''),(343,1,'Madiga',''),(344,1,'Mahakan',''),(345,1,'Mahar',''),(346,1,'Mahendra',''),(347,1,'Maheswari',''),(348,1,'Maheswari / Meshri',''),(349,1,'Mahishya',''),(350,1,'Mahor',''),(351,1,'Mahuri',''),(352,1,'Mair Rajput Swarnkar',''),(353,1,'Majabi',''),(354,1,'Mala',''),(355,1,'Mali',''),(356,1,'Mallah',''),(357,1,'Malviya Bramhim',''),(358,1,'Malwani',''),(359,1,'Mangalorean',''),(360,1,'Manipuri',''),(361,1,'Manjapidur Chettiar',''),(362,1,'Mannan / Velan / Vannan',''),(363,1,'Mapila',''),(364,1,'Maratha',''),(365,1,'Maratha Kshatriya',''),(366,1,'Maruthuvar',''),(367,1,'Matang',''),(368,1,'Mathur',''),(369,1,'Mathur Vaishya',''),(370,1,'Maurya / Shakya',''),(371,1,'Meena',''),(372,1,'Meenavar',''),(373,1,'Meghwal',''),(374,1,'Mehra',''),(375,1,'Meru Darji',''),(376,1,'Mochi',''),(377,1,'Medak',''),(378,1,'Modi',''),(379,1,'Modikarlu',''),(380,1,'Mogaveera',''),(381,1,'Mudaliyar',''),(382,1,'Mudiraj',''),(383,1,'Munnuru Kapu',''),(384,1,'Musukama',''),(385,1,'Muthuraja',''),(386,1,'Naagavamsam',''),(387,1,'Nabit',''),(388,1,'Nadar',''),(389,1,'Nagaralu',''),(390,1,'Nai',''),(391,1,'Naicker',''),(392,1,'Naicker - Others',''),(393,1,'Naicker - Vanniya Kula Kshatriyar',''),(394,1,'Naidu',''),(395,1,'Naik',''),(396,1,'Nair',''),(397,1,'Namasudra / Namaseej',''),(398,1,'Namniar',''),(399,1,'Namdarlu',''),(400,1,'Nanjil Mudali',''),(401,1,'Nanjil Nattu Vellalar',''),(402,1,'Nanjil Vellalar',''),(403,1,'Nanjil Pillai',''),(404,1,'Nankudi Vellalar',''),(405,1,'Napit',''),(406,1,'Nattu Gounder',''),(407,1,'Nattukottai Chettiar',''),(408,1,'Nayaka',''),(409,1,'Neeli',''),(410,1,'Neeli Saali',''),(411,1,'Nema',''),(412,1,'Nepali',''),(413,1,'Nessi',''),(414,1,'Nhavi',''),(415,1,'Ontari',''),(416,1,'Oswal',''),(417,1,'Otari',''),(418,1,'Othuvaar',''),(419,1,'Padmasali',''),(420,1,'Padmashali',''),(421,1,'Padmavathi Porwal',''),(422,1,'Pagadala',''),(423,1,'Pal',''),(424,1,'Pallan / Devandra Kula Vellalan',''),(425,1,'Panan',''),(426,1,'Panchal',''),(427,1,'Pandaram',''),(428,1,'Pandiya Vellalar',''),(429,1,'Panicker',''),(430,1,'Pannirandam Chettiar',''),(431,1,'Paravan / Bharatar',''),(432,1,'Parit',''),(433,1,'Parkava Kulam',''),(434,1,'Parsi',''),(435,1,'Partraj',''),(436,1,'Parvatha Rajakulam',''),(437,1,'Pasi',''),(438,1,'Paswan / Dusadh',''),(439,1,'Patel',''),(440,1,'Pathare Prabhu',''),(441,1,'Patil',''),(442,1,'Patnick / Sistakaranam',''),(443,1,'Patra',''),(444,1,'Pattinavar',''),(445,1,'Pattusali',''),(446,1,'Patwa',''),(447,1,'Perika',''),(448,1,'Perika / Puragiri Kshatriya',''),(449,1,'Pillai',''),(450,1,'Poosala',''),(451,1,'Porwal',''),(452,1,'Porwal / Porwar',''),(453,1,'Poundra',''),(454,1,'Prajapati',''),(455,1,'Pulaya / Cheruman',''),(456,1,'Raigar',''),(457,1,'Rajaka',''),(458,1,'Rajastani',''),(459,1,'Rajbhar',''),(460,1,'Rajbonshi',''),(461,1,'Rajpurohot',''),(462,1,'Rajput',''),(463,1,'Ramanandi',''),(464,1,'Ramdasia',''),(465,1,'Ramgariah',''),(466,1,'Ramoshi',''),(467,1,'Rastogi',''),(468,1,'Rathi',''),(469,1,'Rauniar',''),(470,1,'Ravidaisia',''),(471,1,'Rawat',''),(472,1,'Reddy',''),(473,1,'Relli',''),(474,1,'Ronit / Chamar',''),(475,1,'Ror',''),(476,1,'SC',''),(477,1,'SKP',''),(478,1,'ST',''),(479,1,'Sadgope',''),(480,1,'Sadhi Chetty',''),(481,1,'Sagara (Uppara)',''),(482,1,'Saha',''),(483,1,'Sahu',''),(484,1,'Saini',''),(485,1,'Saiva Pillai Thanjavur',''),(486,1,'Saiva Pillai Tirunelveli',''),(487,1,'Saliya',''),(488,1,'Samagar',''),(489,1,'Sambava',''),(490,1,'Sathwara',''),(491,1,'Satnami',''),(492,1,'Savji',''),(493,1,'Senai Thalaivar',''),(494,1,'Senguntha Mudiliyar',''),(495,1,'Sengunthar / Kaikolar',''),(496,1,'Settibalija',''),(497,1,'Setty Balija',''),(498,1,'Shaw / Sahu / Teli',''),(499,1,'Shettigar',''),(500,1,'Shipkar',''),(501,1,'Shimpi/ Namdev',''),(502,1,'Sindhi',''),(503,1,'Sindhi-Amil',''),(504,1,'Sindhi-Baibhand',''),(505,1,'Sindhi-Bhanusali',''),(506,1,'Sindhi-Bhatia',''),(507,1,'Sindhi-Chhapru',''),(508,1,'Sindhi-Dadu',''),(509,1,'Sindhi-Hyderabadi',''),(510,1,'Sindhi-Larai',''),(511,1,'Sindhi-Larkana',''),(512,1,'Sindhi-Lohana',''),(513,1,'Sindhi-Rohiri',''),(514,1,'Sindhi-Sahiti',''),(515,1,'Sindhi-Sakkhar',''),(516,1,'Sindhi-Sehwani',''),(517,1,'Sindhi-Shikarpuri',''),(518,1,'Sindhi-Thatai',''),(519,1,'Sonar',''),(520,1,'Soni',''),(521,1,'Sonkar',''),(522,1,'Sourashtra',''),(523,1,'Sozhia Chetty',''),(524,1,'Sozhiya Vellalar',''),(525,1,'Srisayana',''),(526,1,'Sugali (Naika)',''),(527,1,'Sunari',''),(528,1,'Sundhi',''),(529,1,'Surya Balija',''),(530,1,'Suthar',''),(531,1,'Swakula Sali',''),(532,1,'Tamboli',''),(533,1,'Tanti',''),(534,1,'Tantubai',''),(535,1,'Telaga',''),(536,1,'Teli',''),(537,1,'Telugupatti',''),(538,1,'Thakkar',''),(539,1,'Thakore',''),(540,1,'Thakur',''),(541,1,'Thandan',''),(542,1,'Thigala',''),(543,1,'Thiyya',''),(544,1,'Thiyya Thandan',''),(545,1,'Thogata Veera Kshatriya',''),(546,1,'Thogata Veerakshathriya',''),(547,1,'Thondai Mandala Vellalar',''),(548,1,'Thota',''),(549,1,'Tili',''),(550,1,'Togata',''),(551,1,'Tonk Kshatriya',''),(552,1,'Turupu Kapu',''),(553,1,'Ummar / Umre / Bagaria',''),(554,1,'Urali Gounder',''),(555,1,'Urs',''),(556,1,'Vada Baliji',''),(557,1,'Vasambar',''),(558,1,'Vaddera',''),(559,1,'Vadugan',''),(560,1,'Vaish',''),(561,1,'Vaishnav',''),(562,1,'Vaishanav Dishaval',''),(563,1,'Vaishanav Khadyata',''),(564,1,'Vaishanav Lad',''),(565,1,'Vaishanav Modh',''),(566,1,'Vaishanav Porvas',''),(567,1,'Vaishanav Shrimali',''),(568,1,'Vaishanav Sorathaiya',''),(569,1,'Vaishanav Vania',''),(570,1,'Vaishanav',''),(571,1,'Vaishya',''),(572,1,'Vaishya Vani',''),(573,1,'Vallivan',''),(574,1,'Vakmiki',''),(575,1,'Vani',''),(576,1,'Vani / Vaishya',''),(577,1,'Vania',''),(578,1,'Vanika Vyshaya',''),(579,1,'Vaniya',''),(580,1,'Vaniya Chettiar',''),(581,1,'Vanjara',''),(582,1,'Vanjari',''),(583,1,'Vankar',''),(584,1,'Vannar',''),(585,1,'Vannia Kula Lshatriyar',''),(586,1,'Variar',''),(587,1,'Varshney',''),(588,1,'Varsjney (Baraseni)',''),(589,1,'Veera Shivam',''),(590,1,'Veerakodi Vellala',''),(591,1,'Velaan',''),(592,1,'Velama',''),(593,1,'Vellalar',''),(594,1,'Vellan Chettiars',''),(595,1,'Veluthedathu Nair',''),(596,1,'Vettuva Gounder',''),(597,1,'Vettuvan',''),(598,1,'Vijayvargia',''),(599,1,'Vilakithala Nair',''),(600,1,'Vilakkithala Nair',''),(601,1,'Vishwakarma',''),(602,1,'Viswabramhin',''),(603,1,'Vokkaliga',''),(604,1,'Vysya',''),(605,1,'Yadav',''),(606,1,'Yadav Naidu',''),(607,1,'Yellapu',''),(608,1,'Other Caste',''),(609,1,'Don\'t wish to Specify',''),(610,1,'Avavil Bramhin',''),(611,1,'Audichya Brahmin',''),(612,1,'Barendra Brahmin',''),(613,1,'Bharr Brahmin',''),(614,1,'Bhatt Brahmin',''),(615,1,'Bhumihar Brahmin',''),(616,1,'Daivadnya Brahmin',''),(617,1,'Danua Brahmin',''),(618,1,'Deshasthu Brahmin',''),(619,1,'Dhiman Brahmin',''),(620,1,'Dravida Brahmin',''),(621,1,'Embrandiri Brahmin',''),(622,1,'Gaur Brahmin',''),(623,1,'Goswami / Gosavi Brahmin',''),(624,1,'Gujar Guar Brahmin',''),(625,1,'Gurukkal Brahmin',''),(626,1,'Havyaka Brahmin',''),(627,1,'Hoysala Brahmin',''),(628,1,'Iyengar Brahmin',''),(629,1,'Iyer Brahmin',''),(630,1,'Jangid Brahmin',''),(631,1,'Jangid Brahmin',''),(632,1,'Jhadua Brahmin',''),(633,1,'Janyajubi Brahmin',''),(634,1,'Kanyakubj Brahmin',''),(635,1,'Karhade Brahmin',''),(636,1,'Kokanastha Brahmin',''),(637,1,'Kota Brahmin',''),(638,1,'Kulin Brahmin',''),(639,1,'Kumaoni Brahmin',''),(640,1,'Madhwa Brahmin',''),(641,1,'Maithil Brahmin',''),(642,1,'Modh Brahmin',''),(643,1,'Mohyal Brahmin',''),(644,1,'Nagar Brahmin',''),(645,1,'Namboodiri Brahmin',''),(646,1,'Barmaduya Brahmin',''),(647,1,'Niyogi Brahmin',''),(648,1,'Panda Brahmin',''),(649,1,'Pandit Brahmin',''),(650,1,'Pushkarna Brahmin',''),(651,1,'Pushkarna Brahmin',''),(652,1,'Rarhi Brahmin',''),(653,1,'Rigvedi Brahmin',''),(654,1,'Rudraj Brahmin',''),(655,1,'Sakaldwipi Brahmin',''),(656,1,'Sanadya Brahmin',''),(657,1,'Sanketi Brahmin',''),(658,1,'Saraswat Brahmin',''),(659,1,'Saryuparin Brahmin',''),(660,1,'Shivhalli Brahmin',''),(661,1,'Shrimali Brahmin',''),(662,1,'Sikhwal Brahmin',''),(663,1,'Sri Vaishnava Brahmin',''),(664,1,'Stanika Brahmin',''),(665,1,'Tyagi Brahmin',''),(666,1,'Vaidiki Brahmin',''),(667,1,'Vaikhanasa Brahmin',''),(668,1,'Velanadu Brahmin',''),(669,1,'Vyas Brahmin',''),(670,1,'Shetty',''),(671,1,'Mera',''),(672,1,'Mukkulathor',''),(673,1,'Paswan',''),(674,1,'Jeer',''),(675,1,'Bramhin Jijhotia',''),(676,1,'Nath',''),(677,1,'Koiri',''),(678,1,'Bramhin Malviya',''),(679,1,'Darji',''),(680,1,'Amil Sindhi',''),(681,1,'Baidhand Sindhi',''),(682,1,'Bhanusali Sindhi',''),(683,1,'Bhatia Sindhi',''),(684,1,'Chhapru Sindhi',''),(685,1,'Sadu Sindhi',''),(686,1,'Hyderabadi Sindhi',''),(687,1,'Larai Sindhi',''),(688,1,'Larkana Sindhi',''),(689,1,'Lohana Sindhi',''),(690,1,'Rohiri Sindhi',''),(691,1,'Sahiti Sindhi',''),(692,1,'Sakkhar Sindhi',''),(693,1,'Sehwani Sindhi',''),(694,1,'Shikarpuri Sindhi',''),(695,1,'Thatai Sindhi',''),(696,1,'Naika',''),(697,1,'Don\'t wish to specify',''),(698,14,'Aaru Nattu Vellala',''),(699,14,'Ad Dharmi',''),(700,14,'Adi Andhra',''),(701,14,'Adi Dravidar',''),(702,14,'Adi Karnataka',''),(703,14,'Agamudayar/Arcot/Thuluva Vellala',''),(704,14,'Agaram Vellan Chettiar',''),(705,14,'Agarwal',''),(706,14,'Agnikula Kshatriya',''),(707,14,'Agrahari',''),(708,14,'Agri',''),(709,14,'Ahir Shimpi',''),(710,14,'Ahirwar',''),(711,14,'Ahom',''),(712,14,'Ambalavasi',''),(713,14,'Anjana (Chowdary)Patel',''),(714,14,'Aramari / Gabit',''),(715,14,'Arekatica',''),(716,14,'Arora',''),(717,14,'Arunthathiyar',''),(718,14,'Arya Vysya',''),(719,14,'Asathi',''),(720,14,'Ayira Vysya',''),(721,14,'Ayodhyavasi',''),(722,14,'Ayyaraka',''),(723,14,'Budaga',''),(724,14,'Bagdi',''),(725,14,'Baidya',''),(726,14,'Bairwa',''),(727,14,'Baishbnab',''),(728,14,'Baishya',''),(729,14,'Bajantri',''),(730,14,'Balai',''),(731,14,'Balija',''),(732,14,'Balija Naidu',''),(733,14,'Balija Reddy',''),(734,14,'Banayat Oriya',''),(735,14,'Banik',''),(736,14,'Baniya',''),(737,14,'Baniya - Bania',''),(738,14,'Baniya - KUmuti',''),(739,14,'Banjara',''),(740,14,'Barai',''),(741,14,'Barnwal',''),(742,14,'Barujibi',''),(743,14,'Beri Chettiar',''),(744,14,'Besta',''),(745,14,'Bhandari',''),(746,14,'Bhaia',''),(747,14,'Bhatraju',''),(748,14,'Bhavasar Vshatriya',''),(749,14,'Bhoi',''),(750,14,'Bhovi',''),(751,14,'Bhoyar',''),(752,14,'Billava',''),(753,14,'Bishnoi / Vishnoi',''),(754,14,'Bondili',''),(755,14,'Born Again',''),(756,14,'Boyar',''),(757,14,'Brahmbatt',''),(758,14,'Brahmin - Anavil',''),(759,14,'Brahmin - Anaviln Desai',''),(760,14,'Brahmin - Audichya',''),(761,14,'Brahmin - Baidhiki / Vaidhiki',''),(762,14,'Brahmin - Bardai',''),(763,14,'Brahmin - Barendra',''),(764,14,'Brahmin - Bhargav',''),(765,14,'Brahmin - Bhatt',''),(766,14,'Brahmin - Bhumihar',''),(767,14,'Brahmin - Dadhich',''),(768,14,'Brahmin - Daivadnya',''),(769,14,'Brahmin - Danua',''),(770,14,'Brahmin - Deshastha',''),(771,14,'Brahmin - Dhiman',''),(772,14,'Brahmin - Dravida',''),(773,14,'Brahmin - Embrandiri',''),(774,14,'Brahmin - Garhwali',''),(775,14,'Brahmin - Gaur',''),(776,14,'Brahmin - Goswami / Gosavi',''),(777,14,'Brahmin - Gujar Gaur',''),(778,14,'Brahmin - Gurakkal',''),(779,14,'Brahmin - Halua',''),(780,14,'Brahmin - Havyaka',''),(781,14,'Brahmin - Hoysala',''),(782,14,'Brahmin - Iyengar',''),(783,14,'Brahmin - Iyer',''),(784,14,'Brahmin - Jabgid',''),(785,14,'Brahmin - Jhadua',''),(786,14,'Brahmin - Jyotish',''),(787,14,'Brahmin - Kanyakubi',''),(788,14,'Brahmin - Karhade',''),(789,14,'Brahmin - Khadayata',''),(790,14,'Brahmin - Khandelwal',''),(791,14,'Brahmin - Khedaval',''),(792,14,'Brahmin - Kokanastha',''),(793,14,'Brahmin - Kota',''),(794,14,'Brahmin - Koteshwara /Kota(Madhwa)',''),(795,14,'Brahmin - Kulin',''),(796,14,'Brahmin - Kumaoni',''),(797,14,'Brahmin - Madhwa',''),(798,14,'Brahmin - Maithil',''),(799,14,'Brahmin - Meveda',''),(800,14,'Brahmin - Modh',''),(801,14,'Brahmin - Mohyal',''),(802,14,'Brahmin - Nagar',''),(803,14,'Brahmin - Namboodiri',''),(804,14,'Brahmin - Narmadiya',''),(805,14,'Brahmin - Niyogi',''),(806,14,'Brahmin - Others',''),(807,14,'Brahmin - Paliwal',''),(808,14,'Brahmin - Panda',''),(809,14,'Brahmin - Pandit',''),(810,14,'Brahmin - Panicker',''),(811,14,'Brahmin - Pareek',''),(812,14,'Brahmin - Pushkarna',''),(813,14,'Brahmin - Rajgor',''),(814,14,'Brahmin - Rarhi',''),(815,14,'Brahmin - Rarhi /Radhi',''),(816,14,'Brahmin - Rigvedi',''),(817,14,'Brahmin - Rudraj',''),(818,14,'Brahmin - Sakaldwipi',''),(819,14,'Brahmin - Sanadya',''),(820,14,'Brahmin - Sanketi',''),(821,14,'Brahmin - Saraswat',''),(822,14,'Brahmin - Sarua',''),(823,14,'Brahmin - Saeyuparin',''),(824,14,'Brahmin - Shivalli (Madhva)',''),(825,14,'Brahmin - Shivhalli',''),(826,14,'Brahmin - Shri Gaud',''),(827,14,'Brahmin - Shri Mali',''),(828,14,'Brahmin - Shrimali',''),(829,14,'Brahmin - Shukla Yajurvedi',''),(830,14,'Brahmin - Sikhwal',''),(831,14,'Brahmin - Smartha',''),(832,14,'Brahmin - Sri Vaishnava',''),(833,14,'Brahmin - Stanila',''),(834,14,'Brahmin - Tapodhan',''),(835,14,'Brahmin - Tyagi',''),(836,14,'Brahmin - Vaidiki',''),(837,14,'Brahmin - Vaikhanasa',''),(838,14,'Brahmin - Valam',''),(839,14,'Brahmin - Velanadu',''),(840,14,'Brahmin - Vyas',''),(841,14,'Brahmin - Zalora',''),(842,14,'Brajastha Maithil',''),(843,14,'Bunt (Shetty)',''),(844,14,'CKP',''),(845,14,'Chalawadi and Holeya',''),(846,14,'Chambhar',''),(847,14,'Chandravanishi Kahar',''),(848,14,'Chasa',''),(849,14,'Chattada Sri Vaishnava',''),(850,14,'Chaturth',''),(851,14,'Chaudary',''),(852,14,'Chaurasia',''),(853,14,'Chennadasar',''),(854,14,'Cjerukula Vellalar',''),(855,14,'Chettiar',''),(856,14,'Chhetri',''),(857,14,'Chippolu(Mera)',''),(858,14,'Choudary',''),(859,14,'Coorgi',''),(860,14,'Deshmukh',''),(861,14,'Desikar',''),(862,14,'Desikar Thanjuvur',''),(863,14,'Devadiga',''),(864,14,'Devandra Kula Vellalar',''),(865,14,'Devang Koshthi',''),(866,14,'Devanga',''),(867,14,'Devanga Chettiar',''),(868,14,'Devar / Thevar /Mukkulathor',''),(869,14,'Devrukhe Brahmin',''),(870,14,'Dhanak',''),(871,14,'Dhangar',''),(872,14,'Dheevara',''),(873,14,'Dhiman',''),(874,14,'Dhobi',''),(875,14,'Dhor /Dusra',''),(876,14,'Dumal',''),(877,14,'Dusadh (Paswan)',''),(878,14,'Ediga',''),(879,14,'Ediga / Goud (Balija)',''),(880,14,'Elur Chetty',''),(881,14,'Ezhava',''),(882,14,'Ezhava Panciker',''),(883,14,'Ezhava Thandan',''),(884,14,'Ezhuthachan',''),(885,14,'Gabit',''),(886,14,'Gahoi',''),(887,14,'Gajula / Kavarai',''),(888,14,'Ganda',''),(889,14,'Gandha Vanika',''),(890,14,'Gandla',''),(891,14,'Gandla / Ganiga',''),(892,14,'Ganiga',''),(893,14,'Garhwall',''),(894,14,'Gatti',''),(895,14,'Gavara',''),(896,14,'Gawali',''),(897,14,'Ghisadi',''),(898,14,'Ghumar',''),(899,14,'Goala',''),(900,14,'Goan',''),(901,14,'Gomantak',''),(902,14,'Gondhali',''),(903,14,'Goud',''),(904,14,'Gounder',''),(905,14,'Gounder - Kongu Vellala Gounder',''),(906,14,'Gounder - Nattu Guunder',''),(907,14,'Gounder - Others',''),(908,14,'Gounder - Urali Gounder',''),(909,14,'Gounder - Vanniya Kula Kshatriyar',''),(910,14,'Gounder - Vettuva Gounder',''),(911,14,'Gowda',''),(912,14,'Gowda - Kuruba gowda',''),(913,14,'Gramani',''),(914,14,'Gudia',''),(915,14,'Gujjar',''),(916,14,'Gulahre',''),(917,14,'Gupta',''),(918,14,'Guptan',''),(919,14,'Gurav',''),(920,14,'Gurjar',''),(921,14,'Haihavanshi',''),(922,14,'Halba Koshti',''),(923,14,'Helava',''),(924,14,'Hugar(Jeer)',''),(925,14,'IIIaththu Pillai',''),(926,14,'Intercaste',''),(927,14,'Irani',''),(928,14,'Isai Vellalar',''),(929,14,'Jaalari',''),(930,14,'Jaiswal',''),(931,14,'Jandra',''),(932,14,'Jangam',''),(933,14,'Jangra - Brahmin',''),(934,14,'Jat',''),(935,14,'Jatav',''),(936,14,'Jetty / Malla',''),(937,14,'Jhadav',''),(938,14,'Jijhotia Brahmin',''),(939,14,'Jogi (Nath)',''),(940,14,'Julaha',''),(941,14,'Kachara',''),(942,14,'Kadava Patel',''),(943,14,'Kaibarta',''),(944,14,'Kaikaala',''),(945,14,'Kalal',''),(946,14,'Kalanji',''),(947,14,'Kalar',''),(948,14,'Kalinga',''),(949,14,'Kalinga Vysya',''),(950,14,'Kalita',''),(951,14,'Kalwar',''),(952,14,'Kamboj',''),(953,14,'Kamma',''),(954,14,'Kamma Naidu',''),(955,14,'Kanakkan Padanna',''),(956,14,'Kandara',''),(957,14,'Kanasari',''),(958,14,'Kanykubj Bania',''),(959,1,'Kapu',''),(960,1,'Kapu Naidu',''),(961,1,'Kapu Reddy',''),(962,14,'Karakala Bhakthula',''),(963,14,'Karana',''),(964,14,'Karkathar',''),(965,14,'Karmakar',''),(966,14,'Karani Bhakthula',''),(967,14,'Karuneegar',''),(968,14,'Kasar',''),(969,14,'Kasaundhan',''),(970,14,'Kashyap',''),(971,14,'Kasukara',''),(972,14,'Katiya',''),(973,14,'Kavara',''),(974,14,'Kavuthiyya / Ezhavathy',''),(975,14,'Kayastha',''),(976,14,'Kayastha (Bengali)',''),(977,14,'Kerala Mudali',''),(978,14,'Keshri (Kesarwani)',''),(979,14,'Khandayat',''),(980,14,'Khandelwal',''),(981,14,'Kharwa',''),(982,14,'Kharwar',''),(983,14,'Khatik',''),(984,14,'Khatri',''),(985,14,'Kirar',''),(986,14,'Kodikal Pillai',''),(987,14,'Kokanastha Maratha',''),(988,14,'Koli',''),(989,14,'Koli Madhadev',''),(990,14,'Koli Patel',''),(991,14,'Komati / Arya Vaishya',''),(992,14,'Kongu Chettiar',''),(993,14,'Kongu Nadar',''),(994,14,'Kongu Vellala Gounder',''),(995,14,'Konkani',''),(996,14,'Korama',''),(997,14,'Kori',''),(998,14,'Kori / Koli',''),(999,14,'Kosthi',''),(1000,14,'Krishnavaka',''),(1001,14,'Kshatriya',''),(1002,14,'Kshatriya Kurmi',''),(1003,14,'Kshatriya Raju',''),(1004,14,'Kudumbi',''),(1005,14,'Kulal',''),(1006,14,'Kulalar',''),(1007,14,'Kilita',''),(1008,14,'Kumaoni Rajput',''),(1009,14,'Kumawat',''),(1010,14,'Kumbhakar',''),(1011,14,'Kumbhar',''),(1012,14,'Kumhar',''),(1013,14,'Kummari',''),(1014,14,'Kunbi',''),(1015,14,'Kunbi Lonari',''),(1016,14,'Kunbi Maratha',''),(1017,14,'Kunbi Tirale',''),(1018,14,'Kuravan',''),(1019,14,'Kurmi',''),(1020,14,'Kurmi / Kurmi Kshatriya',''),(1021,14,'Kurni',''),(1022,14,'Kuruba',''),(1023,14,'Kuruhina Shetty',''),(1024,14,'Kuruhini CHetty',''),(1025,14,'Kurumbar',''),(1026,14,'Kuruva',''),(1027,14,'Kushwaha (Koiri)',''),(1028,14,'Kurchi',''),(1029,14,'Lad',''),(1030,14,'Lambadi',''),(1031,14,'Leva patel',''),(1032,14,'Linga Balija',''),(1033,14,'Lingayath',''),(1034,14,'Lodhi Rajput',''),(1035,14,'Lohana',''),(1036,14,'Lohar',''),(1037,14,'Loniya',''),(1038,14,'Lubana',''),(1039,14,'Madhesiya / Kani / Halwai',''),(1040,14,'Madiga',''),(1041,14,'Mahakan',''),(1042,14,'Mahar',''),(1043,14,'Mahendra',''),(1044,14,'Maheswari',''),(1045,14,'Maheswari / Meshri',''),(1046,14,'Mahishya',''),(1047,14,'Mahor',''),(1048,14,'Mahuri',''),(1049,14,'Mair Rajput Swarnkar',''),(1050,14,'Majabi',''),(1051,14,'Mala',''),(1052,14,'Mali',''),(1053,14,'Mallah',''),(1054,14,'Malviya Bramhim',''),(1055,14,'Malwani',''),(1056,14,'Mangalorean',''),(1057,14,'Manipuri',''),(1058,14,'Manjapidur Chettiar',''),(1059,14,'Mannan / Velan / Vannan',''),(1060,14,'Mapila',''),(1061,14,'Maratha',''),(1062,14,'Maratha Kshatriya',''),(1063,14,'Maruthuvar',''),(1064,14,'Matang',''),(1065,14,'Mathur',''),(1066,14,'Mathur Vaishya',''),(1067,14,'Maurya / Shakya',''),(1068,14,'Meena',''),(1069,14,'Meenavar',''),(1070,14,'Meghwal',''),(1071,14,'Mehra',''),(1072,14,'Meru Darji',''),(1073,14,'Mochi',''),(1074,14,'Medak',''),(1075,14,'Modi',''),(1076,14,'Modikarlu',''),(1077,14,'Mogaveera',''),(1078,14,'Mudaliyar',''),(1079,14,'Mudiraj',''),(1080,1,'Munnuru Kapu',''),(1081,14,'Musukama',''),(1082,14,'Muthuraja',''),(1083,14,'Naagavamsam',''),(1084,14,'Nabit',''),(1085,14,'Nadar',''),(1086,14,'Nagaralu',''),(1087,14,'Nai',''),(1088,14,'Naicker',''),(1089,14,'Naicker - Others',''),(1090,14,'Naicker - Vanniya Kula Kshatriyar',''),(1091,14,'Naidu',''),(1092,14,'Naik',''),(1093,14,'Nair',''),(1094,14,'Namasudra / Namaseej',''),(1095,14,'Namniar',''),(1096,14,'Namdarlu',''),(1097,14,'Nanjil Mudali',''),(1098,14,'Nanjil Nattu Vellalar',''),(1099,14,'Nanjil Vellalar',''),(1100,14,'Nanjil Pillai',''),(1101,14,'Nankudi Vellalar',''),(1102,14,'Napit',''),(1103,14,'Nattu Gounder',''),(1104,14,'Nattukottai Chettiar',''),(1105,14,'Nayaka',''),(1106,14,'Neeli',''),(1107,14,'Neeli Saali',''),(1108,14,'Nema',''),(1109,14,'Nepali',''),(1110,14,'Nessi',''),(1111,14,'Nhavi',''),(1112,14,'Ontari',''),(1113,14,'Oswal',''),(1114,14,'Otari',''),(1115,14,'Othuvaar',''),(1116,14,'Padmasali',''),(1117,14,'Padmashali',''),(1118,14,'Padmavathi Porwal',''),(1119,14,'Pagadala',''),(1120,14,'Pal',''),(1121,14,'Pallan / Devandra Kula Vellalan',''),(1122,14,'Panan',''),(1123,14,'Panchal',''),(1124,14,'Pandaram',''),(1125,14,'Pandiya Vellalar',''),(1126,14,'Panicker',''),(1127,14,'Pannirandam Chettiar',''),(1128,14,'Paravan / Bharatar',''),(1129,14,'Parit',''),(1130,14,'Parkava Kulam',''),(1131,14,'Parsi',''),(1132,14,'Partraj',''),(1133,14,'Parvatha Rajakulam',''),(1134,14,'Pasi',''),(1135,14,'Paswan / Dusadh',''),(1136,14,'Patel',''),(1137,14,'Pathare Prabhu',''),(1138,14,'Patil',''),(1139,14,'Patnick / Sistakaranam',''),(1140,14,'Patra',''),(1141,14,'Pattinavar',''),(1142,14,'Pattusali',''),(1143,14,'Patwa',''),(1144,14,'Perika',''),(1145,14,'Perika / Puragiri Kshatriya',''),(1146,14,'Pillai',''),(1147,14,'Poosala',''),(1148,14,'Porwal',''),(1149,14,'Porwal / Porwar',''),(1150,14,'Poundra',''),(1151,14,'Prajapati',''),(1152,14,'Pulaya / Cheruman',''),(1153,14,'Raigar',''),(1154,14,'Rajaka',''),(1155,14,'Rajastani',''),(1156,14,'Rajbhar',''),(1157,14,'Rajbonshi',''),(1158,14,'Rajpurohot',''),(1159,14,'Rajput',''),(1160,14,'Ramanandi',''),(1161,14,'Ramdasia',''),(1162,14,'Ramgariah',''),(1163,14,'Ramoshi',''),(1164,14,'Rastogi',''),(1165,14,'Rathi',''),(1166,14,'Rauniar',''),(1167,14,'Ravidaisia',''),(1168,14,'Rawat',''),(1169,14,'Reddy',''),(1170,14,'Relli',''),(1171,14,'Ronit / Chamar',''),(1172,14,'Ror',''),(1173,14,'SC',''),(1174,14,'SKP',''),(1175,14,'ST',''),(1176,14,'Sadgope',''),(1177,14,'Sadhi Chetty',''),(1178,14,'Sagara (Uppara)',''),(1179,14,'Saha',''),(1180,14,'Sahu',''),(1181,14,'Saini',''),(1182,14,'Saiva Pillai Thanjavur',''),(1183,14,'Saiva Pillai Tirunelveli',''),(1184,14,'Saliya',''),(1185,14,'Samagar',''),(1186,14,'Sambava',''),(1187,14,'Sathwara',''),(1188,14,'Satnami',''),(1189,14,'Savji',''),(1190,14,'Senai Thalaivar',''),(1191,14,'Senguntha Mudiliyar',''),(1192,14,'Sengunthar / Kaikolar',''),(1193,14,'Settibalija',''),(1194,14,'Setty Balija',''),(1195,14,'Shaw / Sahu / Teli',''),(1196,14,'Shettigar',''),(1197,14,'Shipkar',''),(1198,14,'Shimpi/ Namdev',''),(1199,14,'Sindhi',''),(1200,14,'Sindhi-Amil',''),(1201,14,'Sindhi-Baibhand',''),(1202,14,'Sindhi-Bhanusali',''),(1203,14,'Sindhi-Bhatia',''),(1204,14,'Sindhi-Chhapru',''),(1205,14,'Sindhi-Dadu',''),(1206,14,'Sindhi-Hyderabadi',''),(1207,14,'Sindhi-Larai',''),(1208,14,'Sindhi-Larkana',''),(1209,14,'Sindhi-Lohana',''),(1210,14,'Sindhi-Rohiri',''),(1211,14,'Sindhi-Sahiti',''),(1212,14,'Sindhi-Sakkhar',''),(1213,14,'Sindhi-Sehwani',''),(1214,14,'Sindhi-Shikarpuri',''),(1215,14,'Sindhi-Thatai',''),(1216,14,'Sonar',''),(1217,14,'Soni',''),(1218,14,'Sonkar',''),(1219,14,'Sourashtra',''),(1220,14,'Sozhia Chetty',''),(1221,14,'Sozhiya Vellalar',''),(1222,14,'Srisayana',''),(1223,14,'Sugali (Naika)',''),(1224,14,'Sunari',''),(1225,14,'Sundhi',''),(1226,14,'Surya Balija',''),(1227,14,'Suthar',''),(1228,14,'Swakula Sali',''),(1229,14,'Tamboli',''),(1230,14,'Tanti',''),(1231,14,'Tantubai',''),(1232,14,'Telaga',''),(1233,14,'Teli',''),(1234,14,'Telugupatti',''),(1235,14,'Thakkar',''),(1236,14,'Thakore',''),(1237,14,'Thakur',''),(1238,14,'Thandan',''),(1239,14,'Thigala',''),(1240,14,'Thiyya',''),(1241,14,'Thiyya Thandan',''),(1242,14,'Thogata Veera Kshatriya',''),(1243,14,'Thogata Veerakshathriya',''),(1244,14,'Thondai Mandala Vellalar',''),(1245,14,'Thota',''),(1246,14,'Tili',''),(1247,14,'Togata',''),(1248,14,'Tonk Kshatriya',''),(1249,1,'Turupu Kapu',''),(1250,14,'Ummar / Umre / Bagaria',''),(1251,14,'Urali Gounder',''),(1252,14,'Urs',''),(1253,14,'Vada Baliji',''),(1254,14,'Vasambar',''),(1255,14,'Vaddera',''),(1256,14,'Vadugan',''),(1257,14,'Vaish',''),(1258,14,'Vaishnav',''),(1259,14,'Vaishanav Dishaval',''),(1260,14,'Vaishanav Khadyata',''),(1261,14,'Vaishanav Lad',''),(1262,14,'Vaishanav Modh',''),(1263,14,'Vaishanav Porvas',''),(1264,14,'Vaishanav Shrimali',''),(1265,14,'Vaishanav Sorathaiya',''),(1266,14,'Vaishanav Vania',''),(1267,14,'Vaishanav',''),(1268,14,'Vaishya',''),(1269,14,'Vaishya Vani',''),(1270,14,'Vallivan',''),(1271,14,'Vakmiki',''),(1272,14,'Vani',''),(1273,14,'Vani / Vaishya',''),(1274,14,'Vania',''),(1275,14,'Vanika Vyshaya',''),(1276,14,'Vaniya',''),(1277,14,'Vaniya Chettiar',''),(1278,14,'Vanjara',''),(1279,14,'Vanjari',''),(1280,14,'Vankar',''),(1281,14,'Vannar',''),(1282,14,'Vannia Kula Lshatriyar',''),(1283,14,'Variar',''),(1284,14,'Varshney',''),(1285,14,'Varsjney (Baraseni)',''),(1286,14,'Veera Shivam',''),(1287,14,'Veerakodi Vellala',''),(1288,14,'Velaan',''),(1289,14,'Velama',''),(1290,14,'Vellalar',''),(1291,14,'Vellan Chettiars',''),(1292,14,'Veluthedathu Nair',''),(1293,14,'Vettuva Gounder',''),(1294,14,'Vettuvan',''),(1295,14,'Vijayvargia',''),(1296,14,'Vilakithala Nair',''),(1297,14,'Vilakkithala Nair',''),(1298,14,'Vishwakarma',''),(1299,14,'Viswabramhin',''),(1300,14,'Vokkaliga',''),(1301,14,'Vysya',''),(1302,14,'Yadav',''),(1303,14,'Yadav Naidu',''),(1304,14,'Yellapu',''),(1305,14,'Other Caste',''),(1306,14,'Don\'t wish to Specify',''),(1307,14,'Avavil Bramhin',''),(1308,14,'Audichya Brahmin',''),(1309,14,'Barendra Brahmin',''),(1310,14,'Bharr Brahmin',''),(1311,14,'Bhatt Brahmin',''),(1312,14,'Bhumihar Brahmin',''),(1313,14,'Daivadnya Brahmin',''),(1314,14,'Danua Brahmin',''),(1315,14,'Deshasthu Brahmin',''),(1316,14,'Dhiman Brahmin',''),(1317,14,'Dravida Brahmin',''),(1318,14,'Embrandiri Brahmin',''),(1319,14,'Gaur Brahmin',''),(1320,14,'Goswami / Gosavi Brahmin',''),(1321,14,'Gujar Guar Brahmin',''),(1322,14,'Gurukkal Brahmin',''),(1323,14,'Havyaka Brahmin',''),(1324,14,'Hoysala Brahmin',''),(1325,14,'Iyengar Brahmin',''),(1326,14,'Iyer Brahmin',''),(1327,14,'Jangid Brahmin',''),(1328,14,'Jangid Brahmin',''),(1329,14,'Jhadua Brahmin',''),(1330,14,'Janyajubi Brahmin',''),(1331,14,'Kanyakubj Brahmin',''),(1332,14,'Karhade Brahmin',''),(1333,14,'Kokanastha Brahmin',''),(1334,14,'Kota Brahmin',''),(1335,14,'Kulin Brahmin',''),(1336,14,'Kumaoni Brahmin',''),(1337,14,'Madhwa Brahmin',''),(1338,14,'Maithil Brahmin',''),(1339,14,'Modh Brahmin',''),(1340,14,'Mohyal Brahmin',''),(1341,14,'Nagar Brahmin',''),(1342,14,'Namboodiri Brahmin',''),(1343,14,'Barmaduya Brahmin',''),(1344,14,'Niyogi Brahmin',''),(1345,14,'Panda Brahmin',''),(1346,14,'Pandit Brahmin',''),(1347,14,'Pushkarna Brahmin',''),(1348,14,'Pushkarna Brahmin',''),(1349,14,'Rarhi Brahmin',''),(1350,14,'Rigvedi Brahmin',''),(1351,14,'Rudraj Brahmin',''),(1352,14,'Sakaldwipi Brahmin',''),(1353,14,'Sanadya Brahmin',''),(1354,14,'Sanketi Brahmin',''),(1355,14,'Saraswat Brahmin',''),(1356,14,'Saryuparin Brahmin',''),(1357,14,'Shivhalli Brahmin',''),(1358,14,'Shrimali Brahmin',''),(1359,14,'Sikhwal Brahmin',''),(1360,14,'Sri Vaishnava Brahmin',''),(1361,14,'Stanika Brahmin',''),(1362,14,'Tyagi Brahmin',''),(1363,14,'Vaidiki Brahmin',''),(1364,14,'Vaikhanasa Brahmin',''),(1365,14,'Velanadu Brahmin',''),(1366,14,'Vyas Brahmin',''),(1367,14,'Shetty',''),(1368,14,'Mera',''),(1369,14,'Mukkulathor',''),(1370,14,'Paswan',''),(1371,14,'Jeer',''),(1372,14,'Bramhin Jijhotia',''),(1373,14,'Nath',''),(1374,14,'Koiri',''),(1375,14,'Bramhin Malviya',''),(1376,14,'Darji',''),(1377,14,'Amil Sindhi',''),(1378,14,'Baidhand Sindhi',''),(1379,14,'Bhanusali Sindhi',''),(1380,14,'Bhatia Sindhi',''),(1381,14,'Chhapru Sindhi',''),(1382,14,'Sadu Sindhi',''),(1383,14,'Hyderabadi Sindhi',''),(1384,14,'Larai Sindhi',''),(1385,14,'Larkana Sindhi',''),(1386,14,'Lohana Sindhi',''),(1387,14,'Rohiri Sindhi',''),(1388,14,'Sahiti Sindhi',''),(1389,14,'Sakkhar Sindhi',''),(1390,14,'Sehwani Sindhi',''),(1391,14,'Shikarpuri Sindhi',''),(1392,14,'Thatai Sindhi',''),(1393,14,'Naika',''),(1394,14,'Don\'t wish to specify',''),(1395,3,'Aaru Nattu Vellala',''),(1396,3,'Ad Dharmi',''),(1397,3,'Adi Andhra',''),(1398,3,'Adi Dravidar',''),(1399,3,'Adi Karnataka',''),(1400,3,'Agamudayar/Arcot/Thuluva Vellala',''),(1401,3,'Agaram Vellan Chettiar',''),(1402,3,'Agarwal',''),(1403,3,'Agnikula Kshatriya',''),(1404,3,'Agrahari',''),(1405,3,'Agri',''),(1406,3,'Ahir Shimpi',''),(1407,3,'Ahirwar',''),(1408,3,'Ahom',''),(1409,3,'Ambalavasi',''),(1410,3,'Anjana (Chowdary)Patel',''),(1411,3,'Aramari / Gabit',''),(1412,3,'Arekatica',''),(1413,3,'Arora',''),(1414,3,'Arunthathiyar',''),(1415,3,'Arya Vysya',''),(1416,3,'Asathi',''),(1417,3,'Ayira Vysya',''),(1418,3,'Ayodhyavasi',''),(1419,3,'Ayyaraka',''),(1420,3,'Budaga',''),(1421,3,'Bagdi',''),(1422,3,'Baidya',''),(1423,3,'Bairwa',''),(1424,3,'Baishbnab',''),(1425,3,'Baishya',''),(1426,3,'Bajantri',''),(1427,3,'Balai',''),(1428,3,'Balija',''),(1429,3,'Balija Naidu',''),(1430,3,'Balija Reddy',''),(1431,3,'Banayat Oriya',''),(1432,3,'Banik',''),(1433,3,'Baniya',''),(1434,3,'Baniya - Bania',''),(1435,3,'Baniya - KUmuti',''),(1436,3,'Banjara',''),(1437,3,'Barai',''),(1438,3,'Barnwal',''),(1439,3,'Barujibi',''),(1440,3,'Beri Chettiar',''),(1441,3,'Besta',''),(1442,3,'Bhandari',''),(1443,3,'Bhaia',''),(1444,3,'Bhatraju',''),(1445,3,'Bhavasar Vshatriya',''),(1446,3,'Bhoi',''),(1447,3,'Bhovi',''),(1448,3,'Bhoyar',''),(1449,3,'Billava',''),(1450,3,'Bishnoi / Vishnoi',''),(1451,3,'Bondili',''),(1452,3,'Born Again',''),(1453,3,'Boyar',''),(1454,3,'Brahmbatt',''),(1455,3,'Brahmin - Anavil',''),(1456,3,'Brahmin - Anaviln Desai',''),(1457,3,'Brahmin - Audichya',''),(1458,3,'Brahmin - Baidhiki / Vaidhiki',''),(1459,3,'Brahmin - Bardai',''),(1460,3,'Brahmin - Barendra',''),(1461,3,'Brahmin - Bhargav',''),(1462,3,'Brahmin - Bhatt',''),(1463,3,'Brahmin - Bhumihar',''),(1464,3,'Brahmin - Dadhich',''),(1465,3,'Brahmin - Daivadnya',''),(1466,3,'Brahmin - Danua',''),(1467,3,'Brahmin - Deshastha',''),(1468,3,'Brahmin - Dhiman',''),(1469,3,'Brahmin - Dravida',''),(1470,3,'Brahmin - Embrandiri',''),(1471,3,'Brahmin - Garhwali',''),(1472,3,'Brahmin - Gaur',''),(1473,3,'Brahmin - Goswami / Gosavi',''),(1474,3,'Brahmin - Gujar Gaur',''),(1475,3,'Brahmin - Gurakkal',''),(1476,3,'Brahmin - Halua',''),(1477,3,'Brahmin - Havyaka',''),(1478,3,'Brahmin - Hoysala',''),(1479,3,'Brahmin - Iyengar',''),(1480,3,'Brahmin - Iyer',''),(1481,3,'Brahmin - Jabgid',''),(1482,3,'Brahmin - Jhadua',''),(1483,3,'Brahmin - Jyotish',''),(1484,3,'Brahmin - Kanyakubi',''),(1485,3,'Brahmin - Karhade',''),(1486,3,'Brahmin - Khadayata',''),(1487,3,'Brahmin - Khandelwal',''),(1488,3,'Brahmin - Khedaval',''),(1489,3,'Brahmin - Kokanastha',''),(1490,3,'Brahmin - Kota',''),(1491,3,'Brahmin - Koteshwara /Kota(Madhwa)',''),(1492,3,'Brahmin - Kulin',''),(1493,3,'Brahmin - Kumaoni',''),(1494,3,'Brahmin - Madhwa',''),(1495,3,'Brahmin - Maithil',''),(1496,3,'Brahmin - Meveda',''),(1497,3,'Brahmin - Modh',''),(1498,3,'Brahmin - Mohyal',''),(1499,3,'Brahmin - Nagar',''),(1500,3,'Brahmin - Namboodiri',''),(1501,3,'Brahmin - Narmadiya',''),(1502,3,'Brahmin - Niyogi',''),(1503,3,'Brahmin - Others',''),(1504,3,'Brahmin - Paliwal',''),(1505,3,'Brahmin - Panda',''),(1506,3,'Brahmin - Pandit',''),(1507,3,'Brahmin - Panicker',''),(1508,3,'Brahmin - Pareek',''),(1509,3,'Brahmin - Pushkarna',''),(1510,3,'Brahmin - Rajgor',''),(1511,3,'Brahmin - Rarhi',''),(1512,3,'Brahmin - Rarhi /Radhi',''),(1513,3,'Brahmin - Rigvedi',''),(1514,3,'Brahmin - Rudraj',''),(1515,3,'Brahmin - Sakaldwipi',''),(1516,3,'Brahmin - Sanadya',''),(1517,3,'Brahmin - Sanketi',''),(1518,3,'Brahmin - Saraswat',''),(1519,3,'Brahmin - Sarua',''),(1520,3,'Brahmin - Saeyuparin',''),(1521,3,'Brahmin - Shivalli (Madhva)',''),(1522,3,'Brahmin - Shivhalli',''),(1523,3,'Brahmin - Shri Gaud',''),(1524,3,'Brahmin - Shri Mali',''),(1525,3,'Brahmin - Shrimali',''),(1526,3,'Brahmin - Shukla Yajurvedi',''),(1527,3,'Brahmin - Sikhwal',''),(1528,3,'Brahmin - Smartha',''),(1529,3,'Brahmin - Sri Vaishnava',''),(1530,3,'Brahmin - Stanila',''),(1531,3,'Brahmin - Tapodhan',''),(1532,3,'Brahmin - Tyagi',''),(1533,3,'Brahmin - Vaidiki',''),(1534,3,'Brahmin - Vaikhanasa',''),(1535,3,'Brahmin - Valam',''),(1536,3,'Brahmin - Velanadu',''),(1537,3,'Brahmin - Vyas',''),(1538,3,'Brahmin - Zalora',''),(1539,3,'Brajastha Maithil',''),(1540,3,'Bunt (Shetty)',''),(1541,3,'CKP',''),(1542,3,'Chalawadi and Holeya',''),(1543,3,'Chambhar',''),(1544,3,'Chandravanishi Kahar',''),(1545,3,'Chasa',''),(1546,3,'Chattada Sri Vaishnava',''),(1547,3,'Chaturth',''),(1548,3,'Chaudary',''),(1549,3,'Chaurasia',''),(1550,3,'Chennadasar',''),(1551,3,'Cjerukula Vellalar',''),(1552,3,'Chettiar',''),(1553,3,'Chhetri',''),(1554,3,'Chippolu(Mera)',''),(1555,3,'Choudary',''),(1556,3,'Coorgi',''),(1557,3,'Deshmukh',''),(1558,3,'Desikar',''),(1559,3,'Desikar Thanjuvur',''),(1560,3,'Devadiga',''),(1561,3,'Devandra Kula Vellalar',''),(1562,3,'Devang Koshthi',''),(1563,3,'Devanga',''),(1564,3,'Devanga Chettiar',''),(1565,3,'Devar / Thevar /Mukkulathor',''),(1566,3,'Devrukhe Brahmin',''),(1567,3,'Dhanak',''),(1568,3,'Dhangar',''),(1569,3,'Dheevara',''),(1570,3,'Dhiman',''),(1571,3,'Dhobi',''),(1572,3,'Dhor /Dusra',''),(1573,3,'Dumal',''),(1574,3,'Dusadh (Paswan)',''),(1575,3,'Ediga',''),(1576,3,'Ediga / Goud (Balija)',''),(1577,3,'Elur Chetty',''),(1578,3,'Ezhava',''),(1579,3,'Ezhava Panciker',''),(1580,3,'Ezhava Thandan',''),(1581,3,'Ezhuthachan',''),(1582,3,'Gabit',''),(1583,3,'Gahoi',''),(1584,3,'Gajula / Kavarai',''),(1585,3,'Ganda',''),(1586,3,'Gandha Vanika',''),(1587,3,'Gandla',''),(1588,3,'Gandla / Ganiga',''),(1589,3,'Ganiga',''),(1590,3,'Garhwall',''),(1591,3,'Gatti',''),(1592,3,'Gavara',''),(1593,3,'Gawali',''),(1594,3,'Ghisadi',''),(1595,3,'Ghumar',''),(1596,3,'Goala',''),(1597,3,'Goan',''),(1598,3,'Gomantak',''),(1599,3,'Gondhali',''),(1600,3,'Goud',''),(1601,3,'Gounder',''),(1602,3,'Gounder - Kongu Vellala Gounder',''),(1603,3,'Gounder - Nattu Guunder',''),(1604,3,'Gounder - Others',''),(1605,3,'Gounder - Urali Gounder',''),(1606,3,'Gounder - Vanniya Kula Kshatriyar',''),(1607,3,'Gounder - Vettuva Gounder',''),(1608,3,'Gowda',''),(1609,3,'Gowda - Kuruba gowda',''),(1610,3,'Gramani',''),(1611,3,'Gudia',''),(1612,3,'Gujjar',''),(1613,3,'Gulahre',''),(1614,3,'Gupta',''),(1615,3,'Guptan',''),(1616,3,'Gurav',''),(1617,3,'Gurjar',''),(1618,3,'Haihavanshi',''),(1619,3,'Halba Koshti',''),(1620,3,'Helava',''),(1621,3,'Hugar(Jeer)',''),(1622,3,'IIIaththu Pillai',''),(1623,3,'Intercaste',''),(1624,3,'Irani',''),(1625,3,'Isai Vellalar',''),(1626,3,'Jaalari',''),(1627,3,'Jaiswal',''),(1628,3,'Jandra',''),(1629,3,'Jangam',''),(1630,3,'Jangra - Brahmin',''),(1631,3,'Jat',''),(1632,3,'Jatav',''),(1633,3,'Jetty / Malla',''),(1634,3,'Jhadav',''),(1635,3,'Jijhotia Brahmin',''),(1636,3,'Jogi (Nath)',''),(1637,3,'Julaha',''),(1638,3,'Kachara',''),(1639,3,'Kadava Patel',''),(1640,3,'Kaibarta',''),(1641,3,'Kaikaala',''),(1642,3,'Kalal',''),(1643,3,'Kalanji',''),(1644,3,'Kalar',''),(1645,3,'Kalinga',''),(1646,3,'Kalinga Vysya',''),(1647,3,'Kalita',''),(1648,3,'Kalwar',''),(1649,3,'Kamboj',''),(1650,3,'Kamma',''),(1651,3,'Kamma Naidu',''),(1652,3,'Kanakkan Padanna',''),(1653,3,'Kandara',''),(1654,3,'Kanasari',''),(1655,3,'Kanykubj Bania',''),(1656,1,'Kapu',''),(1657,1,'Kapu Naidu',''),(1658,1,'Kapu Reddy',''),(1659,3,'Karakala Bhakthula',''),(1660,3,'Karana',''),(1661,3,'Karkathar',''),(1662,3,'Karmakar',''),(1663,3,'Karani Bhakthula',''),(1664,3,'Karuneegar',''),(1665,3,'Kasar',''),(1666,3,'Kasaundhan',''),(1667,3,'Kashyap',''),(1668,3,'Kasukara',''),(1669,3,'Katiya',''),(1670,3,'Kavara',''),(1671,3,'Kavuthiyya / Ezhavathy',''),(1672,3,'Kayastha',''),(1673,3,'Kayastha (Bengali)',''),(1674,3,'Kerala Mudali',''),(1675,3,'Keshri (Kesarwani)',''),(1676,3,'Khandayat',''),(1677,3,'Khandelwal',''),(1678,3,'Kharwa',''),(1679,3,'Kharwar',''),(1680,3,'Khatik',''),(1681,3,'Khatri',''),(1682,3,'Kirar',''),(1683,3,'Kodikal Pillai',''),(1684,3,'Kokanastha Maratha',''),(1685,3,'Koli',''),(1686,3,'Koli Madhadev',''),(1687,3,'Koli Patel',''),(1688,3,'Komati / Arya Vaishya',''),(1689,3,'Kongu Chettiar',''),(1690,3,'Kongu Nadar',''),(1691,3,'Kongu Vellala Gounder',''),(1692,3,'Konkani',''),(1693,3,'Korama',''),(1694,3,'Kori',''),(1695,3,'Kori / Koli',''),(1696,3,'Kosthi',''),(1697,3,'Krishnavaka',''),(1698,3,'Kshatriya',''),(1699,3,'Kshatriya Kurmi',''),(1700,3,'Kshatriya Raju',''),(1701,3,'Kudumbi',''),(1702,3,'Kulal',''),(1703,3,'Kulalar',''),(1704,3,'Kilita',''),(1705,3,'Kumaoni Rajput',''),(1706,3,'Kumawat',''),(1707,3,'Kumbhakar',''),(1708,3,'Kumbhar',''),(1709,3,'Kumhar',''),(1710,3,'Kummari',''),(1711,3,'Kunbi',''),(1712,3,'Kunbi Lonari',''),(1713,3,'Kunbi Maratha',''),(1714,3,'Kunbi Tirale',''),(1715,3,'Kuravan',''),(1716,3,'Kurmi',''),(1717,3,'Kurmi / Kurmi Kshatriya',''),(1718,3,'Kurni',''),(1719,3,'Kuruba',''),(1720,3,'Kuruhina Shetty',''),(1721,3,'Kuruhini CHetty',''),(1722,3,'Kurumbar',''),(1723,3,'Kuruva',''),(1724,3,'Kushwaha (Koiri)',''),(1725,3,'Kurchi',''),(1726,3,'Lad',''),(1727,3,'Lambadi',''),(1728,3,'Leva patel',''),(1729,3,'Linga Balija',''),(1730,3,'Lingayath',''),(1731,3,'Lodhi Rajput',''),(1732,3,'Lohana',''),(1733,3,'Lohar',''),(1734,3,'Loniya',''),(1735,3,'Lubana',''),(1736,3,'Madhesiya / Kani / Halwai',''),(1737,3,'Madiga',''),(1738,3,'Mahakan',''),(1739,3,'Mahar',''),(1740,3,'Mahendra',''),(1741,3,'Maheswari',''),(1742,3,'Maheswari / Meshri',''),(1743,3,'Mahishya',''),(1744,3,'Mahor',''),(1745,3,'Mahuri',''),(1746,3,'Mair Rajput Swarnkar',''),(1747,3,'Majabi',''),(1748,3,'Mala',''),(1749,3,'Mali',''),(1750,3,'Mallah',''),(1751,3,'Malviya Bramhim',''),(1752,3,'Malwani',''),(1753,3,'Mangalorean',''),(1754,3,'Manipuri',''),(1755,3,'Manjapidur Chettiar',''),(1756,3,'Mannan / Velan / Vannan',''),(1757,3,'Mapila',''),(1758,3,'Maratha',''),(1759,3,'Maratha Kshatriya',''),(1760,3,'Maruthuvar',''),(1761,3,'Matang',''),(1762,3,'Mathur',''),(1763,3,'Mathur Vaishya',''),(1764,3,'Maurya / Shakya',''),(1765,3,'Meena',''),(1766,3,'Meenavar',''),(1767,3,'Meghwal',''),(1768,3,'Mehra',''),(1769,3,'Meru Darji',''),(1770,3,'Mochi',''),(1771,3,'Medak',''),(1772,3,'Modi',''),(1773,3,'Modikarlu',''),(1774,3,'Mogaveera',''),(1775,3,'Mudaliyar',''),(1776,3,'Mudiraj',''),(1777,1,'Munnuru Kapu',''),(1778,3,'Musukama',''),(1779,3,'Muthuraja',''),(1780,3,'Naagavamsam',''),(1781,3,'Nabit',''),(1782,3,'Nadar',''),(1783,3,'Nagaralu',''),(1784,3,'Nai',''),(1785,3,'Naicker',''),(1786,3,'Naicker - Others',''),(1787,3,'Naicker - Vanniya Kula Kshatriyar',''),(1788,3,'Naidu',''),(1789,3,'Naik',''),(1790,3,'Nair',''),(1791,3,'Namasudra / Namaseej',''),(1792,3,'Namniar',''),(1793,3,'Namdarlu',''),(1794,3,'Nanjil Mudali',''),(1795,3,'Nanjil Nattu Vellalar',''),(1796,3,'Nanjil Vellalar',''),(1797,3,'Nanjil Pillai',''),(1798,3,'Nankudi Vellalar',''),(1799,3,'Napit',''),(1800,3,'Nattu Gounder',''),(1801,3,'Nattukottai Chettiar',''),(1802,3,'Nayaka',''),(1803,3,'Neeli',''),(1804,3,'Neeli Saali',''),(1805,3,'Nema',''),(1806,3,'Nepali',''),(1807,3,'Nessi',''),(1808,3,'Nhavi',''),(1809,3,'Ontari',''),(1810,3,'Oswal',''),(1811,3,'Otari',''),(1812,3,'Othuvaar',''),(1813,3,'Padmasali',''),(1814,3,'Padmashali',''),(1815,3,'Padmavathi Porwal',''),(1816,3,'Pagadala',''),(1817,3,'Pal',''),(1818,3,'Pallan / Devandra Kula Vellalan',''),(1819,3,'Panan',''),(1820,3,'Panchal',''),(1821,3,'Pandaram',''),(1822,3,'Pandiya Vellalar',''),(1823,3,'Panicker',''),(1824,3,'Pannirandam Chettiar',''),(1825,3,'Paravan / Bharatar',''),(1826,3,'Parit',''),(1827,3,'Parkava Kulam',''),(1828,3,'Parsi',''),(1829,3,'Partraj',''),(1830,3,'Parvatha Rajakulam',''),(1831,3,'Pasi',''),(1832,3,'Paswan / Dusadh',''),(1833,3,'Patel',''),(1834,3,'Pathare Prabhu',''),(1835,3,'Patil',''),(1836,3,'Patnick / Sistakaranam',''),(1837,3,'Patra',''),(1838,3,'Pattinavar',''),(1839,3,'Pattusali',''),(1840,3,'Patwa',''),(1841,3,'Perika',''),(1842,3,'Perika / Puragiri Kshatriya',''),(1843,3,'Pillai',''),(1844,3,'Poosala',''),(1845,3,'Porwal',''),(1846,3,'Porwal / Porwar',''),(1847,3,'Poundra',''),(1848,3,'Prajapati',''),(1849,3,'Pulaya / Cheruman',''),(1850,3,'Raigar',''),(1851,3,'Rajaka',''),(1852,3,'Rajastani',''),(1853,3,'Rajbhar',''),(1854,3,'Rajbonshi',''),(1855,3,'Rajpurohot',''),(1856,3,'Rajput',''),(1857,3,'Ramanandi',''),(1858,3,'Ramdasia',''),(1859,3,'Ramgariah',''),(1860,3,'Ramoshi',''),(1861,3,'Rastogi',''),(1862,3,'Rathi',''),(1863,3,'Rauniar',''),(1864,3,'Ravidaisia',''),(1865,3,'Rawat',''),(1866,3,'Reddy',''),(1867,3,'Relli',''),(1868,3,'Ronit / Chamar',''),(1869,3,'Ror',''),(1870,3,'SC',''),(1871,3,'SKP',''),(1872,3,'ST',''),(1873,3,'Sadgope',''),(1874,3,'Sadhi Chetty',''),(1875,3,'Sagara (Uppara)',''),(1876,3,'Saha',''),(1877,3,'Sahu',''),(1878,3,'Saini',''),(1879,3,'Saiva Pillai Thanjavur',''),(1880,3,'Saiva Pillai Tirunelveli',''),(1881,3,'Saliya',''),(1882,3,'Samagar',''),(1883,3,'Sambava',''),(1884,3,'Sathwara',''),(1885,3,'Satnami',''),(1886,3,'Savji',''),(1887,3,'Senai Thalaivar',''),(1888,3,'Senguntha Mudiliyar',''),(1889,3,'Sengunthar / Kaikolar',''),(1890,3,'Settibalija',''),(1891,3,'Setty Balija',''),(1892,3,'Shaw / Sahu / Teli',''),(1893,3,'Shettigar',''),(1894,3,'Shipkar',''),(1895,3,'Shimpi/ Namdev',''),(1896,3,'Sindhi',''),(1897,3,'Sindhi-Amil',''),(1898,3,'Sindhi-Baibhand',''),(1899,3,'Sindhi-Bhanusali',''),(1900,3,'Sindhi-Bhatia',''),(1901,3,'Sindhi-Chhapru',''),(1902,3,'Sindhi-Dadu',''),(1903,3,'Sindhi-Hyderabadi',''),(1904,3,'Sindhi-Larai',''),(1905,3,'Sindhi-Larkana',''),(1906,3,'Sindhi-Lohana',''),(1907,3,'Sindhi-Rohiri',''),(1908,3,'Sindhi-Sahiti',''),(1909,3,'Sindhi-Sakkhar',''),(1910,3,'Sindhi-Sehwani',''),(1911,3,'Sindhi-Shikarpuri',''),(1912,3,'Sindhi-Thatai',''),(1913,3,'Sonar',''),(1914,3,'Soni',''),(1915,3,'Sonkar',''),(1916,3,'Sourashtra',''),(1917,3,'Sozhia Chetty',''),(1918,3,'Sozhiya Vellalar',''),(1919,3,'Srisayana',''),(1920,3,'Sugali (Naika)',''),(1921,3,'Sunari',''),(1922,3,'Sundhi',''),(1923,3,'Surya Balija',''),(1924,3,'Suthar',''),(1925,3,'Swakula Sali',''),(1926,3,'Tamboli',''),(1927,3,'Tanti',''),(1928,3,'Tantubai',''),(1929,3,'Telaga',''),(1930,3,'Teli',''),(1931,3,'Telugupatti',''),(1932,3,'Thakkar',''),(1933,3,'Thakore',''),(1934,3,'Thakur',''),(1935,3,'Thandan',''),(1936,3,'Thigala',''),(1937,3,'Thiyya',''),(1938,3,'Thiyya Thandan',''),(1939,3,'Thogata Veera Kshatriya',''),(1940,3,'Thogata Veerakshathriya',''),(1941,3,'Thondai Mandala Vellalar',''),(1942,3,'Thota',''),(1943,3,'Tili',''),(1944,3,'Togata',''),(1945,3,'Tonk Kshatriya',''),(1946,1,'Turupu Kapu',''),(1947,3,'Ummar / Umre / Bagaria',''),(1948,3,'Urali Gounder',''),(1949,3,'Urs',''),(1950,3,'Vada Baliji',''),(1951,3,'Vasambar',''),(1952,3,'Vaddera',''),(1953,3,'Vadugan',''),(1954,3,'Vaish',''),(1955,3,'Vaishnav',''),(1956,3,'Vaishanav Dishaval',''),(1957,3,'Vaishanav Khadyata',''),(1958,3,'Vaishanav Lad',''),(1959,3,'Vaishanav Modh',''),(1960,3,'Vaishanav Porvas',''),(1961,3,'Vaishanav Shrimali',''),(1962,3,'Vaishanav Sorathaiya',''),(1963,3,'Vaishanav Vania',''),(1964,3,'Vaishanav',''),(1965,3,'Vaishya',''),(1966,3,'Vaishya Vani',''),(1967,3,'Vallivan',''),(1968,3,'Vakmiki',''),(1969,3,'Vani',''),(1970,3,'Vani / Vaishya',''),(1971,3,'Vania',''),(1972,3,'Vanika Vyshaya',''),(1973,3,'Vaniya',''),(1974,3,'Vaniya Chettiar',''),(1975,3,'Vanjara',''),(1976,3,'Vanjari',''),(1977,3,'Vankar',''),(1978,3,'Vannar',''),(1979,3,'Vannia Kula Lshatriyar',''),(1980,3,'Variar',''),(1981,3,'Varshney',''),(1982,3,'Varsjney (Baraseni)',''),(1983,3,'Veera Shivam',''),(1984,3,'Veerakodi Vellala',''),(1985,3,'Velaan',''),(1986,3,'Velama',''),(1987,3,'Vellalar',''),(1988,3,'Vellan Chettiars',''),(1989,3,'Veluthedathu Nair',''),(1990,3,'Vettuva Gounder',''),(1991,3,'Vettuvan',''),(1992,3,'Vijayvargia',''),(1993,3,'Vilakithala Nair',''),(1994,3,'Vilakkithala Nair',''),(1995,3,'Vishwakarma',''),(1996,3,'Viswabramhin',''),(1997,3,'Vokkaliga',''),(1998,3,'Vysya',''),(1999,3,'Yadav',''),(2000,3,'Yadav Naidu',''),(2001,3,'Yellapu',''),(2002,3,'Other Caste',''),(2003,3,'Don\'t wish to Specify',''),(2004,3,'Avavil Bramhin',''),(2005,3,'Audichya Brahmin',''),(2006,3,'Barendra Brahmin',''),(2007,3,'Bharr Brahmin',''),(2008,3,'Bhatt Brahmin',''),(2009,3,'Bhumihar Brahmin',''),(2010,3,'Daivadnya Brahmin',''),(2011,3,'Danua Brahmin',''),(2012,3,'Deshasthu Brahmin',''),(2013,3,'Dhiman Brahmin',''),(2014,3,'Dravida Brahmin',''),(2015,3,'Embrandiri Brahmin',''),(2016,3,'Gaur Brahmin',''),(2017,3,'Goswami / Gosavi Brahmin',''),(2018,3,'Gujar Guar Brahmin',''),(2019,3,'Gurukkal Brahmin',''),(2020,3,'Havyaka Brahmin',''),(2021,3,'Hoysala Brahmin',''),(2022,3,'Iyengar Brahmin',''),(2023,3,'Iyer Brahmin',''),(2024,3,'Jangid Brahmin',''),(2025,3,'Jangid Brahmin',''),(2026,3,'Jhadua Brahmin',''),(2027,3,'Janyajubi Brahmin',''),(2028,3,'Kanyakubj Brahmin',''),(2029,3,'Karhade Brahmin',''),(2030,3,'Kokanastha Brahmin',''),(2031,3,'Kota Brahmin',''),(2032,3,'Kulin Brahmin',''),(2033,3,'Kumaoni Brahmin',''),(2034,3,'Madhwa Brahmin',''),(2035,3,'Maithil Brahmin',''),(2036,3,'Modh Brahmin',''),(2037,3,'Mohyal Brahmin',''),(2038,3,'Nagar Brahmin',''),(2039,3,'Namboodiri Brahmin',''),(2040,3,'Barmaduya Brahmin',''),(2041,3,'Niyogi Brahmin',''),(2042,3,'Panda Brahmin',''),(2043,3,'Pandit Brahmin',''),(2044,3,'Pushkarna Brahmin',''),(2045,3,'Pushkarna Brahmin',''),(2046,3,'Rarhi Brahmin',''),(2047,3,'Rigvedi Brahmin',''),(2048,3,'Rudraj Brahmin',''),(2049,3,'Sakaldwipi Brahmin',''),(2050,3,'Sanadya Brahmin',''),(2051,3,'Sanketi Brahmin',''),(2052,3,'Saraswat Brahmin',''),(2053,3,'Saryuparin Brahmin',''),(2054,3,'Shivhalli Brahmin',''),(2055,3,'Shrimali Brahmin',''),(2056,3,'Sikhwal Brahmin',''),(2057,3,'Sri Vaishnava Brahmin',''),(2058,3,'Stanika Brahmin',''),(2059,3,'Tyagi Brahmin',''),(2060,3,'Vaidiki Brahmin',''),(2061,3,'Vaikhanasa Brahmin',''),(2062,3,'Velanadu Brahmin',''),(2063,3,'Vyas Brahmin',''),(2064,3,'Shetty',''),(2065,3,'Mera',''),(2066,3,'Mukkulathor',''),(2067,3,'Paswan',''),(2068,3,'Jeer',''),(2069,3,'Bramhin Jijhotia',''),(2070,3,'Nath',''),(2071,3,'Koiri',''),(2072,3,'Bramhin Malviya',''),(2073,3,'Darji',''),(2074,3,'Amil Sindhi',''),(2075,3,'Baidhand Sindhi',''),(2076,3,'Bhanusali Sindhi',''),(2077,3,'Bhatia Sindhi',''),(2078,3,'Chhapru Sindhi',''),(2079,3,'Sadu Sindhi',''),(2080,3,'Hyderabadi Sindhi',''),(2081,3,'Larai Sindhi',''),(2082,3,'Larkana Sindhi',''),(2083,3,'Lohana Sindhi',''),(2084,3,'Rohiri Sindhi',''),(2085,3,'Sahiti Sindhi',''),(2086,3,'Sakkhar Sindhi',''),(2087,3,'Sehwani Sindhi',''),(2088,3,'Shikarpuri Sindhi',''),(2089,3,'Thatai Sindhi',''),(2090,3,'Don\'t wish to specify',''),(2091,3,'Naika',''),(2092,2,'Born Again',''),(2093,2,'Bretheren',''),(2094,2,'Church of Siuth India',''),(2095,2,'Evangelist',''),(2096,2,'Jacobite',''),(2097,2,'Knanaya',''),(2098,2,'Knanaya Catholic',''),(2099,2,'Knanaya Jacobite',''),(2100,2,'Latin Catholic',''),(2101,2,'Malankara Catholic',''),(2102,2,'Marthoma',''),(2103,2,'Pentecose',''),(2104,2,'Roman Catholic',''),(2105,2,'Seventh - day Adventist',''),(2106,2,'Syrian Catholic',''),(2107,2,'Syrian Jacobite',''),(2108,2,'Syrian Orthodox',''),(2109,2,'Syro Malabar',''),(2110,2,'Christian - Others',''),(2111,2,'Don\'t wish to specify',''),(2112,4,'Muslim - Ansari',''),(2113,4,'Muslim - Arain',''),(2114,4,'Muslim-Awan',''),(2115,4,'Muslim - Bohra',''),(2116,4,'Muslim- Dekkani',''),(2117,4,'Muslim- Dudekula',''),(2118,4,'Muslim- Hanafi',''),(2119,4,'Muslim- Jat',''),(2120,4,'Muslim-Khoja',''),(2121,4,'Muslim- Lebbai',''),(2122,4,'Muslim- Malilk',''),(2123,4,'Muslim-Mapila',''),(2124,4,'Muslim-Maraicar',''),(2125,4,'Muslim-Memon',''),(2126,4,'Muslim-Mughal',''),(2127,4,'Muslim-Others',''),(2128,4,'Muslim-Pathan',''),(2129,4,'Muslim-Qureshi',''),(2130,4,'Muslim-Rajput',''),(2131,4,'Muslim-Rowther',''),(2132,4,'Muslim-Shafi',''),(2133,4,'Muslim-Sheikh',''),(2134,4,'Muslim-Siddiqui',''),(2135,4,'Muslim-Syed',''),(2136,4,'Muslim-UnSpecified',''),(2137,4,'Other Caste',''),(2138,4,'Don\'t wish to specify',''),(2139,5,'Muslim - Ansari',''),(2140,5,'Muslim - Arain',''),(2141,5,'Muslim-Awan',''),(2142,5,'Muslim - Bohra',''),(2143,5,'Muslim- Dekkani',''),(2144,5,'Muslim- Dudekula',''),(2145,5,'Muslim- Hanafi',''),(2146,5,'Muslim- Jat',''),(2147,5,'Muslim-Khoja',''),(2148,5,'Muslim- Lebbai',''),(2149,5,'Muslim- Malilk',''),(2150,5,'Muslim-Mapila',''),(2151,5,'Muslim-Maraicar',''),(2152,5,'Muslim-Memon',''),(2153,5,'Muslim-Mughal',''),(2154,5,'Muslim-Others',''),(2155,5,'Muslim-Pathan',''),(2156,5,'Muslim-Qureshi',''),(2157,5,'Muslim-Rajput',''),(2158,5,'Muslim-Rowther',''),(2159,5,'Muslim-Shafi',''),(2160,5,'Muslim-Sheikh',''),(2161,5,'Muslim-Siddiqui',''),(2162,5,'Muslim-Syed',''),(2163,5,'Muslim-UnSpecified',''),(2164,5,'Other Caste',''),(2165,5,'Don\'t wish to specify',''),(2166,6,'Muslim - Ansari',''),(2167,6,'Muslim - Arain',''),(2168,6,'Muslim-Awan',''),(2169,6,'Muslim - Bohra',''),(2170,6,'Muslim- Dekkani',''),(2171,6,'Muslim- Dudekula',''),(2172,6,'Muslim- Hanafi',''),(2173,6,'Muslim- Jat',''),(2174,6,'Muslim-Khoja',''),(2175,6,'Muslim- Lebbai',''),(2176,6,'Muslim- Malilk',''),(2177,6,'Muslim-Mapila',''),(2178,6,'Muslim-Maraicar',''),(2179,6,'Muslim-Memon',''),(2180,6,'Muslim-Mughal',''),(2181,6,'Muslim-Others',''),(2182,6,'Muslim-Pathan',''),(2183,6,'Muslim-Qureshi',''),(2184,6,'Muslim-Rajput',''),(2185,6,'Muslim-Rowther',''),(2186,6,'Muslim-Shafi',''),(2187,6,'Muslim-Sheikh',''),(2188,6,'Muslim-Siddiqui',''),(2189,6,'Muslim-Syed',''),(2190,6,'Muslim-UnSpecified',''),(2191,6,'Other Caste',''),(2192,6,'Don\'t wish to specify',''),(2193,8,'Jain-Agarwal',''),(2194,8,'Jain-Bania',''),(2195,8,'Jain-Intercaste',''),(2196,8,'Jain-Jaiswal',''),(2197,8,'Jain-KVO',''),(2198,8,'Jain-Khandelwal',''),(2199,8,'Jain-Kutchi',''),(2200,8,'Jain-Oswal',''),(2201,8,'Jain-Others',''),(2202,8,'Jain-Porwal',''),(2203,8,'Jain-Unspecified',''),(2204,8,'Jain-Vaishya',''),(2205,8,'Other Caste',''),(2206,8,'Don\'t wish to Specify',''),(2207,9,'Jain-Agarwal',''),(2208,9,'Jain-Bania',''),(2209,9,'Jain-Intercaste',''),(2210,9,'Jain-Jaiswal',''),(2211,9,'Jain-KVO',''),(2212,9,'Jain-Khandelwal',''),(2213,9,'Jain-Kutchi',''),(2214,9,'Jain-Oswal',''),(2215,9,'Jain-Others',''),(2216,9,'Jain-Porwal',''),(2217,9,'Jain-Unspecified',''),(2218,9,'Jain-Vaishya',''),(2219,9,'Other Caste',''),(2220,9,'Don\'t wish to Specify',''),(2221,10,'Jain-Agarwal',''),(2222,10,'Jain-Bania',''),(2223,10,'Jain-Intercaste',''),(2224,10,'Jain-Jaiswal',''),(2225,10,'Jain-KVO',''),(2226,10,'Jain-Khandelwal',''),(2227,10,'Jain-Kutchi',''),(2228,10,'Jain-Oswal',''),(2229,10,'Jain-Others',''),(2230,10,'Jain-Porwal',''),(2231,10,'Jain-Unspecified',''),(2232,10,'Jain-Vaishya',''),(2233,10,'Other Caste',''),(2234,10,'Don\'t wish to Specify',''),(2235,7,'Sikh-Ahluwalia',''),(2236,7,'Sikh-Arora',''),(2237,7,'Sikh-Bhatia',''),(2238,7,'Sikh-Bhatra',''),(2239,7,'Sikh-Ghumar',''),(2240,7,'Sikh-Intercaste',''),(2241,7,'Sikh-Jat',''),(2242,7,'Sikh-Kamboj',''),(2243,7,'Sikh-Khatri',''),(2244,7,'Sikh-Kshatriya',''),(2245,7,'Sikh-Majabi',''),(2246,7,'Sikh-Nai',''),(2247,7,'Sikh-Others',''),(2248,7,'Sikh-Rajput',''),(2249,7,'Sikh-Ramdasia',''),(2250,7,'Sikh-Ramgharia',''),(2251,7,'Sikh-Ravidasia',''),(2252,7,'Sikh-Saini',''),(2253,7,'Sikh-Tonk Kshatriya',''),(2254,7,'Sikh-Unspecified',''),(2255,7,'Other Caste',''),(2256,7,'Don\'t wish to specify',''),(2257,11,'Intercaste',''),(2258,11,'Irani',''),(2259,11,'Parsi',''),(2260,11,'Other Caste',''),(2261,11,'Don\'t wish to Specify',''),(2262,12,'Other Caste',''),(2263,12,'Don\'t wish to Specify',''),(2264,13,'Other Caste',''),(2265,13,'Don\'t wish to Specify',''),(2266,3,'abc',''),(2267,1,'Rccc',''),(2268,1,'Rcccc',''),(2269,1,'abc',''),(2270,5,'abc',''),(2271,3,'test1',''),(2272,1,'Brahmin - Any',''),(2273,1,'Kapu - Any',''),(2274,1,'bharmin','');
/*!40000 ALTER TABLE `castes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `castes_old`
--

DROP TABLE IF EXISTS `castes_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `castes_old` (
  `caste_id` int(10) NOT NULL AUTO_INCREMENT,
  `religion_id` int(20) NOT NULL,
  `caste_name` varchar(100) NOT NULL,
  `caste_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`caste_id`)
) ENGINE=InnoDB AUTO_INCREMENT=632 DEFAULT CHARSET=latin1 COMMENT='Caste details of members';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `castes_old`
--

LOCK TABLES `castes_old` WRITE;
/*!40000 ALTER TABLE `castes_old` DISABLE KEYS */;
INSERT INTO `castes_old` VALUES (1,1,'24 Manai Telugu Chettiar',1),(2,1,'96 Kuli Maratha',1),(3,1,'Aaru Nattu Vellala',1),(4,1,'Achirapakkam Chettiar',1),(5,1,'Ad Dharmi',1),(6,1,'Adi Andhra',1),(7,1,'Adi Dravidar',1),(8,1,'Adi Karnataka',1),(9,1,'Agamudayar / Arcot / Thuluva Vellala',1),(11,5,'Roman Catholic',1),(12,5,'Latin Catholic',1),(13,14,'Sikkk',1),(14,1,'test',0),(15,16,'Hindu  or Inter Religion',1),(16,16,'24 Manai Telugu Chettiar',1),(17,16,'96 Kuli Maratha',1),(18,16,'Aaru Nattu Vellala',1),(19,16,'Ad Dharmi',1),(20,16,'Adi Andhra',1),(21,16,'Adi Dravidar',1),(22,16,'Adi Karnataka',1),(23,16,'Agamudayar/Arcot/Thuluva Vellala',1),(24,16,'Agaram Vellan Chettiar',1),(25,16,'Agarwal',1),(26,16,'Agnikula Kshatriya',1),(27,16,'Agrahari',1),(28,16,'Agri',1),(29,16,'Ahir Shimpi',1),(30,16,'Ahirwar',1),(31,16,'Ahom',1),(32,16,'Ambalavasi',1),(33,16,'Anjana (Chowdary)Patel',1),(34,16,'Aramari / Gabit',1),(35,16,'Arekatica',1),(36,16,'Arora',1),(37,16,'Arunthathiyar',1),(38,16,'Arya Vysya',1),(39,16,'Asathi',1),(40,16,'Ayira Vysya',1),(41,16,'Ayodhyavasi',1),(42,16,'Ayodhyavasi',1),(43,16,'Budaga',1),(44,16,'Bagdi',1),(45,16,'Baidya',1),(46,16,'Bairwa',1),(47,16,'Baishbnab',1),(48,16,'Baishya',1),(49,16,'Bajantri',1),(50,16,'Balai',1),(51,16,'Balija',1),(52,16,'Balija Naidu',1),(53,16,'Balija Reddy',1),(54,16,'Banayat Oriya',1),(55,16,'Banik',1),(56,16,'Baniya',1),(57,16,'Baniya - Bania',1),(58,16,'Baniya - KUmuti',1),(59,16,'Banjara',1),(60,16,'Barai',1),(61,16,'Barnwal',1),(62,16,'Barujibi',1),(63,16,'Beri Chettiar',1),(64,16,'Besta',1),(65,16,'Bhandari',1),(66,16,'Bhaia',1),(67,16,'Bhatraju',1),(68,16,'Bhavasar Vshatriya',1),(69,16,'Bhoi',1),(70,16,'Bhovi',1),(71,16,'Bhoyar',1),(72,16,'Billava',1),(73,16,'Bishnoi / Vishnoi',1),(74,16,'Bondili',1),(75,16,'Born Again',1),(76,16,'Boyar',1),(77,16,'Brahmbatt',1),(78,16,'Brahmin - Anavil',1),(79,16,'Brahmin - Anaviln Desai',1),(80,16,'Brahmin - Audichya',1),(81,16,'Brahmin - Baidhiki / Vaidhiki',1),(82,16,'Brahmin - Bardai',1),(83,16,'Brahmin - Barendra',1),(84,16,'Brahmin - Bhargav',1),(85,16,'Brahmin - Bhatt',1),(86,16,'Brahmin - Bhumihar',1),(87,16,'Brahmin - Dadhich',1),(88,16,'Brahmin - Daivadnya',1),(89,16,'Brahmin - Danua',1),(90,16,'Brahmin - Deshastha',1),(91,16,'Brahmin - Dhiman',1),(92,16,'Brahmin - Dravida',1),(93,16,'Brahmin - Embrandiri',1),(94,16,'Brahmin - Garhwali',1),(95,16,'Brahmin - Gaur',1),(96,16,'Brahmin - Goswami / Gosavi',1),(97,16,'Brahmin - Gujar Gaur',1),(98,16,'Brahmin - Gurakkal',1),(99,16,'Brahmin - Halua',1),(100,16,'Brahmin - Havyaka',1),(101,16,'Brahmin - Hoysala',1),(102,16,'Brahmin - Iyengar',1),(103,16,'Brahmin - Iyer',1),(104,16,'Brahmin - Jabgid',1),(105,16,'Brahmin - Jhadua',1),(106,16,'Brahmin - Jyotish',1),(107,16,'Brahmin - Kanyakubi',1),(108,16,'Brahmin - Karhade',1),(109,16,'Brahmin - Khadayata',1),(110,16,'Brahmin - Khandelwal',1),(111,16,'Brahmin - Khedaval',1),(112,16,'Brahmin - Kokanastha',1),(113,16,'Brahmin - Kota',1),(114,16,'Brahmin - Koteshwara /Kota(Madhwa)',1),(115,16,'Brahmin - Kulin',1),(116,16,'Brahmin - Kumaoni',1),(117,16,'Brahmin - Madhwa',1),(118,16,'Brahmin - Madhwa',1),(119,16,'Brahmin - Maithil',1),(120,16,'Brahmin - Meveda',1),(121,16,'Brahmin - Modh',1),(122,16,'Brahmin - Mohyal',1),(123,16,'Brahmin - Nagar',1),(124,16,'Brahmin - Namboodiri',1),(125,16,'Brahmin - Narmadiya',1),(126,16,'Brahmin - Niyogi',1),(127,16,'Brahmin - Others',1),(128,16,'Brahmin - Paliwal',1),(129,16,'Brahmin - Panda',1),(130,16,'Brahmin - Pandit',1),(131,16,'Brahmin - Panicker',1),(132,16,'Brahmin - Pareek',1),(133,16,'Brahmin - Pushkarna',1),(134,16,'Brahmin - Rajgor',1),(135,16,'Brahmin - Rarhi',1),(136,16,'Brahmin - Rarhi /Radhi',1),(137,16,'Brahmin - Rigvedi',1),(138,16,'Brahmin - Rudraj',1),(139,16,'Brahmin - Sakaldwipi',1),(140,16,'Brahmin - Sanadya',1),(141,16,'Brahmin - Sanketi',1),(142,16,'Brahmin - Saraswat',1),(143,16,'Brahmin - Sarua',1),(144,16,'Brahmin - Saeyuparin',1),(145,16,'Brahmin - Shivalli (Madhva)',1),(146,16,'Brahmin - Shivhalli',1),(147,16,'Brahmin - Shri Gaud',1),(148,16,'Brahmin - Shri Mali',1),(149,16,'Brahmin - Shrimali',1),(150,16,'Brahmin - Shukla Yajurvedi',1),(151,16,'Brahmin - Sikhwal',1),(152,16,'Brahmin - Smartha',1),(153,16,'Brahmin - Sri Vaishnava',1),(154,16,'Brahmin - Stanila',1),(155,16,'Brahmin - Tapodhan',1),(156,16,'Brahmin - Tyagi',1),(157,16,'Brahmin - Vaidiki',1),(158,16,'Brahmin - Vaikhanasa',1),(159,16,'Brahmin - Valam',1),(160,16,'Brahmin - Velanadu',1),(161,16,'Brahmin - Vyas',1),(162,16,'Brahmin - Zalora',1),(163,16,'Brajastha Maithil',1),(164,16,'Bunt (Shetty)',1),(165,16,'CKP',1),(166,16,'Chalawadi and Holeya',1),(167,16,'Chambhar',1),(168,16,'Chandravanishi Kahar',1),(169,16,'Chasa',1),(170,16,'Chattada Sri Vaishnava',1),(171,16,'Chaturth',1),(172,16,'Chaudary',1),(173,16,'Chaurasia',1),(174,16,'Chennadasar',1),(175,16,'Cjerukula Vellalar',1),(176,16,'Chettiar',1),(177,16,'Chhetri',1),(178,16,'Chippolu(Mera)',1),(179,16,'Choudary',1),(180,16,'Coorgi',1),(181,16,'Deshmukh',1),(182,16,'Desikar',1),(183,16,'Desikar Thanjuvur',1),(184,16,'Devadiga',1),(185,16,'Devandra Kula Vellalar',1),(186,16,'Devang Koshthi',1),(187,16,'Devanga',1),(188,16,'Devanga Chettiar',1),(189,16,'Devar / Thevar /Mukkulathor',1),(190,16,'Devrukhe Brahmin',1),(191,16,'Dhanak',1),(192,16,'Dhangar',1),(193,16,'Dheevara',1),(194,16,'Dhiman',1),(195,16,'Dhobi',1),(196,16,'Dhor /Dusra',1),(197,16,'Dumal',1),(198,16,'Dusadh (Paswan)',1),(199,16,'Ediga',1),(200,16,'Ediga / Goud (Balija)',1),(201,16,'Elur Chetty',1),(202,16,'Ezhava',1),(203,16,'Ezhava Panciker',1),(204,16,'Ezhuthachan',1),(205,16,'Gabit',1),(206,16,'Gahoi',1),(207,16,'Gajula / Kavarai',1),(208,16,'Ganda',1),(209,16,'Gandha Vanika',1),(210,16,'Gandla',1),(211,16,'Gandla / Ganiga',1),(212,16,'Ganiga',1),(213,16,'Garhwall',1),(214,16,'Gatti',1),(215,16,'Gavara',1),(216,16,'Gawali',1),(217,16,'Ghisadi',1),(218,16,'Ghumar',1),(219,16,'Goala',1),(220,16,'Goan',1),(221,16,'Gomantak',1),(222,16,'Gondhali',1),(223,16,'Goud',1),(224,16,'Gounder',1),(225,16,'Gounder - Kongu Vellala Gounder',1),(226,16,'Gounder - Nattu Guunder',1),(227,16,'Gounder - Others',1),(228,16,'Gounder - Urali Gounder',1),(229,16,'Gounder - Vanniya Kula Kshatriyar',1),(230,16,'Gounder - Vettuva Gounder',1),(231,16,'Gowda',1),(232,16,'Gowda - Kuruba gowda',1),(233,16,'Gramani',1),(234,16,'Gudia',1),(235,16,'Gujjar',1),(236,16,'Gulahre',1),(237,16,'Gupta',1),(238,16,'Guptan',1),(239,16,'Gurav',1),(240,16,'Gurjar',1),(241,16,'Haihavanshi',1),(242,16,'Halba Koshti',1),(243,16,'Helava',1),(244,16,'Hugar(Jeer)',1),(245,16,'IIIaththu Pillai',1),(246,16,'Intercaste',1),(247,16,'Irani',1),(248,16,'Isai Vellalar',1),(249,16,'Jaalari',1),(250,16,'Jaiswal',1),(251,16,'Jandra',1),(252,16,'Jangam',1),(253,16,'Jangra - Brahmin',1),(254,16,'Jangra - Brahmin',1),(255,16,'Jat',1),(256,16,'Jatav',1),(257,16,'Jetty / Malla',1),(258,16,'Jhadav',1),(259,16,'Jijhotia Brahmin',1),(260,16,'Jogi (Nath)',1),(261,16,'Jogi (Nath)',0),(262,16,'Kachara',1),(263,16,'Kadava Patel',1),(264,16,'Kaibarta',1),(265,16,'Kaikaala',1),(266,16,'Kalal',1),(267,16,'Kalanji',1),(268,16,'Kalar',1),(269,16,'Kalinga',1),(270,16,'Kalinga Vysya',1),(271,16,'Kalita',1),(272,16,'Kalwar',1),(273,16,'Kamboj',1),(274,16,'Kamma',1),(275,16,'Kamma Naidu',1),(276,16,'Kanakkan Padanna',1),(277,16,'Kandara',1),(278,16,'Kanasari',1),(279,16,'Kanykubj Bania',1),(280,16,'Kapu',1),(281,16,'Kapu Naidu',1),(282,16,'Kapu Reddy',1),(283,16,'Karakala Bhakthula',1),(284,16,'Karana',1),(285,16,'Karkathar',1),(286,16,'Karani Bhakthula',1),(287,16,'Karuneegar',1),(288,16,'Kasar',1),(289,16,'Kasaundhan',1),(290,16,'Kashyap',1),(291,16,'Kasukara',1),(292,16,'Katiya',1),(293,16,'Kavara',1),(294,16,'Kavuthiyya / Ezhavathy',1),(295,16,'Kayastha',1),(296,16,'Kayastha (Bengali)',1),(297,16,'Kerala Mudali',1),(298,16,'Keshri (Kesarwani)',1),(299,16,'Khandayat',1),(300,16,'Khandelwal',1),(301,16,'Kharwa',1),(302,16,'Kharwar',1),(303,16,'Kharwar',1),(304,16,'Khatik',1),(305,16,'Kirar',1),(306,16,'Kirar',1),(307,16,'Kodikal Pillai',1),(308,16,'Kokanastha Maratha',1),(309,16,'Koli',1),(310,16,'Koli Madhadev',1),(311,16,'Koli Patel',1),(312,16,'Komati / Arya Vaishya',1),(313,16,'Kongu Chettiar',1),(314,16,'Kongu Nadar',1),(315,16,'Kongu Vellala Gounder',1),(316,16,'Konkani',1),(317,16,'Korama',1),(318,16,'Kori',1),(319,16,'Kori / Koli',1),(320,16,'Kosthi',1),(321,16,'Krishnavaka',1),(322,16,'Kshatriya',1),(323,16,'Kshatriya Kurmi',1),(324,16,'Kshatriya Raju',1),(325,16,'Kudumbi',1),(326,16,'Kulal',1),(327,16,'Kulalar',1),(328,16,'Kilita',1),(329,16,'Kumaoni Rajput',1),(330,16,'Kumawat',1),(331,16,'Kumbhakar',1),(332,16,'Kumbhar',1),(333,16,'Kumhar',1),(334,16,'Kummari',1),(335,16,'Kunbi',1),(336,16,'Kunbi Lonari',1),(337,16,'Kunbi Maratha',1),(338,16,'Kunbi Tirale',1),(339,16,'Kuravan',1),(340,16,'Kurmi',1),(341,16,'Kurmi / Kurmi Kshatriya',1),(342,16,'Kurni',1),(343,16,'Kuruba',1),(344,16,'Kuruhina Shetty',1),(345,16,'Kuruhini CHetty',1),(346,16,'Kurumbar',1),(347,16,'Kuruva',1),(348,16,'Kushwaha (Koiri)',1),(349,16,'Kurchi',1),(350,16,'Lad',1),(351,16,'Lambadi',1),(352,16,'Leva patel',1),(353,16,'Linga Balija',1),(354,16,'Lingayath',1),(355,16,'Lodhi Rajput',1),(356,16,'Lohana',1),(357,16,'Lohar',1),(358,16,'Loniya',1),(359,16,'Lubana',1),(360,16,'Madhesiya / Kani / Halwai',1),(361,16,'Madiga',1),(362,16,'Mahakan',1),(363,16,'Mahar',1),(364,16,'Mahendra',1),(365,16,'Maheswari',1),(366,16,'Maheswari / Meshri',1),(367,16,'Mahishya',1),(368,16,'Mahor',1),(369,16,'Mahuri',1),(370,16,'Mair Rajput Swarnkar',1),(371,16,'Majabi',1),(372,16,'Mala',1),(373,16,'Mali',1),(374,16,'Mallah',1),(375,16,'Malviya Bramhim',1),(376,16,'Malwani',1),(377,16,'Mangalorean',1),(378,16,'Manipuri',1),(379,16,'Manjapidur Chettiar',1),(380,16,'Mannan / Velan / Vannan',1),(381,16,'Mapila',1),(382,16,'Maratha',1),(383,16,'Maratha Kshatriya',1),(384,16,'Maruthuvar',1),(385,16,'Matang',1),(386,16,'Mathur',1),(387,16,'Mathur Vaishya',1),(388,16,'Maurya / Shakya',1),(389,16,'Meena',1),(390,16,'Meenavar',1),(391,16,'Meghwal',1),(392,16,'Mehra',1),(393,16,'Meru Darji',1),(394,16,'Mochi',1),(395,16,'Medak',1),(396,16,'Modi',1),(397,16,'Modikarlu',1),(398,16,'Mogaveera',1),(399,16,'Mudaliyar',1),(400,16,'Mudiraj',1),(401,16,'Munnuru Kapu',1),(402,16,'Musukama',1),(403,16,'Muthuraja',1),(404,16,'Naagavamsam',1),(405,16,'Nabit',1),(406,16,'Nadar',1),(407,16,'Nagaralu',1),(408,16,'Nai',1),(409,16,'Naicker',1),(410,16,'Naicker - Others',1),(411,16,'Naicker - Vanniya Kula Kshatriyar',1),(412,16,'Naidu',1),(413,16,'Naik',1),(414,16,'Nair',1),(415,16,'Namasudra / Namaseej',1),(416,16,'Namniar',1),(417,16,'Namdarlu',1),(418,16,'Nanjil Mudali',1),(419,16,'Nanjil Nattu Vellalar',1),(420,16,'Nanjil Vellalar',1),(421,16,'Nanjil Pillai',1),(422,16,'Nankudi Vellalar',1),(423,16,'Napit',1),(424,16,'Nattu Gounder',1),(425,16,'Nattukottai Chettiar',1),(426,16,'Nayaka',1),(427,16,'Neeli',1),(428,16,'Neeli Saali',1),(429,16,'Nema',1),(430,16,'Nepali',1),(431,16,'Nessi',1),(432,16,'Nhavi',1),(433,16,'Ontari',1),(434,16,'Oswal',1),(435,16,'Otari',1),(436,16,'Othuvaar',1),(437,16,'Padmasali',1),(438,16,'Padmashali',1),(439,16,'Padmavathi Porwal',1),(440,16,'Pagadala',1),(441,16,'Pal',1),(442,16,'Pallan / Devandra Kula Vellalan',1),(443,16,'Panan',1),(444,16,'Panchal',1),(445,16,'Pandaram',1),(446,16,'Pandiya Vellalar',1),(447,16,'Panicker',1),(448,16,'Pannirandam Chettiar',1),(449,16,'Paravan / Bharatar',1),(450,16,'Parit',1),(451,16,'Parkava Kulam',1),(452,16,'Parsi',1),(453,16,'Partraj',1),(454,16,'Parvatha Rajakulam',1),(455,16,'Pasi',1),(456,16,'Paswan / Dusadh',1),(457,16,'Patel',1),(458,16,'Pathare Prabhu',1),(459,16,'Patil',1),(460,16,'Patnick / Sistakaranam',1),(461,16,'Patra',1),(462,16,'Pattinavar',1),(463,16,'Pattusali',1),(464,16,'Patwa',1),(465,16,'Perika',1),(466,16,'Perika / Puragiri Kshatriya',1),(467,16,'Pillai',1),(468,16,'Poosala',1),(469,16,'Porwal',1),(470,16,'Porwal / Porwar',1),(471,16,'Poundra',1),(472,16,'Prajapati',1),(473,16,'Pulaya / Cheruman',1),(474,16,'Raigar',1),(475,16,'Rajaka',1),(476,16,'Rajastani',1),(477,16,'Rajbhar',1),(478,16,'Rajbonshi',1),(479,16,'Rajpurohot',1),(480,16,'Rajput',1),(481,16,'Ramanandi',1),(482,16,'Ramdasia',1),(483,16,'Ramgariah',1),(484,16,'Ramoshi',1),(485,16,'Rastogi',1),(486,16,'Rathi',1),(487,16,'Rauniar',1),(488,16,'Ravidaisia',1),(489,16,'Rawat',1),(490,16,'Reddy',1),(491,16,'Relli',1),(492,16,'Ronit / Chamar',1),(493,16,'Ronit / Chamar',1),(494,16,'Ror',1),(495,16,'SC',1),(496,16,'SKP',1),(497,16,'SKP',1),(498,16,'ST',1),(499,16,'Sadgope',1),(500,16,'Sadhi Chetty',1),(501,16,'Sagara (Uppara)',1),(502,16,'Saha',1),(503,16,'Sahu',1),(504,16,'Saini',1),(505,16,'Saiva Pillai Thanjavur',1),(506,16,'Saiva Pillai Tirunelveli',1),(507,16,'Saliya',1),(508,16,'Samagar',1),(509,16,'Sambava',1),(510,16,'Sathwara',1),(511,16,'Satnami',1),(512,16,'Savji',1),(513,16,'Senai Thalaivar',1),(514,16,'Senguntha Mudiliyar',1),(515,16,'Sengunthar / Kaikolar',1),(516,16,'Settibalija',1),(517,16,'Setty Balija',1),(518,16,'Shaw / Sahu / Teli',1),(519,16,'Shettigar',1),(520,16,'Shipkar',1),(521,16,'Shimpi/ Namdev',1),(522,16,'Sindhi',1),(523,16,'Sindhi-Amil',1),(524,16,'Sindhi-Baibhand',1),(525,16,'Sindhi-Bhanusali',1),(526,16,'Sindhi-Bhatia',1),(527,16,'Sindhi-Chhapru',1),(528,16,'Sindhi-Dadu',1),(529,16,'Sindhi-Hyderabadi',1),(530,16,'Sindhi-Larai',1),(531,16,'Sindhi-Larkana',1),(532,16,'Sindhi-Lohana',1),(533,16,'Sindhi-Rohiri',1),(534,16,'Sindhi-Sahiti',1),(535,16,'Sindhi-Sakkhar',1),(536,16,'Sindhi-Sehwani',1),(537,16,'Sindhi-Shikarpuri',1),(538,16,'Sindhi-Thatai',1),(539,16,'Sonar',1),(540,16,'Soni',1),(541,16,'Sonkar',1),(542,16,'Sourashtra',1),(543,16,'Sozhia Chetty',1),(544,16,'Sozhiya Vellalar',1),(545,16,'Srisayana',1),(546,16,'Sugali (Naika)',1),(547,16,'Sunari',1),(548,16,'Sundhi',1),(549,16,'Surya Balija',1),(550,16,'Suthar',1),(551,16,'Swakula Sali',1),(552,16,'Tamboli',1),(553,16,'Tanti',1),(554,16,'Tantubai',1),(555,16,'Telaga',1),(556,16,'Teli',1),(557,16,'Telugupatti',1),(558,16,'Thakkar',1),(559,16,'Thakore',1),(560,16,'Thakur',1),(561,16,'Thandan',1),(562,16,'Thigala',1),(563,16,'Thiyya',1),(564,16,'Thiyya Thandan',1),(565,16,'Thogata Veera Kshatriya',1),(566,16,'Thogata Veerakshathriya',1),(567,16,'Thondai Mandala Vellalar',1),(568,16,'Thota',1),(569,16,'Tili',1),(570,16,'Togata',1),(571,16,'Tonk Kshatriya',1),(572,16,'Turupu Kapu',1),(573,16,'Ummar / Umre / Bagaria',1),(574,16,'Urali Gounder',1),(575,16,'Urs',1),(576,16,'Vada Baliji',1),(577,16,'Vasambar',1),(578,16,'Vaddera',1),(579,16,'Vadugan',1),(580,16,'Vaish',1),(581,16,'Vaishnav',1),(582,16,'Vaishanav Dishaval',1),(583,16,'Vaishanav Khadyata',1),(584,16,'Vaishanav Lad',1),(585,16,'Vaishanav Modh',1),(586,16,'Vaishanav Porvas',1),(587,16,'Vaishanav Shrimali',1),(588,16,'Vaishanav Sorathaiya',1),(589,16,'Vaishanav Vania',1),(590,16,'Vaishanav ',1),(591,16,'Vaishya',1),(592,16,'Vaishya Vani',1),(593,16,'Vallivan',1),(594,16,'Vakmiki',1),(595,16,'Vakmiki',1),(596,16,'Vani',1),(597,16,'Vani / Vaishya',1),(598,16,'Vania',1),(599,16,'Vanika Vyshaya',1),(600,16,'Vaniya',1),(601,16,'Vaniya Chettiar',1),(602,16,'Vanjara',1),(603,16,'Vanjari',1),(604,16,'Vankar',1),(605,16,'Vannar',1),(606,16,'Vannia Kula Lshatriyar',1),(607,16,'Variar',1),(608,16,'Varshney',1),(609,16,'Varsjney (Baraseni)',1),(610,16,'Veera Shivam',1),(611,16,'Veerakodi Vellala',1),(612,16,'Velaan',1),(613,16,'Velama',1),(614,16,'Vellalar',1),(615,16,'Vellan Chettiars',1),(616,16,'Veluthedathu Nair',1),(617,16,'Vettuva Gounder',1),(618,16,'Vettuvan',1),(619,16,'Vijayvargia',1),(620,16,'Vilakithala Nair',1),(621,16,'Vilakkithala Nair',1),(622,16,'Vishwakarma',1),(623,16,'Viswabramhin',1),(624,16,'Vokkaliga',1),(625,16,'Vysya',1),(626,16,'Yadav',1),(627,16,'Yadav Naidu',1),(628,16,'Yellapu',1),(629,16,'Yellapu',1),(630,16,'Other Caste',1),(631,16,'Don\'t wish to Specify',1);
/*!40000 ALTER TABLE `castes_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `city_id` int(20) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(100) DEFAULT NULL,
  `state_id` int(20) NOT NULL,
  `country_id` int(20) NOT NULL DEFAULT '1',
  `city_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1 COMMENT='Details of cities';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'Ernakulam',19,1,1),(2,'Calicut',19,1,1),(3,'Trivandrum',19,1,1),(4,'Alappuzha',19,1,1),(5,'australia',0,0,0),(6,'wayanad',19,1,0),(7,'shaju city',121,203,0),(8,'Anantapur',2,1,1),(9,'Chittoor',2,1,1),(10,'East Godavari',2,1,1),(11,'Guntur',2,1,1),(12,'Kadapa',2,1,1),(13,'Krishna',2,1,1),(14,'Kurnool',2,1,1),(15,'Nellore',2,1,1),(16,'Prakasam District',2,1,1),(17,'Srikakulam',2,1,1),(18,'Visakhapatnam',2,1,1),(19,'Vizianagaram',2,1,1),(20,'West Godavari',2,1,1),(21,'Adilabad',33,1,1),(22,'Bhadradri District',33,1,1),(23,'Hyderabad',33,1,1),(24,'Jagtial',33,1,1),(25,'Jangaon',33,1,1),(26,'Jayashankar',33,1,1),(27,'Jogulamba',33,1,1),(28,'Kamareddy',33,1,1),(29,'Karimnagar',33,1,1),(30,'Khammam',33,1,1),(31,'Komaram Bheem',33,1,1),(32,'Mahabubabad',33,1,1),(33,'Mahabubnagar',33,1,1),(34,'Mancherial',33,1,1),(35,'Medak',33,1,1),(36,'Medchal',33,1,1),(37,'Nagarkurnool',33,1,1),(38,'Nalgonda',33,1,1),(39,'Nirmal',33,1,1),(40,'Nizamabad',33,1,1),(41,'Peddapalli',33,1,1),(42,'Rajanna Sircilla',33,1,1),(43,'Ranga Reddy',33,1,1),(44,'Sangareddy',33,1,1),(45,'Siddipet',33,1,1),(46,'Suryapet',33,1,1),(47,'Vikarabad',33,1,1),(48,'Wanaparthy',33,1,1),(49,'Warangal Rural',33,1,1),(50,'Warangal Urban',33,1,1),(51,'Yadadri',33,1,1),(52,'wales',123,6,1),(53,'Testtest',19,1,0),(54,'desaff',127,5,0),(55,'KAKINADA',5,1,1),(56,'VIJAYAWADA',37,1,1),(57,'Test',2,1,0);
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classified_images`
--

DROP TABLE IF EXISTS `classified_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classified_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `image_path` varchar(750) NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classified_images`
--

LOCK TABLES `classified_images` WRITE;
/*!40000 ALTER TABLE `classified_images` DISABLE KEYS */;
INSERT INTO `classified_images` VALUES (2,162,'assets/uploads/Classifieds_images/162-hall4.png','2017-02-09 11:57:00'),(4,162,'assets/uploads/Classifieds_images/162-hall2.png','2017-02-09 11:57:00'),(5,162,'assets/uploads/Classifieds_images/162-hall3.png','2017-02-09 11:57:00'),(7,162,'assets/uploads/Classifieds_images/162-hall11.png','2017-02-09 11:58:53'),(8,167,'assets/uploads/Classifieds_images/167-1485867746_2.jpg','2017-02-09 17:37:14'),(9,167,'assets/uploads/Classifieds_images/167-1485867746_21.jpg','2017-02-09 17:52:45'),(10,256,'assets/uploads/Classifieds_images/256-acb92256fb75a47080e4c8044ab11e8b.jpg','2017-02-25 11:28:45'),(11,256,'assets/uploads/Classifieds_images/256-1485926150_7.jpg','2017-02-25 11:29:09'),(12,256,'assets/uploads/Classifieds_images/256-3878024-wallpaper-for-desktop.jpg','2017-02-25 11:29:16');
/*!40000 ALTER TABLE `classified_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classifieds_ads`
--

DROP TABLE IF EXISTS `classifieds_ads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classifieds_ads` (
  `ad_id` int(50) NOT NULL AUTO_INCREMENT,
  `provider_id` int(50) NOT NULL,
  `ad_unique` varchar(50) NOT NULL,
  `ad_company` varchar(400) NOT NULL,
  `ad_contact` varchar(400) NOT NULL,
  `ad_mobile` varchar(250) NOT NULL,
  `ad_email` varchar(100) NOT NULL,
  `ad_website` varchar(700) DEFAULT NULL,
  `ad_address` varchar(500) NOT NULL,
  `ad_country` int(20) NOT NULL,
  `ad_state` int(20) NOT NULL,
  `ad_city` int(20) NOT NULL,
  `ad_description` longtext NOT NULL,
  `ad_datetime` datetime NOT NULL,
  `ad_status` int(11) NOT NULL,
  `ad_delete_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`ad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classifieds_ads`
--

LOCK TABLES `classifieds_ads` WRITE;
/*!40000 ALTER TABLE `classifieds_ads` DISABLE KEYS */;
INSERT INTO `classifieds_ads` VALUES (1,75,'F7MGC41y','FX Hub Weddings','Abhi','9447413883','classi1@gmail.com','www.fxhub.com/',' Kothamangalam, Kerala 686691',1,19,1,'hellos','2017-01-16 20:03:32',1,1),(2,75,'ZvNYOroC','FX Hub Weddings -Cochin','Ajith','9447413883','classi1@gmail.com','www.fxhub.com/',' Kothamangalam, Kerala 686691',1,19,1,'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English.','2017-01-17 10:04:39',1,1),(3,75,'KytyQLmZ','FX Hub Weddings','Ammu','9447413883','classi1@gmail.com','www.fxhub.com/',' Kothamangalam, Kerala 686691',1,19,1,'Hewlo ples contact me','2017-01-20 10:47:22',1,1),(4,143,'nITmRi2C','Techs Events','Avinash','9567783111','techs@gmail.com','http://192.168.138.31/Akhil/Wedding_web_akhil/classifieds/home/post_ads','Alappuzha PO, Alappuzha',1,19,4,'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.','2017-02-06 10:46:20',1,1),(5,143,'K7k02KiR','Big Deals - on Jewellery','Akash','9567783111','techs@gmail.com','www.test.com/ddd.json','Alappuzha PO, Alappuzha',1,19,4,'123456','2017-02-06 12:15:01',0,1),(8,162,'F5CGej28','testing','jai','122334455678','test123@gmail.com','http://www.telugucatholicmatrimony.com/','ewsrfref rfegtre5yrtgg',1,19,4,'test','2017-02-08 18:40:40',1,0),(9,162,'6lHKzTH3','testing','jai','1223344555','test123@gmail.com','http://www.telugucatholicmatrimony.com/','ewsrfref rfegtre5y',1,19,1,'test 12345','2017-02-09 12:49:56',0,0),(10,167,'9qK3U23T','daniel','daniel','7894561233','special@gmail.com','http://specialevents.com/weddings/','News and trends for professional wedding planners and coordinators on wedding design and business management',1,19,1,'News and trends for professional wedding planners and coordinators on wedding design and business management','2017-02-09 16:35:49',1,1),(11,167,'hcsKBC4P','daniel','daniel','7894561233','special@gmail.com','http://specialevents.com/weddings/','News and trends for professional wedding planners and coordinators on wedding design and business management',1,19,1,'News and trends for professional wedding planners and coordinators on wedding design and business management','2017-02-09 16:40:59',1,0),(12,167,'ypRQbtqK','daniel','daniel','7894561233','special@gmail.com','http://specialevents.com/weddings/','News and trends for professional wedding planners and coordinators on wedding design and business management',1,19,1,'News and trends for professional wedding planners and coordinators on wedding design and business management','2017-02-13 17:56:59',1,1),(13,207,'iN9Vi53o','eventia','eventia','4535353','eventia@gmail.com','http://www.eventia.in//','Eventia is a story of 11 teenage friends, who made a good team in their school and locality, enthusiastic about conducting and organizing events around them. As time passed they carried on with their lives, with their higher studies. They missed each others’ companies a lot and found a way to get united again. To be together, they converted their passion of organizing events, a creative way, into a business.',1,19,4,'http://www.eventia.in/','2017-02-13 18:50:46',1,1),(14,172,'Z1sP0CJA','Amazing Stage Decorations - Cochin Events','Abijith','9898987845','kochi@gmail.com','http://www.kochi.com/','Cochin',1,19,1,'The Name Red Carpet has been chosen wisely, we spread it in front of you to realize your dream events. MICE, Weddings, Birthday parties,Conferences, Employee Meets, BTL & Brand activations are to name a few of the services. . Established in the year 2002, at Kochi, the commercial capital of Kerala, Red Carpet Events has now branches all across Kerala and associates all over India, to make an event happen right in front of you.','2017-02-17 14:58:35',1,1),(15,256,'zTH3URC1','chandy','chandy','3542354540','test@gmail.com','http://www.test.com/',' edryery ery eyeyeryeryeryery',1,19,1,'bgd hdfh dfh dhfdhdfh dfhdfh dfhsdfh dh dfh 6636356jru     gsdgsd@#!$#$ dfgdfg dfgdfgdfg','2017-02-25 11:42:17',1,1);
/*!40000 ALTER TABLE `classifieds_ads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classifieds_ads_categories`
--

DROP TABLE IF EXISTS `classifieds_ads_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classifieds_ads_categories` (
  `ads_category_id` int(50) NOT NULL AUTO_INCREMENT,
  `ad_id` int(50) NOT NULL,
  `category_id` int(50) NOT NULL,
  PRIMARY KEY (`ads_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classifieds_ads_categories`
--

LOCK TABLES `classifieds_ads_categories` WRITE;
/*!40000 ALTER TABLE `classifieds_ads_categories` DISABLE KEYS */;
INSERT INTO `classifieds_ads_categories` VALUES (1,1,6),(2,1,14),(3,1,13),(4,2,16),(5,2,48),(6,2,70),(7,3,12),(8,3,19),(9,3,38),(10,3,39),(11,4,17),(12,4,21),(13,4,41),(14,5,12),(15,5,19),(16,5,38),(17,5,39),(18,5,61),(19,6,21),(20,6,28),(21,7,3),(22,7,12),(23,8,3),(24,9,6),(25,9,3),(26,9,9),(27,10,12),(28,10,15),(29,10,16),(30,11,12),(31,11,15),(32,11,16),(33,12,12),(34,12,13),(35,13,16),(36,13,40),(37,14,56),(38,14,57),(39,15,9),(40,15,16),(41,15,56),(42,15,71);
/*!40000 ALTER TABLE `classifieds_ads_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classifieds_ads_gallery`
--

DROP TABLE IF EXISTS `classifieds_ads_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classifieds_ads_gallery` (
  `gallery_id` int(50) NOT NULL AUTO_INCREMENT,
  `ad_id` int(50) NOT NULL,
  `image_location` varchar(300) NOT NULL,
  `image_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`gallery_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classifieds_ads_gallery`
--

LOCK TABLES `classifieds_ads_gallery` WRITE;
/*!40000 ALTER TABLE `classifieds_ads_gallery` DISABLE KEYS */;
INSERT INTO `classifieds_ads_gallery` VALUES (1,1,'assets/uploads/ads/1484577212-Penguins.jpg',1),(2,1,'assets/uploads/ads/1484577212-Tulips.jpg',1),(3,2,'assets/uploads/ads/1484627680-Desert.jpg',1),(4,2,'assets/uploads/ads/1484627680-Koala.jpg',1),(5,3,'assets/uploads/ads/1484889442-51b91bba5a3fd9b6c8b9c53bc0ab6c65.jpg',1),(6,4,'assets/uploads/ads/1486358180-profile_img.png',1),(7,4,'assets/uploads/ads/1486358180-Profile-Pic.png',1),(8,4,'assets/uploads/ads/1486358180-Tara-Alisha-Berry-Height-Weight-Bra-Pics-Profile.jpg',1),(9,5,'assets/uploads/ads/1486363502-58.png',1),(12,8,'assets/uploads/ads/1486559440-wed-logo.jpg',1),(13,9,'assets/uploads/ads/1486624797-hall4.png',1),(14,10,'assets/uploads/ads/1486638349-Baskin-Robbins-OREO-N-Cake.jpg',1),(15,11,'assets/uploads/ads/1486638659-acb92256fb75a47080e4c8044ab11e8b.jpg',1),(16,11,'assets/uploads/ads/1486638659-Cala-di-Volpe-Hotel-CostaSmeralda-Wedding-Couple-with-Bouquet.jpg',1),(17,11,'assets/uploads/ads/1486638660-onelove-wedding-01.jpg',1),(18,12,'assets/uploads/ads/1486988819-2015_-_1.png',1),(19,13,'assets/uploads/ads/1486992046-1485926150_7.jpg',1),(20,13,'assets/uploads/ads/1486992046-acb92256fb75a47080e4c8044ab11e8b.jpg',1),(21,14,'assets/uploads/ads/1487323715-7.jpg',1),(22,14,'assets/uploads/ads/1487323715-profile-pics12.jpg',1),(23,15,'assets/uploads/ads/1488003138-1485926150_7.jpg',1),(24,15,'assets/uploads/ads/1488003138-acb92256fb75a47080e4c8044ab11e8b.jpg',1),(25,15,'assets/uploads/ads/1488003138-Cala-di-Volpe-Hotel-CostaSmeralda-Wedding-Couple-with-Bouquet.jpg',1);
/*!40000 ALTER TABLE `classifieds_ads_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classifieds_categories`
--

DROP TABLE IF EXISTS `classifieds_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classifieds_categories` (
  `category_id` int(50) NOT NULL AUTO_INCREMENT,
  `category_parent` int(50) NOT NULL DEFAULT '0',
  `category_name` varchar(200) NOT NULL,
  `category_rank` int(50) DEFAULT '0',
  `category_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classifieds_categories`
--

LOCK TABLES `classifieds_categories` WRITE;
/*!40000 ALTER TABLE `classifieds_categories` DISABLE KEYS */;
INSERT INTO `classifieds_categories` VALUES (3,5,'Accessories',NULL,1),(4,59,'Air / Rail / Bus Ticketing',NULL,1),(5,0,'Apparel & Accessories',NULL,1),(6,7,'Astrologers And Numerologists',NULL,1),(7,0,'Astrology & Religious Services',NULL,1),(9,72,'Banquets, Party Halls & Hotels',NULL,1),(10,0,'Beauty & Grooming',NULL,1),(11,10,'Beauty Parlours / Salons',NULL,1),(12,39,'Bridal Jewellery',NULL,1),(13,10,'Bridal Makeup Artist',NULL,1),(14,5,'Bridal Wear',NULL,1),(15,28,'Cake & Sweet Shops, Ice-Cream Vendors',NULL,1),(16,69,'Candid Photographers',NULL,1),(17,28,'Caterers',NULL,1),(18,45,'Choreographers & Dancers',NULL,1),(19,39,'Contemporary Fashion Jewellery',NULL,1),(20,33,'Cosmetic Surgeons',NULL,1),(21,0,'Decorators',0,1),(22,10,'Dental Care',NULL,1),(23,5,'Designers & Boutiques',NULL,1),(24,39,'Diamonds & Precious Stones',NULL,1),(25,45,'DJs',NULL,1),(26,21,'Fireworks',NULL,1),(27,0,'Florists & Flower Decorators',NULL,1),(28,0,'Food & Beverages',NULL,1),(29,0,'Ghodi Wale',NULL,1),(30,39,'Gold',NULL,1),(31,5,'Groom Wear',NULL,1),(32,10,'Hair Care',0,1),(33,0,'Health & Wellness',NULL,1),(34,0,'Home Furnishings',NULL,1),(35,0,'Honeymoon Packages',0,1),(36,37,'Hotels',NULL,1),(37,0,'Hotels & Accommodation',1,1),(38,39,'Imitation Jewellery',NULL,1),(39,0,'Jewellery',1,1),(40,21,'Lightings & Sounds',NULL,1),(41,72,'Mandaps & Marriage Halls',NULL,1),(42,0,'Marriage Counsellors',NULL,1),(43,0,'Marriage Loan',NULL,1),(44,10,'Mehendi Artist',NULL,1),(45,0,'Music & Entertainment',1,1),(46,45,'Orchestras',NULL,1),(47,7,'Pandits & Priests',NULL,1),(48,69,'Photo Booths',NULL,1),(49,33,'Pre-Marital Health Check-up',NULL,1),(50,72,'Resorts & Farm House',NULL,1),(51,37,'Service Apartments & Guest Houses',NULL,1),(52,21,'Shamiyana / Tent Houses',NULL,1),(53,33,'Skin Clinics',NULL,1),(54,33,'Slimming Centers & Health Clubs',NULL,1),(55,33,'Spas',NULL,1),(56,21,'Stage / Mandap Decorators',NULL,1),(57,45,'Stage Performers & MCs / Host',NULL,1),(59,0,'Tours & Travels',NULL,1),(60,45,'Traditional Musicians',NULL,1),(61,39,'Traditional Wedding Jewellery',NULL,1),(62,0,'Videographers',1,1),(63,62,'Webcasting',NULL,1),(64,45,'Wedding Bands',NULL,1),(65,0,'Wedding Cards',0,1),(66,59,'Wedding Cars on Rent',NULL,1),(67,5,'Wedding Dress on Rent',NULL,1),(68,0,'Wedding Gifts',NULL,1),(69,0,'Wedding Photographers',1,1),(70,69,'Wedding Photography',NULL,1),(71,27,'Wedding Planners & Contractors',NULL,1),(72,0,'Wedding Venues',2,1),(74,65,'Cards',0,1),(75,68,'Wedding Gifts',0,1),(76,35,'Honeymoon Packages',0,1),(77,29,'Godhi Wale',0,1),(78,43,'Marriage Loan',0,1),(79,34,'Home Furnishings',0,1),(80,42,'Marriage Counsellors',0,1),(81,0,'Arbana',0,1),(82,81,'Arbana Sub 1',0,1),(83,0,'Arbana V2',0,1),(84,0,'Arbana V3',0,1),(85,84,'Arbana V3 subs ',0,1);
/*!40000 ALTER TABLE `classifieds_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classifieds_providers`
--

DROP TABLE IF EXISTS `classifieds_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `classifieds_providers` (
  `provider_id` int(50) NOT NULL AUTO_INCREMENT,
  `user_id` int(50) NOT NULL,
  `provider_name` varchar(300) NOT NULL,
  `provider_description` longtext NOT NULL,
  `provider_country` int(20) NOT NULL,
  `provider_state` int(20) NOT NULL,
  `provider_city` int(20) NOT NULL,
  `provider_address` longtext,
  `provider_email` varchar(200) DEFAULT NULL,
  `provider_phone` varchar(40) DEFAULT NULL,
  `provider_password` varchar(100) NOT NULL,
  `provider_website` varchar(100) DEFAULT NULL,
  `provider_modified` datetime DEFAULT NULL,
  `provider_status` int(20) NOT NULL DEFAULT '1',
  PRIMARY KEY (`provider_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classifieds_providers`
--

LOCK TABLES `classifieds_providers` WRITE;
/*!40000 ALTER TABLE `classifieds_providers` DISABLE KEYS */;
INSERT INTO `classifieds_providers` VALUES (2,75,'FX Hub Weddings','FX hub have a good team of energetic, creative, and friendly expert photographers and videographers with a passion for what they do. \r\nIn the field of photography and filming we are well known for professional studio portraits, family portraits, kids photography, fashion &modeling photography, industrial, advertising and commercial\r\nphotography, events like seminars, conferences, engagements,weddings & birthday parties',1,19,1,' Kothamangalam, Kerala 686691','classi1@gmail.com','9447413883','','www.fxhub.com','2017-01-15 00:00:00',1),(3,75,'FX Hub Weddings','FX hub have a good team of energetic, creative, and friendly expert photographers and videographers with a passion for what they do. \r\nIn the field of photography and filming we are well known for professional studio portraits, family portraits, kids photography, fashion &modeling photography, industrial, advertising and commercial\r\nphotography, events like seminars, conferences, engagements,weddings & birthday parties',1,19,1,' Kothamangalam, Kerala 686691','classi1@gmail.com','9447413883','','www.fxhub.com','2017-01-15 00:00:00',1),(4,0,'test','test',1,19,1,'test','test@gmail.com','3243535','ivGL9YE6fVzRN5cmby4paPcClFXlXSQS9XotyM/wOnbiTkVYn3AOslQuhmwrLYcZTAwvPpeOeVWE985NqPd6rA==','test.com','2017-01-21 18:38:02',1),(5,83,'Kripa Events','Kripa Events',1,19,3,'Trivandrum','classi2@gmail.com','1223344555','2Xcw9XAu1q5owGyxNfXBlPQuuAqilhy5eujBSaM9sDl2Q+4ZUZOTpvF3BBTHyVRlOrz00A0ZA8KGzPJAuOI6Mg==+MhMPsWGYLqU','www.kripa.com','2017-01-21 18:45:02',1),(9,88,'sadsad','adasds',1,19,1,'dsfsdfdsfd','sadfs@gmail.com','fsdfsdfds','/uH9O+lHOqxqDXpOtLpOcqRwV473FiMHpyxCRJ2JgYZv5IQMCQLuZUEArSKcWULfgkDGMsmfi/hauo2d4Ld2ww==','sdsf.ciom','2017-01-21 19:30:19',1),(10,89,'EXECUTIVE EVENTS','Executive Events is a company with extensive experience in managing and organising corporate and product based events, medical, scientific and industrial conferences, seminars, weddings, private parties, theme parties etc. Executive Events is the first and only ISO 9001-2008 certified event management company in Kerala, India. The company has a decade’s worth of experience in organizing and executing successful events. Today, it stands a firm ground in managing varied events.',1,19,1,'KV 8, 5TH Cross Road | Panampilly Nagar | Kochi-682036.\r\n\r\nHand Phone: +91 9947058123 \r\n\r\nTelephone: 0484 4030537 / 0484 2317070 ','executive@gmail.com','7788996655','21Pv1gDD33OfhRYSquLnysC8sM1cvL9AOh9mTQJ8MPCWN+33Y11m3WLjVRuqX8pWi5DsA86zWOz6C8kNMF+XSA==','http://executiveevents.in/','2017-01-21 19:39:10',2),(11,143,'Techs Events','abcdefghijklmnopqrstuvwxyz',1,19,4,'Alappuzha PO, Alappuzha','techs@gmail.com','9567783111','F1OYmb9ZzSDGPPL0o8DYp3NKXu0xAVRtGKSIy1FIB4ylp6oLp+Tdz2txJCWy0uDhBiOSuijBRh/CeGoBnjycWA==','www.test.com','2017-02-06 10:41:45',2),(12,151,'','',0,0,0,'','','','fjipXg3mLi+0PenrhiRKREAf0w9/du8QHAURD+IF5K52bAin8TpMJocjva61YEQ3FAcg0lzAirOSArD2pByC1w==','http://','2017-02-06 16:08:32',0),(14,154,'','',0,0,0,'','','','p+ajqLr2H6Csl1opEDBCeCbF2t8IHA6mEpbQE4zmS0dKgO7ZyqM3OTr+4yD02DvbhnqlVkws0zQedShkn0k/ug==','http://','2017-02-06 18:11:19',0),(15,162,'testing','testing',1,19,1,'ewsrfref rfegtre5y','test123@gmail.com','1223344555','j7R8i9ymIhVoCOcQx0W6sTdbnEvTFHoj9s9FgupDKYiqoysB0fc27SQrbMFrMeoHIIQeqsFFlZ3XzfN8sBYi1g==','http://www.telugucatholicmatrimony.com','2017-02-08 18:39:26',1),(16,167,'daniel','special events',1,19,1,'News and trends for professional wedding planners and coordinators on wedding design and business management','special@gmail.com','7894561233','Dpwit+m7se+n/WEsnI7jZMUt+an/ZE8AZVCWcv1out7A6wEc04SK878gIDT22heyU0wcawq0UTiEFcV0bF8TiA==','http://specialevents.com/weddings','2017-02-09 16:29:52',1),(17,172,'Cochin Events','abcdsz',1,19,1,'Cochin','kochi@gmail.com','11223344','7gK+JsgoLvXTOt6gg/2guvXWUPcm7MD9Uf3Ac50hW9pcEeIpq3l8JZyJFgPfTSq11zHjD6VL3KtEsrS2eDhGlg==','http://www.kochi.com','2017-02-09 20:20:37',1),(18,207,'eventia','Eventia is a story of 11 teenage friends, who made a good team in their school and locality, enthusiastic about conducting and organizing events around them. As time passed they carried on with their lives, with their higher studies. They missed each others’ companies a lot and found a way to get united again. To be together, they converted their passion of organizing events, a creative way, into a business.',1,19,4,'Eventia is a story of 11 teenage friends, who made a good team in their school and locality, enthusiastic about conducting and organizing events around them. As time passed they carried on with their lives, with their higher studies. They missed each others’ companies a lot and found a way to get united again. To be together, they converted their passion of organizing events, a creative way, into a business.','eventia@gmail.com','4535353','LM5mMQVpdMqbKW0aohpi93jbdlNY1bITvgcrHxHHKzn+5TSnq2X7eUbK02xoCAnE+hceHJPoMwBSa75sMFT6xQ==','http://www.eventia.in/','2017-02-13 18:49:18',1),(19,256,'chandy','chandy\'s events and management',1,19,4,' edryery ery eyeyeryeryeryery','test@gmail.com','35423545455','lledTe4MUskTOYPNueM/LD+wqdreBc2+EuK9vUScw5rfaxEBGtQ6r5h5mSDYB8RJYfbRUr6bj1aQdLQ8EaGTwg==','http://www.test.com','2017-02-25 11:13:37',1);
/*!40000 ALTER TABLE `classifieds_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `count_mobileviews`
--

DROP TABLE IF EXISTS `count_mobileviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `count_mobileviews` (
  `mobileviews_id` int(50) NOT NULL AUTO_INCREMENT,
  `mobileviews_viewer` int(50) NOT NULL,
  `mobileviews_viewed` int(50) NOT NULL,
  `mobileviews_datetime` datetime NOT NULL,
  PRIMARY KEY (`mobileviews_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `count_mobileviews`
--

LOCK TABLES `count_mobileviews` WRITE;
/*!40000 ALTER TABLE `count_mobileviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `count_mobileviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `count_sms`
--

DROP TABLE IF EXISTS `count_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `count_sms` (
  `sms_id` int(50) NOT NULL AUTO_INCREMENT,
  `sms_from` int(50) NOT NULL,
  `sms_to` int(50) NOT NULL,
  `sms_datetime` datetime NOT NULL,
  PRIMARY KEY (`sms_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `count_sms`
--

LOCK TABLES `count_sms` WRITE;
/*!40000 ALTER TABLE `count_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `count_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `country_id` int(20) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(200) NOT NULL,
  `country_currency` varchar(20) DEFAULT NULL,
  `country_extension` varchar(20) DEFAULT NULL,
  `country_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=latin1 COMMENT='Country Details';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'India','INR','+91',1),(2,'Australia','INR',NULL,0),(3,'test1','INR',NULL,0),(5,'United States of America (USA)','USD',NULL,1),(6,'United Kingdom (UK)','INR',NULL,1),(7,'United Arab Emirates (UAE)','INR',NULL,1),(8,'Ukraine','INR',NULL,1),(9,'Uganda','INR',NULL,1),(10,'Uruguay','INR',NULL,1),(11,'Uzbekistan','INR',NULL,1),(12,'Australia','AUD',NULL,1),(13,'Azerbaijan','INR',NULL,1),(14,'Austria','USD',NULL,1),(15,'Armenia','INR',NULL,1),(16,'Argentina','INR',NULL,1),(17,'Antigua and Barbuda','INR',NULL,1),(18,'Angola','INR',NULL,1),(19,'Andorra','INR',NULL,1),(20,'Algeria','INR',NULL,1),(21,'Albania','INR',NULL,1),(22,'Afghanistan','INR',NULL,1),(23,'Iceland','INR',NULL,1),(24,'Indonesia','INR',NULL,1),(25,'Iran','INR',NULL,1),(26,'Iraq','INR',NULL,1),(27,'Ireland','INR',NULL,1),(28,'Israel','INR',NULL,1),(29,'Italy','INR',NULL,1),(30,'Bahamas','INR',NULL,1),(31,'Bahrain','INR',NULL,1),(32,'Bangladesh','INR',NULL,1),(33,'Barbados','INR',NULL,1),(34,'Belarus','INR',NULL,1),(35,'Belgium','INR',NULL,1),(36,'Belize','INR',NULL,1),(37,'Benin','INR',NULL,1),(38,'Bhutan','INR',NULL,1),(39,'Bolivia','INR',NULL,1),(40,'Bosnia and Herzegovina','INR',NULL,1),(41,'Botswana','INR',NULL,1),(42,'Brazil','INR',NULL,1),(43,'Brunei','INR',NULL,1),(44,'Bulgaria','INR',NULL,1),(45,'Burkina Faso','INR',NULL,1),(46,'Burundi','INR',NULL,1),(47,'Cabo Verde','INR',NULL,1),(48,'Cambodia','INR',NULL,1),(49,'Cameroon','INR',NULL,1),(50,'Canada','INR',NULL,1),(51,'Central African Republic (CAR)','INR',NULL,1),(52,'Chad','INR',NULL,1),(53,'Chile','INR',NULL,1),(54,'China','INR',NULL,1),(55,'Colombia','INR',NULL,1),(56,'Comoros','INR',NULL,1),(57,'Democratic Republic of the Congo','INR',NULL,1),(58,'Republic of the Congo','INR',NULL,1),(59,'Costa Rica','INR',NULL,1),(60,'Cote d\'Ivoire','INR',NULL,1),(61,'Croatia','INR',NULL,1),(62,'Cuba','INR',NULL,1),(63,'Cyprus','INR',NULL,1),(64,'Czech Republic','INR',NULL,1),(65,'Denmark','INR',NULL,1),(66,'Djibouti','INR',NULL,1),(67,'Dominica','INR',NULL,1),(68,'Dominican Republic','INR',NULL,1),(69,'Ecuador','INR',NULL,1),(70,'Egypt','INR',NULL,1),(71,'El Salvador','INR',NULL,1),(72,'Equatorial Guinea','INR',NULL,1),(73,'Eritrea','INR',NULL,1),(74,'Estonia','INR',NULL,1),(75,'Ethiopia','INR',NULL,1),(76,'Fiji','INR',NULL,1),(77,'Finland','INR',NULL,1),(78,'France','INR',NULL,1),(79,'Gabon','INR',NULL,1),(80,'Gambia','INR',NULL,1),(81,'Georgia','INR',NULL,1),(82,'Germany','INR',NULL,1),(83,'Ghana','INR',NULL,1),(84,'Greece','INR',NULL,1),(85,'Grenada','INR',NULL,1),(86,'Guatemala','INR',NULL,1),(87,'Guinea','INR',NULL,1),(88,'Guinea-Bissau','INR',NULL,1),(89,'Guyana','INR',NULL,1),(90,'Haiti','INR',NULL,1),(91,'Honduras','INR',NULL,1),(92,'Hungary','INR',NULL,1),(93,'Jamaica','INR',NULL,1),(94,'Japan','INR',NULL,1),(95,'Jordan','INR',NULL,1),(96,'Kazakhstan','INR',NULL,1),(97,'Kenya','INR',NULL,1),(98,'Kiribati','INR',NULL,1),(99,'Kosovo','INR',NULL,1),(100,'Kuwait','INR',NULL,1),(101,'Kyrgyzstan','INR',NULL,1),(102,'Laos','INR',NULL,1),(103,'Latvia','INR',NULL,1),(104,'Lebanon','INR',NULL,1),(105,'Lesotho','INR',NULL,1),(106,'Liberia','INR',NULL,1),(107,'Libya','INR',NULL,1),(108,'Liechtenstein','INR',NULL,1),(109,'Lithuania','INR',NULL,1),(110,'Luxembourg','INR',NULL,1),(111,'Macedonia','INR',NULL,1),(112,'Madagascar','INR',NULL,1),(113,'Malawi','INR',NULL,1),(114,'Malaysia','INR',NULL,1),(115,'Maldives','INR',NULL,1),(116,'Mali','INR',NULL,1),(117,'Malta','INR',NULL,1),(118,'Marshall Islands','INR',NULL,1),(119,'Mauritania','INR',NULL,1),(120,'Mexico','INR',NULL,1),(121,'Mauritius','INR',NULL,1),(122,'Micronesia','INR',NULL,1),(123,'Moldova','INR',NULL,1),(124,'Monaco','INR',NULL,1),(125,'Mongolia','INR',NULL,1),(126,'Mongolia','INR',NULL,1),(127,'Morocco','INR',NULL,1),(128,'Mozambique','INR',NULL,1),(129,'Myanmar (Burma)','INR',NULL,1),(130,'Namibia','INR',NULL,1),(131,'Nauru','INR',NULL,1),(132,'Nepal','INR',NULL,1),(133,'Netherlands','INR',NULL,1),(134,'New Zealand','INR',NULL,1),(135,'Nicaragua','INR',NULL,1),(136,'Niger','INR',NULL,1),(137,'Nigeria','INR',NULL,1),(138,'North Korea','INR',NULL,1),(139,'Norway','INR',NULL,1),(140,'Oman','INR',NULL,1),(141,'Pakistan','INR',NULL,1),(142,'Palau','INR',NULL,1),(143,'Palestine','INR',NULL,1),(144,'Panama','INR',NULL,1),(145,'Papua New Guinea','INR',NULL,1),(146,'Paraguay','INR',NULL,1),(147,'Peru','INR',NULL,1),(148,'Philippines','INR',NULL,1),(149,'Poland','INR',NULL,1),(150,'Portugal','INR',NULL,1),(151,'Qatar','INR',NULL,1),(152,'Romania','INR',NULL,1),(153,'Russia','INR',NULL,1),(154,'Rwanda','INR',NULL,1),(155,'Saint Kitts and Nevis','INR',NULL,1),(156,'Saint Lucia','INR',NULL,1),(157,'Saint Vincent and the Grenadines','INR',NULL,1),(158,'Samoa','INR',NULL,1),(159,'San Marino','INR',NULL,1),(160,'Sao Tome and Principe','INR',NULL,1),(161,'Saudi Arabia','INR',NULL,1),(162,'Senegal','INR',NULL,1),(163,'Serbia','INR',NULL,1),(164,'Seychelles','INR',NULL,1),(165,'Sierra Leone','INR',NULL,1),(166,'Singapore','INR',NULL,1),(167,'Slovakia','INR',NULL,1),(168,'Slovenia','INR',NULL,1),(169,'Solomon Islands','INR',NULL,1),(170,'Somalia','INR',NULL,1),(171,'South Africa','INR',NULL,1),(172,'South Korea','INR',NULL,1),(173,'South Sudan','INR',NULL,1),(174,'Spain','INR',NULL,1),(175,'Sri Lanka','INR',NULL,1),(176,'Sudan','INR',NULL,1),(177,'Suriname','INR',NULL,1),(178,'Swaziland','INR',NULL,1),(179,'Sweden','INR',NULL,1),(180,'Switzerland','INR',NULL,1),(181,'Syria','INR',NULL,1),(182,'Taiwan','INR',NULL,1),(183,'Tajikistan','INR',NULL,1),(184,'Tanzania','INR',NULL,1),(185,'Thailand','INR',NULL,1),(186,'Timor-Leste','INR',NULL,1),(187,'Togo','INR',NULL,1),(188,'Tonga','INR',NULL,1),(189,'Trinidad and Tobago','INR',NULL,1),(190,'Tunisia','INR',NULL,1),(191,'Turkey','INR',NULL,1),(192,'Turkmenistan','INR',NULL,1),(193,'Tuvalu','INR',NULL,1),(194,'Vanuatu','INR',NULL,1),(195,'Vatican City (Holy See)','INR',NULL,1),(196,'Venezuela','INR',NULL,1),(197,'Vietnam','INR',NULL,1),(198,'Yemen','INR',NULL,1),(199,'Zambia','INR',NULL,1),(200,'Zimbabwe','INR',NULL,0),(209,'Test Country',NULL,NULL,0);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country_new`
--

DROP TABLE IF EXISTS `country_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country_new` (
  `country_id` int(11) NOT NULL,
  `country_name` varchar(33) NOT NULL,
  `country_currency` varchar(3) DEFAULT NULL,
  `country_extension` varchar(30) DEFAULT NULL,
  `country_status` bit(1) NOT NULL,
  PRIMARY KEY (`country_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_new`
--

LOCK TABLES `country_new` WRITE;
/*!40000 ALTER TABLE `country_new` DISABLE KEYS */;
INSERT INTO `country_new` VALUES (1,'United States of America','USD',NULL,''),(2,'India','INR',NULL,''),(3,'Pakistan',NULL,NULL,''),(4,'Philippines',NULL,NULL,''),(5,'Nigeria',NULL,NULL,''),(6,'United Kingdom',NULL,NULL,''),(7,'Germany',NULL,NULL,''),(8,'Canada',NULL,NULL,''),(9,'France',NULL,NULL,''),(10,'Australia','AUD',NULL,''),(11,'Italy',NULL,NULL,''),(12,'Bangladesh',NULL,NULL,''),(13,'Egypt',NULL,NULL,''),(14,'Thailand',NULL,NULL,''),(15,'Netherlands',NULL,NULL,''),(16,'Nepal',NULL,NULL,''),(17,'South Africa',NULL,NULL,''),(18,'Poland',NULL,NULL,''),(19,'Turkey',NULL,NULL,''),(20,'Iraq',NULL,NULL,''),(21,'Sri Lanka',NULL,NULL,''),(22,'Spain',NULL,NULL,''),(23,'China',NULL,NULL,''),(24,'Brazil',NULL,NULL,''),(25,'Sweden',NULL,NULL,''),(26,'Kenya',NULL,NULL,''),(27,'Cameroon',NULL,NULL,''),(28,'Malaysia',NULL,NULL,''),(29,'Russia',NULL,NULL,''),(30,'Belgium',NULL,NULL,''),(31,'Israel',NULL,NULL,''),(32,'Austria',NULL,NULL,''),(33,'Romania',NULL,NULL,''),(34,'Zimbabwe',NULL,NULL,''),(35,'Greece',NULL,NULL,''),(36,'Sierra Leone',NULL,NULL,''),(37,'Mexico',NULL,NULL,''),(38,'Denmark',NULL,NULL,''),(39,'Switzerland',NULL,NULL,''),(40,'Morocco',NULL,NULL,''),(41,'Norway',NULL,NULL,''),(42,'Republic of Ireland',NULL,NULL,''),(43,'Singapore',NULL,NULL,''),(44,'Ghana',NULL,NULL,''),(45,'Tanzania',NULL,NULL,''),(46,'New Zealand',NULL,NULL,''),(47,'Finland',NULL,NULL,''),(48,'Portugal',NULL,NULL,''),(49,'Papua New Guinea',NULL,NULL,''),(50,'Liberia',NULL,NULL,''),(51,'Jordan',NULL,NULL,''),(52,'Jamaica',NULL,NULL,''),(53,'Algeria',NULL,NULL,''),(54,'Uganda',NULL,NULL,''),(55,'Hong Kong',NULL,NULL,''),(56,'Czech Republic',NULL,NULL,''),(57,'Argentina',NULL,NULL,''),(58,'Yemen',NULL,NULL,''),(59,'Croatia',NULL,NULL,''),(60,'Colombia',NULL,NULL,''),(61,'Hungary',NULL,NULL,''),(62,'Puerto Rico',NULL,NULL,''),(63,'Zambia',NULL,NULL,''),(64,'Bulgaria',NULL,NULL,''),(65,'Kazakhstan',NULL,NULL,''),(66,'Lebanon',NULL,NULL,''),(67,'Chile',NULL,NULL,''),(68,'Rwanda',NULL,NULL,''),(69,'Slovakia',NULL,NULL,''),(70,'Trinidad and Tobago',NULL,NULL,''),(71,'Slovenia',NULL,NULL,''),(72,'Lithuania',NULL,NULL,''),(73,'Latvia',NULL,NULL,''),(74,'Guyana',NULL,NULL,''),(75,'Botswana',NULL,NULL,''),(76,'Estonia',NULL,NULL,''),(77,'Cyprus',NULL,NULL,''),(78,'Malawi',NULL,NULL,''),(79,'Lesotho',NULL,NULL,''),(80,'Suriname',NULL,NULL,''),(81,'Malta',NULL,NULL,''),(82,'Namibia',NULL,NULL,''),(83,'Luxembourg',NULL,NULL,''),(84,'Bahamas',NULL,NULL,''),(85,'Barbados',NULL,NULL,''),(86,'Belize',NULL,NULL,''),(87,'Madagascar',NULL,NULL,''),(88,'Mauritius',NULL,NULL,''),(89,'Vanuatu',NULL,NULL,''),(90,'Fiji',NULL,NULL,''),(91,'Solomon Islands',NULL,NULL,''),(92,'Guam',NULL,NULL,''),(93,'Brunei',NULL,NULL,''),(94,'Saint Vincent and the Grenadines',NULL,NULL,''),(95,'U.S. Virgin Islands',NULL,NULL,''),(96,'Grenada',NULL,NULL,''),(97,'Samoa',NULL,NULL,''),(98,'Isle of Man',NULL,NULL,''),(99,'Bhutan',NULL,NULL,''),(100,'Saint Lucia',NULL,NULL,''),(101,'Northern Mariana Islands',NULL,NULL,''),(102,'Antigua and Barbuda',NULL,NULL,''),(103,'American Samoa',NULL,NULL,''),(104,'Federated States of Micronesia',NULL,NULL,''),(105,'Bermuda',NULL,NULL,''),(106,'Dominica',NULL,NULL,''),(107,'Marshall Islands',NULL,NULL,''),(108,'Swaziland',NULL,NULL,''),(109,'Aruba',NULL,NULL,''),(110,'The Gambia',NULL,NULL,''),(111,'Saint Kitts and Nevis',NULL,NULL,''),(112,'Cayman Islands',NULL,NULL,''),(113,'Seychelles',NULL,NULL,''),(114,'Gibraltar',NULL,NULL,''),(115,'Tonga',NULL,NULL,''),(116,'Kiribati',NULL,NULL,''),(117,'British Virgin Islands',NULL,NULL,''),(118,'Palau',NULL,NULL,''),(119,'Andorra',NULL,NULL,''),(120,'Anguilla',NULL,NULL,''),(121,'Nauru',NULL,NULL,''),(122,'Cook Islands',NULL,NULL,''),(123,'Montserrat',NULL,NULL,'');
/*!40000 ALTER TABLE `country_new` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `name` varchar(20) DEFAULT NULL,
  `code` varchar(3) DEFAULT NULL,
  `symbol` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES ('Leke','ALL','Lek'),('Dollars','USD','$'),('Afghanis','AFN','?'),('Pesos','ARS','$'),('Guilders','AWG','ƒ'),('Dollars','AUD','$'),('New Manats','AZN','???'),('Dollars','BSD','$'),('Dollars','BBD','$'),('Rubles','BYR','p.'),('Euro','EUR','€'),('Dollars','BZD','BZ$'),('Dollars','BMD','$'),('Bolivianos','BOB','$b'),('Convertible Marka','BAM','KM'),('Pula','BWP','P'),('Leva','BGN','??'),('Reais','BRL','R$'),('Pounds','GBP','£'),('Dollars','BND','$'),('Riels','KHR','?'),('Dollars','CAD','$'),('Dollars','KYD','$'),('Pesos','CLP','$'),('Yuan Renminbi','CNY','¥'),('Pesos','COP','$'),('Colón','CRC','?'),('Kuna','HRK','kn'),('Pesos','CUP','?'),('Koruny','CZK','K?'),('Kroner','DKK','kr'),('Pesos','DOP','RD$'),('Dollars','XCD','$'),('Pounds','EGP','£'),('Colones','SVC','$'),('Pounds','FKP','£'),('Dollars','FJD','$'),('Cedis','GHC','¢'),('Pounds','GIP','£'),('Quetzales','GTQ','Q'),('Pounds','GGP','£'),('Dollars','GYD','$'),('Lempiras','HNL','L'),('Dollars','HKD','$'),('Forint','HUF','Ft'),('Kronur','ISK','kr'),('Rupees','INR','Rp'),('Rupiahs','IDR','Rp'),('Rials','IRR','?'),('Pounds','IMP','£'),('New Shekels','ILS','?'),('Dollars','JMD','J$'),('Yen','JPY','¥'),('Pounds','JEP','£'),('Tenge','KZT','??'),('Won','KPW','?'),('Won','KRW','?'),('Soms','KGS','??'),('Kips','LAK','?'),('Lati','LVL','Ls'),('Pounds','LBP','£'),('Dollars','LRD','$'),('Switzerland Francs','CHF','CHF'),('Litai','LTL','Lt'),('Denars','MKD','???'),('Ringgits','MYR','RM'),('Rupees','MUR','?'),('Pesos','MXN','$'),('Tugriks','MNT','?'),('Meticais','MZN','MT'),('Dollars','NAD','$'),('Rupees','NPR','?'),('Guilders','ANG','ƒ'),('Dollars','NZD','$'),('Cordobas','NIO','C$'),('Nairas','NGN','?'),('Krone','NOK','kr'),('Rials','OMR','?'),('Rupees','PKR','?'),('Balboa','PAB','B/.'),('Guarani','PYG','Gs'),('Nuevos Soles','PEN','S/.'),('Pesos','PHP','Php'),('Zlotych','PLN','z?'),('Rials','QAR','?'),('New Lei','RON','lei'),('Rubles','RUB','???'),('Pounds','SHP','£'),('Riyals','SAR','?'),('Dinars','RSD','???.'),('Rupees','SCR','?'),('Dollars','SGD','$'),('Dollars','SBD','$'),('Shillings','SOS','S'),('Rand','ZAR','R'),('Rupees','LKR','?'),('Kronor','SEK','kr'),('Dollars','SRD','$'),('Pounds','SYP','£'),('New Dollars','TWD','NT$'),('Baht','THB','?'),('Dollars','TTD','TT$'),('Lira','TRY','TL'),('Liras','TRL','£'),('Dollars','TVD','$'),('Hryvnia','UAH','?'),('Pesos','UYU','$U'),('Sums','UZS','??'),('Bolivares Fuertes','VEF','Bs'),('Dong','VND','?'),('Rials','YER','?'),('Zimbabwe Dollars','ZWD','Z$');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deactivation_check`
--

DROP TABLE IF EXISTS `deactivation_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deactivation_check` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `unique_id` varchar(750) NOT NULL,
  `activate_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deactivation_check`
--

LOCK TABLES `deactivation_check` WRITE;
/*!40000 ALTER TABLE `deactivation_check` DISABLE KEYS */;
INSERT INTO `deactivation_check` VALUES (1,49,'1e6db9a3d93b3a738e439d086e43cc2f',0),(2,76,'de77468e9d68efd7c12073a7d3e61386',0),(3,49,'23979cbb8b2d115c6c9f054f71fc2dd5',0),(4,76,'de61f161761f73c8a339d843ea38c6bf',0),(5,49,'d79ab77cddc87d80511c3c135e699042',0),(6,76,'e6780f107a3b1639f7822ecc647863f0',0),(7,49,'2871940ef44e74db7c86038cb1b04d4f',0),(8,76,'f7683c526f024d18be0dc8fe0229a310',0),(9,49,'2860aad8c6743761c23f7495903e5e80',0),(10,76,'9cdba19cb3d62aa9fa114949fa27f1c1',0),(11,44,'536d0e907c019cebf225c55f80626f79',1),(12,44,'181b6a3cef09fa169a7d7f27e05c3d07',0),(13,44,'8b78b5dc75c2402adc7cb29e34fbd778',1),(14,44,'7695d6e5d73aeeb501fe14c07818b402',0),(15,150,'46219327fe324e7c7b850e7e4b0e452a',1),(16,150,'3bb68012fa59fb272783f7d2d6b75f84',0),(17,44,'a3c2f9667cf231640ef0ced0a3fa8c49',1),(18,44,'eb5d28fe9f58e8d44fbb55446bcffa30',1),(19,44,'3e00e40d3909360fc998bad26a89e0a9',1);
/*!40000 ALTER TABLE `deactivation_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `educations`
--

DROP TABLE IF EXISTS `educations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `educations` (
  `education_id` int(20) NOT NULL AUTO_INCREMENT,
  `education_parent` int(10) DEFAULT '0',
  `education` varchar(100) NOT NULL,
  `education_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`education_id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1 COMMENT='Base education';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `educations`
--

LOCK TABLES `educations` WRITE;
/*!40000 ALTER TABLE `educations` DISABLE KEYS */;
INSERT INTO `educations` VALUES (1,0,'Aeronautical Engineering',1),(2,0,'B.Arch',0),(3,0,'BCA',0),(4,0,'BE',1),(5,0,'B.Tech',0),(6,0,'M.Arch.',0),(7,0,'MCA',0),(8,0,'ME',0),(9,0,'M.Tech.',0),(10,0,'Msc',0),(11,0,'B Sc',0),(12,0,'ME',0),(13,0,'Aeronautical Engineering',0),(14,0,'B.Arch',0),(15,0,'BCA',0),(16,0,'Higher Secondary School / High School',1),(17,0,'Diploma / Others',1),(18,0,'Ph.D',1),(19,0,'Other Degree in Service',1),(20,0,'IPS',1),(21,0,'IRS',1),(22,0,'IFS',1),(23,0,'IES',1),(24,0,'IAS',1),(25,0,'Other Degree in Finance',1),(26,0,'ICWA',1),(27,0,'CS',1),(28,0,'CFA (Charted Financial Analyst)',1),(29,0,'CA',1),(30,0,'Other Master Degree in Legal',1),(31,0,'M.L',1),(32,0,'LL.M',1),(33,0,'Masters – Legal / Others',1),(34,0,'Other Bachelor Degree in Legal',1),(35,0,'LLB',1),(36,0,'B.L',1),(37,0,'BGL',1),(38,0,'Bachelors – Legal / Others',1),(39,0,'Other Master Degree in Medicine',1),(40,0,'MVSc',1),(41,0,'MPT',1),(42,0,'M.Pharm',1),(43,0,'MD/MS(Medical)',1),(44,0,'MDS',1),(45,0,'Masters- Medicine-General / Dental / Surgeon / Others',1),(46,0,'Other Bachelor Degree in Medicine',1),(47,0,'B.Sc. Nursing',1),(48,0,'MBBS',1),(49,0,'BVSc',1),(50,0,'BUMS',1),(51,0,'BPT',1),(52,0,'BPharm',1),(53,0,'BSMS',1),(54,0,'BHMS',1),(55,0,'BDS',1),(56,0,'B.A.M.S',1),(57,0,'MHRM(Human Resource Management).',1),(58,0,'MHM (Hotel Management)',1),(59,0,'MFIM (Financial Management)',1),(60,0,'MBA',1),(61,0,'Masters- Management / Others',1),(62,0,'Other Bachelor Degree in Management',1),(63,0,'BHM(Hotel Management)',1),(64,0,'BFM (Financial Management)',1),(65,0,'BBA',1),(66,0,'Bachelors – Management /Others ',1),(67,0,'Other Master Degree in Arts / Science /Commerce',1),(68,0,'M.Phil',1),(69,0,'MSW',1),(70,0,'M.Sc',1),(71,0,'MLIS',1),(72,0,'Masters – Arts / Science / Commerce /  Others',1),(73,0,'Other Bachelor Degree in Arts / Science / Commerce',1),(74,0,'B.Phil',1),(75,0,'B.S.W',1),(76,0,'B.Sc',1),(77,0,'B.M.M',1),(78,0,'BLIS',1),(79,0,'BFT',1),(80,0,'BFA',1),(81,0,'B.Ed',1),(82,0,'B.Com',1),(83,0,'B.A',1),(84,0,'Aviation Degree',1),(85,0,'Bachelors- Arts / Science / Commerce / Others –',1),(86,0,'Other Masters Degree in Engineering / Computers',1),(87,0,'PGDCA',1),(88,0,'M.Tech.',1),(89,0,'M.S.(Engg)',1),(90,0,'M.Sc . IT / Computer Science',1),(91,0,'ME',1),(92,0,'MCA',1),(93,0,'M.Arch',1),(94,0,'Masters-Engineering / Computers / Others',1),(95,0,'Other Bachelor Degree in Engineering /Computers',1),(96,0,'B.Tech',1),(97,0,'B.Sc IT/Computer Science',1),(98,0,'B.Plan',1),(100,0,'BCA',1),(101,0,'B.Arch',1),(102,0,'Aeronautical Engineering',0),(103,0,'Bachelors- Engineering-Computers-Others ',1),(104,0,'Test',0),(105,0,'ssss',0),(106,0,'ssss',0),(107,0,'SSC',1),(108,0,'COMPUTER ENGINEER',1);
/*!40000 ALTER TABLE `educations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employed_in`
--

DROP TABLE IF EXISTS `employed_in`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employed_in` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employed_in_name` varchar(100) NOT NULL,
  `employed_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employed_in`
--

LOCK TABLES `employed_in` WRITE;
/*!40000 ALTER TABLE `employed_in` DISABLE KEYS */;
INSERT INTO `employed_in` VALUES (1,'private sector',1);
/*!40000 ALTER TABLE `employed_in` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `height`
--

DROP TABLE IF EXISTS `height`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `height` (
  `height_id` int(10) NOT NULL AUTO_INCREMENT,
  `height` varchar(20) NOT NULL,
  PRIMARY KEY (`height_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=latin1 COMMENT='Height details';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `height`
--

LOCK TABLES `height` WRITE;
/*!40000 ALTER TABLE `height` DISABLE KEYS */;
INSERT INTO `height` VALUES (1,'150cm - 4ft 11.05'),(2,'151cm - 4ft 11.44'),(3,'152cm - 4ft 11.84'),(4,'153cm - 5ft 0.23'),(5,'154cm - 5ft 0.63'),(6,'155cm - 5ft 1.02'),(7,'156cm - 5ft 1.41'),(8,'157cm - 5ft 1.81'),(9,'158cm - 5ft 2.20'),(10,'159cm - 5ft 2.59'),(11,'160cm - 5ft 2.99'),(12,'161cm - 5ft 3.38'),(13,'162cm - 5ft 3.77'),(14,'163cm - 5ft 4.17'),(15,'164cm - 5ft 4.56'),(16,'165cm - 5ft 4.96'),(17,'166cm - 5ft 5.35'),(18,'167cm - 5ft 5.74'),(19,'168cm - 5ft 6.14'),(20,'169cm - 5ft 6.53'),(21,'170cm - 5ft 6.92'),(22,'171cm - 5ft 7.32'),(23,'172cm - 5ft 7.71'),(24,'173cm - 5ft 8.11'),(25,'174cm - 5ft 8.50'),(26,'175cm - 5ft 8.89'),(27,'176cm - 5ft 9.29'),(28,'177cm - 5ft 9.68'),(29,'178cm - 5ft 10'),(30,'179cm - 5ft 10.47'),(31,'180cm - 5ft 10.86'),(32,'181cm - 5ft 11.26'),(33,'182cm - 5ft 11.65'),(34,'183cm - 6ft'),(35,'184cm - 6ft 0.44'),(36,'185cm - 6ft 0.83'),(37,'186cm - 6ft 1.22'),(38,'187cm - 6ft 1.62'),(39,'188cm - 6ft 2.0 1'),(40,'189cm - 6ft 2.40'),(41,'190cm - 6ft 2.80'),(42,'191cm - 6ft 3.19'),(43,'192cm - 6ft 3.59'),(44,'193cm - 6ft 3.98'),(45,'194cm - 6ft 4.37'),(46,'195cm - 6ft 4.77'),(47,'196cm - 6ft 5.16'),(48,'197cm - 6ft 5.55'),(49,'198cm - 6ft 5.95'),(50,'199cm - 6ft 6.34'),(51,'200cm - 6ft 6.74'),(52,'201cm - 6ft 7.13'),(53,'202cm - 6ft 7.52'),(54,'203cm - 6ft 7.92'),(55,'204cm - 6ft 8.31'),(56,'205cm - 6ft 8.70'),(57,'206cm - 6ft 9.10'),(58,'207cm - 6ft 9.49'),(59,'208cm - 6ft 9.88'),(60,'209cm - 6ft 10.2'),(61,'210cm - 6ft 10.67'),(62,'211cm - 6ft 11.07'),(63,'212cm - 6ft 11.45'),(64,'213cm - 6ft 11.85'),(65,'214cm - 7ft 0.25'),(66,'215cm - 7ft 0.64'),(67,'216cm - 7ft 1.03'),(68,'217cm - 7ft 1.43'),(69,'218cm - 7ft 1.82'),(70,'219cm - 7ft 2.22'),(71,'220cm - 7ft 2.61'),(72,'221cm - 7ft 3'),(73,'222cm - 7ft 3.40'),(74,'223cm - 7ft 3.79'),(75,'224cm - 7ft 4.18'),(76,'225cm - 7ft 4.58');
/*!40000 ALTER TABLE `height` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `helpline_numbers`
--

DROP TABLE IF EXISTS `helpline_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `helpline_numbers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `helpline_numbers`
--

LOCK TABLES `helpline_numbers` WRITE;
/*!40000 ALTER TABLE `helpline_numbers` DISABLE KEYS */;
INSERT INTO `helpline_numbers` VALUES (1,'INDIA','+91-4567893456',1),(2,'UK','+5698622689',1),(3,'Singapore','+36598652114',1);
/*!40000 ALTER TABLE `helpline_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `history_id` int(30) NOT NULL AUTO_INCREMENT,
  `history_type` varchar(100) NOT NULL,
  `history_foreign` int(30) DEFAULT NULL,
  `history_from` int(20) NOT NULL,
  `history_to` int(20) NOT NULL,
  `history_status` int(10) NOT NULL,
  `history_message` longtext,
  `status` int(11) NOT NULL DEFAULT '0',
  `trash` int(11) DEFAULT '0',
  `history_datetime` datetime NOT NULL,
  PRIMARY KEY (`history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
INSERT INTO `history` VALUES (1,'INTEREST_SENT',1,5136172,7535161,1,'',0,0,'2017-07-19 17:19:04'),(2,'INTEREST_SENT',2,7180214,7535161,0,'',0,0,'2017-07-19 17:20:30'),(3,'MESSAGE_SENT',25,4005106,5136172,1,'Hi Aswathi',0,0,'2019-03-21 15:50:14'),(4,'MESSAGE_SENT',26,4005106,6932446,1,'Hi bhavi\r\n\r\nijsxz ksmalzx nkmsalzx nm sazxm sazx\r\njszxnk  cszxnk  sknazxm ndc zx dczxkm',0,0,'2019-03-21 15:51:08'),(5,'INTEREST_SENT',3,9951422,5136172,0,'',0,0,'2019-03-23 11:50:30'),(6,'INTEREST_SENT',4,2439709,5136172,0,'',0,0,'2019-05-04 15:52:52'),(7,'MESSAGE_SENT',27,46690,16912,1,'Hi mounikanarayana',0,0,'2019-06-19 17:30:22'),(8,'INTEREST_SENT',5,46690,16912,0,'',0,0,'2019-06-19 17:30:26'),(9,'MESSAGE_SENT',28,10249,29516,1,'Hy swetha',1,0,'2019-06-30 19:28:42'),(10,'MESSAGE_SENT',29,10249,16912,1,'Hi mounikanarayana',0,0,'2019-06-30 19:42:31'),(11,'INTEREST_SENT',6,10249,16912,0,'',0,0,'2019-07-04 09:02:40'),(12,'MESSAGE_SENT',30,10249,16912,1,'Hy mounikanarayana',0,0,'2019-07-04 09:03:51'),(13,'MESSAGE_SENT',31,10249,16912,1,'Hy mounikanarayana',0,0,'2019-07-16 11:54:46'),(14,'INTEREST_SENT',7,29653,46690,0,'',0,1,'2019-07-23 12:40:03'),(15,'PHOTO_REQUEST',1,29653,10249,1,'',1,1,'2019-07-25 12:42:07'),(16,'MESSAGE_SENT',32,29653,10249,1,'Hi Siva\r\n\r\nHiokasok msaoojkmsam as ',1,1,'2019-07-25 12:46:28'),(17,'INTEREST_SENT',8,29653,10249,0,'',1,1,'2019-07-25 12:58:56'),(18,'INTEREST_SENT',9,29653,69285,0,'',1,1,'2019-07-25 12:58:59'),(19,'MESSAGE_SENT',33,29653,69285,1,'Hi Munipalle Rajesh Kumar',1,1,'2019-07-25 12:59:17'),(20,'MESSAGE_SENT',34,29653,69285,1,'Hi Munipalle Rajesh Kumar',1,1,'2019-07-25 12:59:17'),(21,'MESSAGE_SENT',35,29653,10249,1,'Hi Siva',1,1,'2019-07-25 12:59:27');
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hobbies`
--

DROP TABLE IF EXISTS `hobbies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hobbies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) NOT NULL,
  `hobbies` text NOT NULL,
  `music` text NOT NULL,
  `sports` text NOT NULL,
  `languages` text NOT NULL,
  `other_hobbies` text NOT NULL,
  `other_music` text NOT NULL,
  `other_sports` text NOT NULL,
  `other_languages` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hobbies`
--

LOCK TABLES `hobbies` WRITE;
/*!40000 ALTER TABLE `hobbies` DISABLE KEYS */;
INSERT INTO `hobbies` VALUES (8,'7577796','Movies,Landscape','Western Music','Tennis','english,hindi,kannada,malayalam,Tamil','','','',''),(9,'6539442','cooking,nature,movies,dancing,','film,western,classic,','cricket,carrom,football,gym,','english,hindi,tamil,telugu,kannada,','','','',''),(10,'5980622','cooking,nature,','film,western,','football,tennis,','english,hindi,tamil,malayalam','','','',''),(11,'9878476','cooking,nature,movies,dancing,painting,internet,travel,pets,landscape,puzzle,musics,photo,add','film,western,classic,rock','cricket,jogging,badminton,football,dfsdf','english,hindi,tamil,sdfsdf','','','',''),(12,'4906686','cooking,nature,movies,dancing,painting,travel,pets,landscape,puzzle,','film,western,classic,','carrom,jogging,badminton,','hindi,tamil,telugu,','','','',''),(13,'4921067','Cooking,Internet,Painting','Film Songs','Cricket,Badminton','Malayalam,Hindi,Tamil','','','',''),(14,'5310265','nature,movies,dancing,painting,travel,photo,','film,','jogging,badminton,tennis,','english,hindi,tamil,','','','',''),(15,'1923511','Cooking,Internet,Travel,Photo,Painting','Film Songs','Cricket,Badminton,Carrom','Malayalam,Hindi,Tamil','','','',''),(16,'7520209','cooking,movies,dancing,travel,puzzle,musics,photo,','western,','jogging,badminton,tennis,','english,hindi,tamil,','','','',''),(17,'4981072','nature,movies,dancing,','film,western,classic,','tennis,','marathi,','','','',''),(18,'6467798','cooking,nature,travel,pets,','film,western,','jogging,badminton,tennis,','telugu,kannada,urdu,','','','',''),(19,'4380262','cooking,movies,dancing,painting,','classic,','carrom,jogging,','english,hindi,tamil,','','','',''),(20,'6452605','cooking,nature,','','','','','','',''),(21,'9950824','nature,travel,pets,photo,melodies','film,western,Rock','jogging,tennis,gym,Football','english,hindi,tamil,kannada','','','',''),(22,'8624954','Cooking,Nature,Painting,Pets','Film Songs,Western Music,Classic Music','Cricket,Carrom,Swimming,Football','english,hindi,kannada,malayalam,English,Hindi,Malayalam','','','',''),(23,'4689972','Cooking','Film Songs','Carrom','Telugu,Hindi','','','',''),(24,'8840620','Internet','Film Songs','Football','Tamil','','','',''),(25,'8493817','cooking,nature,internet,','film,','cricket,carrom,','english,hindi,tamil,','','','',''),(26,'3617298','Dancing,Internet,Painting,Kung Fu','Film Songs,Melodies','Jogging,Gym,Football','Malayalam,Tamil,Telugu,Telugu,Tamil,Malayalam','','','',''),(27,'5464799','Photo,Travel,Music,Dancing,Painting','Classical Music,Western Music,Film Songs','Badminton,Jogging,Carrom','Malayalam,Hindi,Tamil','','','',''),(28,'8235405','nature,travel,photo,','western,','badminton,gym,','english,hindi,tamil,','','','',''),(29,'7246089','Cooking,Nature,Movies,Dancing,Painting,Pets,Landscape,Puzzle,Music,Internet,Travel,Photo','Film Songs,Western Music,Classic Music','Cricket,Carrom,Jogging,Badminton,Swimming,Football,Tennis,Gym','Telugu,Hindi,Kannada,Malayalam,English,Gujarathi,Tamil,Bengali,Rajasthani','','','',''),(30,'5308352','nature,internet,musics,photo,','classic,','yoga','english,telugu,','','','',''),(35,'5941411','cooking,internet','film,western','cricket,carrom','english,marathi','Test Hobbies','qweqwe','qweqw','qwewqe'),(36,'8710301','cooking','film','cricket','english, hindi, tamil, telugu, kannada, urdu, marathi, gujarathi','','','',''),(37,'7535161','cooking, nature, movies, dancing, painting, internet, travel, pets, puzzle, musics, photo','film, western, classic','cricket, carrom, jogging, badminton, swimming, football, tennis, gym','english, hindi, tamil, telugu, kannada, urdu, marathi, gujarathi','Test hobby','Test music','Test sports','Test Language'),(38,'7180214','cooking, nature, movies, dancing, internet, pets, puzzle, musics, photo','film, classic','cricket, jogging, badminton, swimming, football, gym','english, tamil','Sing','Fusion','Wrestling','Malayalam'),(39,'5136172','','','','','','','',''),(40,'28380','','','','','','','',''),(41,'16380','cooking, nature, pets','film','cricket','english','','','','');
/*!40000 ALTER TABLE `hobbies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_management`
--

DROP TABLE IF EXISTS `index_management`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `index_management` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_image` varchar(750) DEFAULT NULL,
  `content_header` text,
  `content_para` text,
  `content_button` varchar(750) DEFAULT NULL,
  `content_link` varchar(750) DEFAULT NULL,
  `footer_image` varchar(750) DEFAULT NULL,
  `footer_header` text,
  `footer_para` text,
  `right_ad` varchar(750) DEFAULT NULL,
  `left_ad` varchar(750) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_management`
--

LOCK TABLES `index_management` WRITE;
/*!40000 ALTER TABLE `index_management` DISABLE KEYS */;
INSERT INTO `index_management` VALUES (1,NULL,'fredfgtred','dergtrdfetg','rgtrgt','dergt',NULL,NULL,NULL,'','','2017-01-18 12:32:50'),(6,NULL,'Matrimonial','Soulmate matrimonial website will play a great role to connecting Telugu catholic s worldwide and it playing major role  to the Telugu Catholic community. \r\nThese matrimonial websites are gaining popularity among the Telugu Catholics as they are safe and secure (terms and conditions Applied). We can keep the profile confidential and respect the user’s privacy.\r\nThere are so many features, which makes these websites user friendly. Like these websites send match alerts to prospective grooms and brides through email and short messaging services. We can also send promotional mails informing about the latest services they are offering.\r\nMatrimony sites are very popular not just among the prospective brides and grooms but parents also like it. These online sites have all the detailed information along with  their native Parish details and also personal phone numbers. Parents can also add profile of their son or daughter on behalf of them.','Read More','http://www.telugucatholicmatrimony.com/',NULL,NULL,NULL,'','','2017-01-18 13:22:01'),(7,NULL,NULL,NULL,NULL,NULL,'assets/uploads/footer_image/1484726180_bgimage_07-01.jpg','sedfersdfgt','drgrdgt','','','2017-01-18 13:26:20'),(8,NULL,NULL,NULL,NULL,NULL,'assets/uploads/banner/1501058896_home_phone.png','Matrimonial','Matrimonial','','','2017-01-18 13:26:58'),(18,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1484737036_7.jpg','2017-01-18 16:27:16'),(19,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1484737040_9.jpg',NULL,'2017-01-18 16:27:20'),(20,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1484737369_googleadd.gif','2017-01-18 16:32:49'),(21,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1484737378_googleadd.gif',NULL,'2017-01-18 16:32:58'),(22,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1484739364_future-timeline-technology-160-600.jpg','2017-01-18 17:06:04'),(23,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1484739394_164ab82abfcfab0b2f92f86fb8c8ccf1.jpg',NULL,'2017-01-18 17:06:34'),(24,'assets/uploads/banner/1485502535_Marriage-1200x450.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-01-25 09:51:36'),(25,'assets/uploads/banner/1485502900_11836796_981035161919952_6738331505797316504_n.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-01-27 13:06:59'),(31,'assets/uploads/banner/1485926150_7.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-02-01 10:45:50'),(32,'assets/uploads/banner/1486038128_fennes_wedding.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-02-02 17:52:08'),(34,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1486039303_advcash_ru_160_600.gif','2017-02-02 18:11:43'),(35,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1486039333_14d0d02d564b3aaed6ef453fcd27d6e3.jpg',NULL,'2017-02-02 18:12:13'),(36,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1486041984_1484739364_future-timeline-technology-160-600.jpg','2017-02-02 18:56:24'),(37,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/ads/1486041990_1484739394_164ab82abfcfab0b2f92f86fb8c8ccf1.jpg',NULL,'2017-02-02 18:56:30'),(38,'assets/uploads/banner/1486220462_7.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-02-04 20:31:02'),(39,'assets/uploads/banner/1486357636_7.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-02-06 10:37:16'),(40,'assets/uploads/banner/1489045560_12003013_981035165253285_1673641877866797276_n.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-03-09 13:16:00'),(41,'assets/uploads/banner/1489045633_11836796_981035161919952_6738331505797316504_n.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-03-09 13:17:13'),(42,'assets/uploads/banner/1492681071_home_main_bg.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-04-20 15:07:51'),(43,'assets/uploads/banner/1535020619_m1.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-23 16:06:59'),(44,'assets/uploads/banner/1535020619_m11.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-23 16:06:59'),(45,'assets/uploads/banner/1535020736_m2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-23 16:08:56'),(46,'assets/uploads/banner/1535020896_m2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-23 16:11:36'),(47,NULL,'MATRIMONIAL','PelliThoranam has been helping people from the Telugu-speaking community around the world find their perfect life partner.\r\n\r\nAndhra Pradesh and Telangana have always been known for their rich cultural heritage. We can trace back the roots of classical music and dance forms such as Kuchipudi and Carnatic music to these two southern states.\r\n\r\nOver the years, we have helped Telugu-speaking members find matches from across different communities such Arya Vysya, Reddy, Kamma, Kapu, Brahmin-Niyogi, Padmasali, Brahmin Vaidiki, Balija, Naidu, and Yadav.','MORE......','ooiproducts.com/matrimonial/admin/Index_management/add_content',NULL,NULL,NULL,NULL,NULL,'2018-08-23 16:24:56'),(48,NULL,NULL,NULL,NULL,NULL,'assets/uploads/footer_image/1535021882_m2.jpg','MATRIMONIAL','MATRIMONIAL',NULL,NULL,'2018-08-23 16:28:02'),(49,NULL,NULL,NULL,NULL,NULL,'assets/uploads/footer_image/1535022137_m1.jpg','MATRIMONIAL','MATRIMONIAL',NULL,NULL,'2018-08-23 16:32:17'),(50,'assets/uploads/banner/1535110527_m2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-24 17:05:27'),(51,'assets/uploads/banner/1535110710_m11.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-24 17:08:30'),(52,'assets/uploads/banner/1535110834_m1.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-24 17:10:34'),(53,'assets/uploads/banner/1535111306_m1.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-24 17:18:26'),(54,'assets/uploads/banner/1535111378_m2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-24 17:19:38'),(55,NULL,NULL,NULL,NULL,NULL,'assets/uploads/banner/1560531277_banner2t.png','Pellithoranam','Pellithoranam',NULL,NULL,'2018-08-24 17:24:25'),(56,'assets/uploads/banner/1535174852_m4.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-25 10:57:32'),(57,'assets/uploads/banner/1535178851_Wedding_Photographers.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-25 12:04:11'),(58,'assets/uploads/banner/1535178976_matbannernew.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-25 12:06:16'),(59,'assets/uploads/banner/1535179112_martimony-banner-1500x500.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-25 12:08:32'),(60,'assets/uploads/banner/1535179144_mat.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2018-08-25 12:09:04'),(61,'assets/uploads/banner/1561792891_img12.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-06-29 12:51:32'),(62,'assets/uploads/banner/1561793768_img12.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-06-29 13:06:08'),(63,'assets/uploads/banner/1563557079_original_indian-wedding-ritual-henna.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-07-19 22:54:39'),(64,'assets/uploads/banner/1563626291_original_indian-wedding-ritual-henna-min.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-07-20 18:08:11'),(65,'assets/uploads/banner/1563636465_banner-nshn.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-07-20 20:57:45');
/*!40000 ALTER TABLE `index_management` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs_table`
--

DROP TABLE IF EXISTS `logs_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs_table` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `log_type` varchar(100) NOT NULL,
  `log_content` varchar(100) NOT NULL,
  `log_author` varchar(100) NOT NULL,
  `log_usertype` int(11) NOT NULL,
  `log_datetime` varchar(100) NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs_table`
--

LOCK TABLES `logs_table` WRITE;
/*!40000 ALTER TABLE `logs_table` DISABLE KEYS */;
INSERT INTO `logs_table` VALUES (1,'EDIT','Members Details Edited','44',0,'2017-02-15 12:08:48'),(2,'EDIT','Members Details Edited','45',0,'2017-02-15 12:15:07'),(3,'EDIT','Members Details Edited','14',3,'2017-02-15 12:41:15'),(4,'REJECT','Rejected membership of 241','45',2,'2017-02-15 12:49:23'),(5,'APPROVE','Approved membership of 241','45',2,'2017-02-15 12:49:30'),(6,'BAN','Banned membership of 241','45',2,'2017-02-15 12:49:38'),(7,'delete','deleted 241','45',2,'2017-02-15 12:49:45'),(8,'APPROVE','Approved membership of 241','45',2,'2017-02-15 12:49:56'),(9,'REJECT','Rejected gallerypic of 9950824','45',2,'2017-02-15 12:58:57'),(10,'APPROVE','Approved gallerypic of 9950824','45',2,'2017-02-15 12:59:27'),(11,'delete','Deleted gallerypic of 9950824','45',2,'2017-02-15 12:59:37'),(12,'approve','success story of 1 approved','45',2,'2017-02-15 13:19:48'),(13,'send','send news letters to 6539442','45',2,'2017-02-15 13:25:53'),(14,'send','send news letters to 3485745','45',2,'2017-02-15 13:25:58'),(15,'send','send news letters to 4380262','45',2,'2017-02-15 13:26:00'),(16,'send','send news letters to 9950824','45',2,'2017-02-15 13:26:01'),(17,'send','send news letters to 6539442','45',2,'2017-02-15 13:29:31'),(18,'send','send news letters to 9950824','45',2,'2017-02-15 13:29:35'),(19,'edit','admin edited','45',2,'2017-02-15 14:59:36'),(20,'delete','admin deleted','45',2,'2017-02-15 15:00:07'),(21,'SMS SEND','awade','45',2,'2017-02-15 15:41:34'),(22,'SMS SEND','awade','45',2,'2017-02-15 15:41:34'),(23,'APPROVE','Approved membership of 241','45',2,'2017-02-15 15:59:30'),(24,'APPROVE','Approved membership of 241','45',2,'2017-02-15 15:59:39'),(25,'REJECT','Rejected membership of 241','45',2,'2017-02-15 15:59:49'),(26,'APPROVE','Approved membership of 223','45',2,'2017-02-15 16:08:46'),(27,'APPROVE','Approved membership of 241','45',2,'2017-02-15 16:12:27'),(28,'APPROVE','Highlighted membership of 240','45',2,'2017-02-15 16:13:11'),(29,'APPROVE','Highlighted membership of 240','45',2,'2017-02-15 16:13:58'),(30,'APPROVE','Highlighted membership of 240','45',2,'2017-02-15 16:15:30'),(31,'REMOVE HIGHLIGHT','Removed Highlighted profile of 240','45',2,'2017-02-15 16:21:08'),(32,'PROFILE HIGHLIGHT','Highlighted membership of 241','45',2,'2017-02-15 16:38:52'),(33,'PROFILE HIGHLIGHT','Highlighted membership of 240','45',2,'2017-02-15 16:53:24'),(34,'REMOVE HIGHLIGHT','Removed Highlighted profile of 241','45',2,'2017-02-15 16:53:35'),(35,'PROFILE HIGHLIGHT','Highlighted membership of 127','45',2,'2017-02-15 16:53:53'),(36,'PROFILE HIGHLIGHT','Highlighted membership of 152','45',2,'2017-02-15 17:03:52'),(37,'PROFILE HIGHLIGHT','Highlighted membership of 223','45',2,'2017-02-15 17:04:42'),(38,'REMOVE HIGHLIGHT','Removed Highlighted profile of 152','45',2,'2017-02-15 17:05:36'),(39,'REMOVE HIGHLIGHT','Removed Highlighted profile of 223','45',2,'2017-02-15 17:12:36'),(40,'APPROVE','add approved (14)','45',2,'2017-02-17 14:59:16'),(41,'delete','deleted 241','45',2,'2017-02-21 10:54:36'),(42,'APPROVE','Approved profilepic of 9361701','45',2,'2017-02-21 15:43:39'),(43,'APPROVE','Approved profilepic of 3617298','45',2,'2017-02-22 11:36:34'),(44,'APPROVE','Approved gallerypic of 3617298','45',2,'2017-02-22 16:03:23'),(45,'APPROVE','Approved gallerypic of 3617298','45',2,'2017-02-22 16:03:34'),(46,'APPROVE','Approved profilepic of 5464799','45',2,'2017-02-23 11:00:52'),(47,'SMS SEND','hoooiiiiiiiiiiii ','45',2,'2017-02-23 17:50:09'),(48,'SMS SEND','hoooiiiiiiiiiiii ','45',2,'2017-02-23 17:50:54'),(49,'SMS SEND','testtest','45',2,'2017-02-23 17:51:40'),(50,'send','send news letters to 6539442','45',2,'2017-02-23 18:46:48'),(51,'send','send news letters to 9950824','45',2,'2017-02-23 18:46:53'),(52,'send','send news letters to 8493817','45',2,'2017-02-23 18:46:55'),(53,'send','send news letters to 1035131','45',2,'2017-02-23 18:46:56'),(54,'send','send news letters to 6539442','45',2,'2017-02-23 18:47:29'),(55,'send','send news letters to 9950824','45',2,'2017-02-23 18:47:32'),(56,'send','send news letters to 8493817','45',2,'2017-02-23 18:47:34'),(57,'send','send news letters to 1035131','45',2,'2017-02-23 18:47:35'),(58,'APPROVE','Approved profilepic of 7848788','45',2,'2017-02-24 10:56:32'),(59,'APPROVE','Approved profilepic of 1035131','45',2,'2017-02-24 11:01:53'),(60,'SMS SEND','sms','45',2,'2017-02-24 11:28:49'),(61,'SMS SEND','sms','45',2,'2017-02-24 11:28:49'),(62,'send','send news letters to 6539442','45',2,'2017-02-24 11:38:25'),(63,'send','send news letters to 9950824','45',2,'2017-02-24 11:38:29'),(64,'send','send news letters to 8493817','45',2,'2017-02-24 11:38:32'),(65,'send','send news letters to 1035131','45',2,'2017-02-24 11:38:32'),(66,'send','send news letters to 6539442','45',2,'2017-02-24 11:39:10'),(67,'send','send news letters to 9950824','45',2,'2017-02-24 11:39:14'),(68,'send','send news letters to 8493817','45',2,'2017-02-24 11:39:16'),(69,'send','send news letters to 1035131','45',2,'2017-02-24 11:39:17'),(70,'send','send news letters to 6539442','45',2,'2017-02-24 11:41:14'),(71,'send','send news letters to 9950824','45',2,'2017-02-24 11:41:18'),(72,'send','send news letters to 8493817','45',2,'2017-02-24 11:41:20'),(73,'send','send news letters to 1035131','45',2,'2017-02-24 11:41:21'),(74,'send','send news letters to 6539442','45',2,'2017-02-24 11:41:22'),(75,'send','send news letters to 9950824','45',2,'2017-02-24 11:41:26'),(76,'send','send news letters to 8493817','45',2,'2017-02-24 11:41:28'),(77,'send','send news letters to 1035131','45',2,'2017-02-24 11:41:29'),(78,'SMS SEND','sms','45',2,'2017-02-24 12:21:27'),(79,'send','send news letters to 6539442','45',2,'2017-02-24 12:22:29'),(80,'send','send news letters to 9950824','45',2,'2017-02-24 12:22:34'),(81,'send','send news letters to 8493817','45',2,'2017-02-24 12:22:37'),(82,'send','send news letters to 1035131','45',2,'2017-02-24 12:22:38'),(83,'APPROVE','Approved gallerypic of 8235405','45',2,'2017-02-24 15:15:35'),(84,'APPROVE','Approved gallerypic of ','45',2,'2017-02-24 15:16:18'),(85,'APPROVE','Approved gallerypic of 8235405','45',2,'2017-02-24 15:16:42'),(86,'APPROVE','Approved gallerypic of 8235405','45',2,'2017-02-24 15:17:37'),(87,'APPROVE','Approved profilepic of ','45',2,'2017-02-24 15:18:18'),(88,'PROFILE HIGHLIGHT','Highlighted membership of 107','45',2,'2017-02-24 16:25:31'),(89,'BAN','Banned membership of 107','45',2,'2017-02-24 16:25:53'),(90,'REMOVE HIGHLIGHT','Removed Highlighted profile of 107','45',2,'2017-02-24 16:26:56'),(91,'APPROVE','Approved profilepic of 8235405','45',2,'2017-02-24 16:38:12'),(92,'APPROVE','Approved profilepic of 8235405','45',2,'2017-02-25 10:30:24'),(93,'edit','ads edited (15)','45',2,'2017-02-25 12:01:26'),(94,'edit','ads edited (15)','45',2,'2017-02-25 12:01:41'),(95,'APPROVE','add approved (15)','45',2,'2017-02-25 12:03:26'),(96,'approve','success story approved','45',2,'2017-02-28 12:26:55'),(97,'SMS SEND','test message','45',2,'2017-02-28 16:08:43'),(98,'send','send news letters to 6539442','45',2,'2017-02-28 16:10:50'),(99,'send','send news letters to 9950824','45',2,'2017-02-28 16:10:57'),(100,'send','send news letters to 8493817','45',2,'2017-02-28 16:11:02'),(101,'send','send news letters to 1035131','45',2,'2017-02-28 16:11:04'),(102,'send','send news letters to 8235405','45',2,'2017-02-28 16:11:06'),(103,'send','send news letters to 6539442','45',2,'2017-02-28 16:20:04'),(104,'send','send news letters to 9950824','45',2,'2017-02-28 16:20:09'),(105,'send','send news letters to 8493817','45',2,'2017-02-28 16:20:11'),(106,'send','send news letters to 1035131','45',2,'2017-02-28 16:20:12'),(107,'send','send news letters to 8235405','45',2,'2017-02-28 16:20:12'),(108,'send','send news letters to 6539442','45',2,'2017-02-28 16:21:54'),(109,'send','send news letters to 9950824','45',2,'2017-02-28 16:22:03'),(110,'send','send news letters to 8493817','45',2,'2017-02-28 16:22:11'),(111,'send','send news letters to 1035131','45',2,'2017-02-28 16:22:13'),(112,'send','send news letters to 8235405','45',2,'2017-02-28 16:22:15'),(113,'send','send news letters to 6539442','45',2,'2017-02-28 16:23:34'),(114,'send','send news letters to 9950824','45',2,'2017-02-28 16:23:38'),(115,'send','send news letters to 8493817','45',2,'2017-02-28 16:23:40'),(116,'send','send news letters to 1035131','45',2,'2017-02-28 16:23:41'),(117,'send','send news letters to 8235405','45',2,'2017-02-28 16:23:42'),(118,'send','send news letters to 6539442','45',2,'2017-02-28 16:26:09'),(119,'send','send news letters to 9950824','45',2,'2017-02-28 16:26:13'),(120,'send','send news letters to 8493817','45',2,'2017-02-28 16:26:15'),(121,'send','send news letters to 1035131','45',2,'2017-02-28 16:26:16'),(122,'send','send news letters to 8235405','45',2,'2017-02-28 16:26:17'),(123,'send','send news letters to 6539442','45',2,'2017-02-28 16:29:34'),(124,'send','send news letters to 8493817','45',2,'2017-02-28 16:29:38'),(125,'delete','add deleted (8)','45',2,'2017-02-28 16:36:35'),(126,'delete','add deleted (9)','45',2,'2017-02-28 16:36:53'),(127,'delete','add deleted (8)','45',2,'2017-02-28 16:42:49'),(128,'REJECT','add rejected (15)','45',2,'2017-02-28 16:48:30'),(129,'delete','deleted 276','45',2,'2017-03-02 11:44:09'),(130,'insert','new banner image added','45',2,'2017-03-09 13:16:00'),(131,'insert','new banner image added','45',2,'2017-03-09 13:17:13'),(132,'delete','deleted 293','45',2,'2017-03-18 11:39:40'),(133,'delete','deleted 107','45',2,'2017-03-18 11:39:43'),(134,'delete','deleted 101','45',2,'2017-03-18 11:39:46'),(135,'delete','deleted 110','45',2,'2017-03-18 11:39:47'),(136,'delete','deleted 277','45',2,'2017-03-18 11:39:53'),(137,'delete','deleted 271','45',2,'2017-03-18 11:46:44'),(138,'delete','deleted 279','45',2,'2017-03-18 11:46:53'),(139,'delete','deleted 280','45',2,'2017-03-18 11:46:58'),(140,'delete','deleted 287','45',2,'2017-03-20 12:08:26'),(141,'APPROVE','Approved membership of 293','45',2,'2017-03-20 12:39:52'),(142,'APPROVE','Approved membership of 285','45',2,'2017-03-20 14:33:05'),(143,'APPROVE','Approved membership of 290','45',2,'2017-03-20 14:33:18'),(144,'APPROVE','Approved membership of 290','45',2,'2017-03-20 14:37:51'),(145,'delete','deleted 240','45',2,'2017-03-20 15:28:30'),(146,'APPROVE','Approved membership of 240','45',2,'2017-03-20 15:28:50'),(147,'APPROVE','Approved membership of 293','45',2,'2017-03-20 15:35:29'),(148,'APPROVE','Approved membership of 290','45',2,'2017-03-20 15:35:53'),(149,'APPROVE','Approved membership of 293','45',2,'2017-03-20 15:41:50'),(150,'APPROVE','Approved membership of 240','45',2,'2017-03-20 15:42:06'),(151,'APPROVE','Approved membership of 225','45',2,'2017-03-20 15:42:20'),(152,'APPROVE','Approved membership of 283','45',2,'2017-03-20 15:42:43'),(153,'APPROVE','Approved membership of 281','45',2,'2017-03-20 15:42:53'),(154,'APPROVE','Approved membership of 290','45',2,'2017-03-20 15:43:14'),(155,'APPROVE','Approved membership of 110','45',2,'2017-03-20 15:43:36'),(156,'APPROVE','Approved membership of 112','45',2,'2017-03-20 15:43:56'),(157,'APPROVE','Approved membership of 188','45',2,'2017-03-20 15:44:15');
/*!40000 ALTER TABLE `logs_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_alerts`
--

DROP TABLE IF EXISTS `mail_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matrimony_id` varchar(50) NOT NULL,
  `photo_reminder` int(11) NOT NULL,
  `membership_expiry` int(11) NOT NULL,
  `individual_match_alert` int(11) NOT NULL,
  `newsletter_alert` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_alerts`
--

LOCK TABLES `mail_alerts` WRITE;
/*!40000 ALTER TABLE `mail_alerts` DISABLE KEYS */;
INSERT INTO `mail_alerts` VALUES (1,'5136172',1,1,1,1),(8,'7535161',0,1,0,1),(9,'2439709',0,0,1,1),(10,'61339',0,0,0,0),(11,'15809',1,1,1,1);
/*!40000 ALTER TABLE `mail_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_details`
--

DROP TABLE IF EXISTS `membership_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `membership_details` (
  `membership_id` int(50) NOT NULL AUTO_INCREMENT,
  `matrimony_id` int(30) NOT NULL,
  `membership_package` int(30) NOT NULL,
  `membership_purchase` datetime NOT NULL,
  `membership_expiry` datetime NOT NULL,
  `addon_package` int(30) NOT NULL,
  `addon_purchase` datetime NOT NULL,
  `addon_expiry` datetime NOT NULL,
  `total_interest` int(20) NOT NULL,
  `total_sendmail` int(20) NOT NULL,
  `total_mobileview` int(20) NOT NULL,
  `total_sms` int(20) NOT NULL,
  PRIMARY KEY (`membership_id`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_details`
--

LOCK TABLES `membership_details` WRITE;
/*!40000 ALTER TABLE `membership_details` DISABLE KEYS */;
INSERT INTO `membership_details` VALUES (242,46690,1,'2019-08-13 15:27:21','2019-08-13 15:27:21',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',1,1,0,0),(243,39069,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(244,16912,5,'2019-07-29 13:23:06','2019-10-29 13:23:06',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',1,1,1,1),(245,10249,18,'2019-06-30 19:08:43','2019-12-30 19:08:43',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',100,100,100,100),(246,29516,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(247,42566,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(248,33188,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(249,89905,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(250,41905,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(251,69285,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(252,30742,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(253,16380,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(254,17260,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(255,10432,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(256,16791,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(257,13205,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(258,28380,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(259,17908,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(260,15265,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(261,14987,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(262,16302,5,'2019-07-25 12:53:06','2019-10-25 12:53:06',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',40,40,40,40),(263,29653,4,'2019-07-25 12:58:30','2019-10-25 12:58:30',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',4,4,3,3),(264,13629,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(265,11125,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(266,10560,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(267,17181,3,'2019-08-10 21:55:13','2019-11-10 21:55:13',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',6,6,6,6),(268,15809,3,'2019-08-13 15:06:24','2019-11-13 15:06:24',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',6,6,6,6),(269,15032,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(270,10967,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(271,13862,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(272,15258,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(273,16115,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(274,22525,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(275,13950,3,'2019-09-06 21:22:14','2019-12-06 21:22:14',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',6,6,6,6),(276,11946,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(277,12033,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(278,24032,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(279,16636,4,'2019-09-06 13:49:32','2020-03-06 13:49:32',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',3,3,3,3),(280,23496,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(281,28297,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(282,28471,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(283,14784,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(284,10969,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(285,14021,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(286,19027,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(287,11022,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(288,19077,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(289,14018,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(290,13548,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(291,12673,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(292,12984,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(293,18750,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(294,12517,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0),(295,18184,1,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,'0000-00-00 00:00:00','0000-00-00 00:00:00',0,0,0,0);
/*!40000 ALTER TABLE `membership_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_view`
--

DROP TABLE IF EXISTS `mobile_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_view` (
  `mobileview_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `mobileview_from` int(11) unsigned NOT NULL,
  `mobileview_to` int(11) unsigned NOT NULL,
  `mobileview_datetime` datetime NOT NULL,
  PRIMARY KEY (`mobileview_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_view`
--

LOCK TABLES `mobile_view` WRITE;
/*!40000 ALTER TABLE `mobile_view` DISABLE KEYS */;
INSERT INTO `mobile_view` VALUES (1,6539442,1569628,'2017-01-17 13:19:59'),(4,6539442,9103429,'2017-01-17 13:29:29'),(5,6539442,4670217,'2017-01-30 08:14:18'),(6,6539442,1000228,'2017-01-30 08:14:27'),(7,6539442,1923511,'2017-02-08 05:51:31'),(8,6539442,8624954,'2017-02-14 16:37:01'),(9,7535161,7180214,'2017-05-04 23:56:51'),(10,7535161,5136172,'2017-05-06 09:15:54'),(11,7535161,7535161,'2017-05-20 15:22:13'),(12,2439709,6932446,'2019-05-04 15:55:47'),(13,10249,29516,'2019-06-30 19:30:41'),(14,10249,10249,'2019-07-20 00:18:56'),(15,10249,16912,'2019-07-25 12:37:01');
/*!40000 ALTER TABLE `mobile_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mother_tongues`
--

DROP TABLE IF EXISTS `mother_tongues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mother_tongues` (
  `mother_tongue_id` int(20) NOT NULL AUTO_INCREMENT,
  `mother_tongue_name` varchar(200) NOT NULL,
  `mother_tongue_status` int(10) NOT NULL,
  PRIMARY KEY (`mother_tongue_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COMMENT='Details of Mother languages';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mother_tongues`
--

LOCK TABLES `mother_tongues` WRITE;
/*!40000 ALTER TABLE `mother_tongues` DISABLE KEYS */;
INSERT INTO `mother_tongues` VALUES (1,'Telugu',1),(2,'Hindi',1),(3,'Tamil',1),(4,'Malayalam',1),(5,'Kannada',1),(6,'English',1),(7,'Gujarathi',1),(8,'Marathi',1),(9,'Oriya',1),(10,'Bengali',1),(11,'Assamese',1),(12,'Kashmiri',1),(13,'Rajasthani',1),(14,'Punjabi',1),(15,'Urdu',1);
/*!40000 ALTER TABLE `mother_tongues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mytable`
--

DROP TABLE IF EXISTS `mytable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mytable` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(27) DEFAULT NULL,
  `state_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `city_status` bit(1) DEFAULT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mytable`
--

LOCK TABLES `mytable` WRITE;
/*!40000 ALTER TABLE `mytable` DISABLE KEYS */;
/*!40000 ALTER TABLE `mytable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `occupations`
--

DROP TABLE IF EXISTS `occupations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `occupations` (
  `occupation_id` int(20) NOT NULL AUTO_INCREMENT,
  `occupation_parent` int(10) DEFAULT NULL,
  `occupation` varchar(200) NOT NULL,
  `occupation_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`occupation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=latin1 COMMENT='Base occupations';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `occupations`
--

LOCK TABLES `occupations` WRITE;
/*!40000 ALTER TABLE `occupations` DISABLE KEYS */;
INSERT INTO `occupations` VALUES (1,0,'Manager',1),(2,0,'Doctor',0),(3,0,'Software Developer',1),(4,0,'Teacher',1),(5,0,'Nurse',0),(6,0,'Police',0),(7,NULL,'tester1',0),(8,NULL,'Accountant',0),(9,NULL,'Business Owner / Entrepreneur ',1),(10,NULL,'Librarian',1),(11,NULL,'Arts & Craftsman',1),(12,NULL,'Technician',1),(13,NULL,'Sportsman',1),(14,NULL,'Social Worker',1),(15,NULL,'Customer Care Professional',1),(16,NULL,'Consultant',1),(17,NULL,'Business Analyst',1),(18,NULL,'CXO / President , Director ,Chairman',1),(19,NULL,'Scientist / Researcher',1),(20,NULL,'Mariner / Merchant Navy',1),(21,NULL,'Designer',1),(22,NULL,'Advertising / PR Professional',1),(23,NULL,'Event Management Professional',1),(24,NULL,'Entertainment Professional',1),(25,NULL,'Media Professional',1),(26,NULL,'Journalist',1),(27,NULL,'Sales Professional',1),(28,NULL,'Marketing Professional',1),(29,NULL,'Nurses',1),(30,NULL,'Health Care Professional',1),(31,NULL,'Doctor',1),(32,NULL,'Law Enforcement Officer',1),(33,NULL,'Lawyer & Legal Professional',1),(34,NULL,'Designer',1),(35,NULL,'Engineer – Non IT',1),(36,NULL,'Hardware Professional',1),(37,NULL,'Hardware Professional',1),(38,NULL,'Hotel / Hospitality Professional',1),(39,NULL,'Education Professional',1),(40,NULL,'Teaching / Academician',1),(41,NULL,'Professor / Lecturer',1),(42,NULL,'Air force',1),(43,NULL,'Navy',1),(44,NULL,'Army',1),(45,NULL,'Civil Services (IAS/IPS/IRS/IES/IFS)',1),(46,NULL,'Beautician',1),(47,NULL,'Fashion Designer',1),(48,NULL,'Financial Analyst / Planning',1),(49,NULL,'Financial Accountant',1),(50,NULL,'Auditor',1),(51,NULL,'Banking Service Professional',1),(52,NULL,'Accounts / Finance Professional',1),(53,NULL,'Company Secretary',1),(54,NULL,'Charted Accountant',1),(55,NULL,'Interior Designer',1),(56,NULL,'Architect',1),(57,NULL,'Airline Professional',1),(58,NULL,'Air Hostess',1),(59,NULL,'Pilot',1),(60,NULL,'Agriculture & Farming Professional',1),(61,NULL,'Human Resource Professional',1),(62,NULL,'Clerk',1),(63,NULL,'Executive',1),(64,NULL,'Administrative Professional',1),(65,NULL,'Officer',1),(66,NULL,'Supervisor',1),(84,NULL,'Test Occupation',0),(89,NULL,'New occupation',1),(90,NULL,'qqq',0),(91,NULL,'FARMER',1),(92,NULL,'BUSSINESS',1),(93,NULL,'CIVIL ENGINEER',1),(94,NULL,'Music Teacher',1);
/*!40000 ALTER TABLE `occupations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `otp_details`
--

DROP TABLE IF EXISTS `otp_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `otp_details` (
  `otp_id` int(50) NOT NULL AUTO_INCREMENT,
  `otp` int(30) NOT NULL,
  `otp_user` int(30) NOT NULL,
  `otp_mobile` varchar(30) NOT NULL,
  `otp_datetime` datetime NOT NULL,
  `otp_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`otp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `otp_details`
--

LOCK TABLES `otp_details` WRITE;
/*!40000 ALTER TABLE `otp_details` DISABLE KEYS */;
INSERT INTO `otp_details` VALUES (1,531706,5136172,'1234567899','2017-04-27 15:42:08',1),(2,750481,7180214,'9488521252','2017-04-28 15:08:58',1),(3,723230,4355283,'1234561234','2017-05-12 11:08:49',0),(4,378906,6423471,'1231231231','2017-05-12 14:35:11',0),(5,426807,6973643,'9400882215','2017-07-12 15:12:15',1),(9,865212,5019447,'1234567897','2017-07-26 15:01:39',0),(10,298934,1778319,'1234567894','2017-07-26 15:35:40',0),(11,691111,5151715,'1436257895','2017-07-26 15:39:11',1),(12,490231,5439130,'9493778391','2018-07-31 15:38:07',0),(13,746648,5241413,'7386793931','2018-08-25 10:24:59',0),(14,640845,8994631,'4569875745','2018-08-30 13:37:40',0),(15,179539,6932446,'4857897897','2018-08-30 15:15:04',1),(16,475275,1799748,'7894561230','2018-09-17 13:23:35',0),(17,199762,9951422,'8977741225','2018-09-17 14:21:27',1),(18,722216,4005106,'7013886155','2019-03-21 14:24:52',0),(19,727917,4564885,'7013552465','2019-04-17 12:14:38',0),(20,549145,2439709,'7010954816','2019-05-04 15:28:21',0),(21,350973,4967614,'9154190352','2019-05-09 13:17:17',1),(22,456942,1054396,'1737616304','2019-05-11 00:11:33',1),(23,206776,4192039,'9154190343','2019-05-11 14:47:33',0),(24,765624,62335,'331323','2019-06-07 07:05:53',1),(25,541994,61339,'9989905002','2019-06-10 13:27:53',1),(26,701674,64344,'8985360257','2019-06-14 15:38:34',0),(27,922569,54589,'8074300847','2019-06-14 19:21:11',0),(28,141517,68047,'7093225992','2019-06-15 12:10:42',0),(29,751886,28637,'321123566','2019-06-18 19:57:34',1),(30,427296,46690,'7013886155','2019-06-19 15:05:49',1),(31,387216,39069,'8074300847','2019-06-19 15:19:17',0),(32,733023,16912,'9493778391','2019-06-19 15:24:49',1),(33,674266,10249,'9966337383','2019-06-19 17:24:01',1),(34,166086,29516,'8247697537','2019-06-19 18:22:22',1),(35,872581,42566,'7893419537','2019-06-20 12:36:05',0),(36,978575,33188,'7893419636','2019-06-20 17:52:01',0),(37,987969,89905,'7842597056','2019-06-22 12:35:40',0),(38,644228,41905,'7842597056','2019-06-22 12:35:45',1),(39,573908,69285,'9866859925','2019-06-26 11:18:06',1),(40,353992,30742,'8008497144','2019-06-28 11:43:00',1),(41,467619,16380,'6303594318','2019-06-30 20:58:47',1),(42,917250,17260,'7842597053','2019-07-01 12:53:01',0),(43,776096,10432,'7842597053','2019-07-01 12:53:48',0),(44,315881,16791,'9533700153','2019-07-12 16:39:11',0),(45,375844,15265,'4255455','2019-07-20 11:12:49',1),(46,446158,14987,'35355','2019-07-20 17:13:46',1),(47,280257,16302,'342','2019-07-20 17:18:46',1),(48,569499,29653,'7010954816','2019-07-20 17:31:10',1),(49,770086,13629,'9949746917','2019-07-30 13:36:03',0),(50,301673,11125,'8977735225','2019-08-07 16:32:51',1),(51,798021,10560,'9491809591','2019-08-07 16:41:32',1),(52,348537,17181,'7702939365','2019-08-10 12:35:57',1),(53,109597,15809,'9573577277','2019-08-13 13:54:06',0),(54,794820,15032,'9394872558','2019-08-15 11:57:58',1),(55,360107,10967,'7895656555','2019-08-15 12:52:27',0),(56,200591,13862,'9959158936','2019-08-15 21:42:51',1),(57,920900,15258,'6301980563','2019-08-21 12:35:45',1),(58,852658,16115,'1234567890','2019-08-26 15:35:34',0),(59,813937,22525,'1234567899','2019-08-26 16:03:47',0),(60,397812,13950,'9885324983','2019-08-28 10:15:37',1),(61,713074,11946,'9603460016','2019-08-29 10:33:34',1),(62,111560,12033,'1478965230','2019-08-29 11:47:46',1),(63,196641,24032,'1256347890','2019-08-29 11:55:33',1),(64,636877,16636,'9603460016','2019-09-05 14:23:50',1),(65,340525,23496,'7893419636','2019-09-06 17:01:47',0),(66,276313,28297,'7893419636','2019-09-06 17:01:50',1),(67,358884,28471,'8008813195','2019-09-08 13:10:52',0),(68,185289,14784,'8341006612','2019-09-14 14:23:15',1),(69,808707,10969,'9032228155','2019-09-22 12:46:52',1),(70,416043,14021,'9493337733','2019-11-07 17:41:20',0),(71,213422,19027,'7894566232','2019-11-07 18:09:29',0),(72,911574,11022,'7894566232','2019-11-07 18:10:01',0),(73,599235,19077,'9879879876','2019-11-07 18:14:52',0),(74,630715,14018,'1234567890','2019-11-07 18:28:25',0),(75,452478,13548,'1234567890','2019-11-07 18:29:13',0),(76,654883,12673,'1234567890','2019-11-07 18:30:01',0),(77,621008,12984,'1256347890','2019-11-07 18:42:01',0),(78,650189,18750,'1256347890','2019-11-07 18:42:31',0),(79,219672,12517,'1256347890','2019-11-07 19:03:39',0);
/*!40000 ALTER TABLE `otp_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `package_name` varchar(100) NOT NULL,
  `price` varchar(50) NOT NULL,
  `month` varchar(100) NOT NULL,
  `alt_mobile` enum('1','0') NOT NULL DEFAULT '0',
  `intrest` varchar(100) NOT NULL,
  `intrest_permonth` varchar(100) NOT NULL,
  `personalized_msg` varchar(100) NOT NULL,
  `personalized_msg_permonth` varchar(100) NOT NULL,
  `verified_mob` varchar(100) NOT NULL,
  `verified_mob_permonth` varchar(100) NOT NULL,
  `send_sms` varchar(100) NOT NULL,
  `send_sms_permonth` varchar(100) NOT NULL,
  `chat_instantly` varchar(100) NOT NULL,
  `chat_instantly_permonth` varchar(100) NOT NULL,
  `profile_highligher` varchar(100) NOT NULL,
  `personal_relationship_manager` varchar(100) NOT NULL,
  `priority_search` varchar(100) NOT NULL,
  `profile_tagged` varchar(100) NOT NULL,
  `prominent_display` varchar(100) NOT NULL,
  `sms_alert` varchar(100) NOT NULL,
  `enhanced_privacy` varchar(100) NOT NULL,
  `view_social_profiles` varchar(100) NOT NULL,
  `package_status` int(11) NOT NULL DEFAULT '1',
  `package_manage_status` int(11) NOT NULL DEFAULT '1',
  `package_type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,'Free','0','0','0','1','','1','','1','','1','','1','','1','1','1','1','1','1','1','0',1,0,1),(3,'Classic','1500','3','1','1','6','1','6','1','6','1','6','1','6','1','1','1','1','1','1','1','1',1,0,1),(4,'GOLD','3000','6','0','1','3','1','3','1','3','1','3','1','3','1','1','1','1','1','1','1','1',1,0,1),(5,'Classic Premium','400','3','0','1','1','1','1','1','1','1','1','1','1','0','0','1','1','1','1','1','1',0,0,1),(6,'Till you Marry','5000','0','0','1','','1','','1','','1','','1','','1','1','1','1','1','1','1','1',0,0,1),(9,'Till u Marry','0','12','0','1','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0',0,1,1),(10,'studied','5','2','0','','','','','','','','','','','','','','','','','','',0,1,1),(11,'low class ','300','5','0','','','','','','','','','','','','','','','','','','',0,0,1),(12,'Middle class','500','4','0','','','','','','','','','','','','','','','','','','',0,0,1),(13,'Rich one','700','5','0','','','','','','','','','','','','','','','','','','',0,0,1),(14,'LOWEST','350','3','0','','','','','','','','','','','','','','','','','','',0,0,2),(15,'RICHEST','550','5','0','','','','','','','','','','','','','','','','','','',0,0,2),(16,'Rich','2000','2','0','','','','','','','','','','','','','','','','','','',0,0,1),(17,'Richer','20000','5','0','','','','','','','','','','','','','','','','','','',0,0,2),(18,'gold plus156675','6000','6','0','1','100','1','100','1','100','1','100','1','100','1','1','1','1','1','1','1','1',0,0,2),(19,'Testfive','5','6','0','1','60','1','60','1','6','1','6','1','6','1','1','1','1','1','1','1','1',0,0,1),(20,'PELLITHORANAM  WEB LAUNCHING OFFER','0','1','0','','5','','5','','5','','5','','5','0','0','0','0','0','0','0','0',0,1,1),(21,'GOLD  PLUS','5000','12','0','','','','','','','','','','','','','','','','','','',1,1,1);
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'terms-conditions','Terms & conditions','<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">The Pellithoranam\r\nis a sole proprietary firm having its registered office in Pragathi Nagar,\r\nHyderabad. and have website in the by name and style of www.pellithoranam.com (herein\r\nafter wards the Pellithoranam called as PT) </span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">The PT humbly\r\nrequests please read the following terms and conditions very carefully as you\r\nuse website and are subject to acceptance and compliance with terms and\r\nconditions including and amended/modified/changed from time to time without\r\nprior notice. </span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">Using the\r\nwebsite shows you are agreeing to all the terms and conditions herein. SO READ\r\nTHE TERMS AND CONDITIONS CAREFULLY BEFORE PROCEEDING. IF YOU PROCEED, ACCEPTED\r\nTHE TERMS AND CONDITIONS BY EXPRESS OR IMPLIED MANNER BY USING THE WEBSITE. IF\r\nYOU DO NOT WANT TO BE BOUND BY THE TERMS AND CONDITIONS YOU MUST NOT USE THE\r\nWEBSITE.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">2.<span style=\"mso-spacerun:yes\">&nbsp; </span>It acts as a platform to enable any\r\nperson/individual to themselves register as member by providing requisite\r\ninformation, and to voluntarily search for profile(s) from the website. Already\r\nregistered users for seeking prospective lawful marriages alliances for\r\nthemselves. PT help desk may also be able to assist you to create your profile,\r\nand also to update. But the member/interested person must have a\r\nvalid/operational mobile/ phone number and an email id, photo, address proof,\r\ndate of birth, and phone verification is compulsory.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">3.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp; </span>The profiles in the database/website of PT\r\nare classified broadly on the basis of language and region for the ease and\r\nconvenience of its member/customer. PT members are provided with free/paid\r\naccess for searching profiles from the website of PT as per the partner\r\npreference set by you and you shortlist the prospective alliances yourself. The\r\nsearch for prospective alliance is depends caste wise, age, and district wise\r\nand inter-caste also. Membership is guided by the terms and conditions\r\nmentioned herein below</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">By using or\r\naccessing the PT services, you agree to be bound by all the terms and\r\nconditions (agreement). PT do not authenticate/guarantee any information of any\r\nprofile is genuine and hence you as a user/member need to verify the\r\ncredentials and information provided by other users/members.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">4. Eligibility:</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp; </span>a.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>PT membership and rights of admission is reserved solely for;- </span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>The<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;\r\n</span>below mentioned are citizens of India;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>i.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>Who is born in the territory of India.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ii.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>Either of whose parents was born in the territory of me.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>iii.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>Who has been ordinarily resident in the ‘territory’ of India for not\r\nless than five years immediately preceding such commitment.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp; </span>b.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>In respect of citizen ship issue, the law of land for the time being in\r\nforce is applicable.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>The person who wants to join as member\r\nmust require/ full fill the following conditions.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>i.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>A major, 18 years is to be completed for female and 21 year is to be\r\ncompleted for male person as per the applicable Indian Law.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>ii.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>Legally competent to marry as per the law applicable to member and in\r\ncase of divorcee he/she has to submit divorcee papers which were obtained from\r\nthe competent court of law or any authority which is approved and the\r\nrecognized by the State Govt.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span>iii.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>Not disqualified by any applicable law for the time being in force from\r\nentering into a valid marriage.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">5. Registration:</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp; </span>a.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>The company (PT) we expect that you would complete the online\r\nregistration process with fairness and honesty while uploading your personal\r\ninformation’s in PT/Website. We should ensure that efficient and effective\r\nmatch making through our website depend upon yourself furnishing true,\r\naccurate, current, complete information and photos etc. We expect you to read\r\nthe relevant columns before keying/uploading/typing the details or selecting\r\nthe option available or uploading the photo you are requested not to keeping\r\nkey in details of the profile in filed other than the applicable filed\r\n(including mentioning id’s of other platforms/websites /applications) or\r\nrepeating your details in another fields after filling them once in the\r\nrelevant fields or others photographs. You further undertake that you alone\r\nshall be responsible or liable for any information provided to PT/Website. In\r\norder to serve you better if PT requires additional details you agree to\r\nprovide it. PT/Website shall reproduce the registered member details on “as on\r\nthat date” basis to other registered members and PT members shall be solely\r\nliable for the information given by such PT member. You may also give a missed\r\ncall to help-desk phone number service phone numbers for us to call you back\r\nand assist you in getting your profile registered on our website. </span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp; </span>b.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>If at any point of time PT/website comes to know or is so informed by\r\nthird party or has reasons to believe that any information provided by you for\r\nregistration (including photos) or otherwise is found to be untrue, inaccurate,\r\nor incomplete then PT/website shall have full right to suspend or terminate\r\nwithout any notice your PT membership and forfeit any amount paid by you\r\ntowards PT membership fee and reserve the right to refuse to provide PT service\r\nto you thereafter.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\"><span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp; </span>c.<span style=\"mso-spacerun:yes\">&nbsp;&nbsp;&nbsp;\r\n</span>PT membership is restricted strictly to the individual member only.\r\nOrganizations, companies, businesses and/or individuals carrying on similar or\r\ncompetitive business cannot become members of PT and nor use the PT service or PT\r\nmembers data for any commercial purpose and PT reserves its right<span style=\"mso-spacerun:yes\">&nbsp; </span>to initiate appropriate legal action for\r\nbreach of these obligation/conditions.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><a name=\"_GoBack\"></a><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">Disclaimer:</span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpFirst\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l5 level1 lfo1\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">a.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Your access to and use of the PT\r\nservices or any content is at your own risk. YouUNDERSTAND AND AGREE THAT THE PT\r\nSERVICES ARE PROVIDED TO YOU ON AN “AS IS” AND “AS AVAILABLE “ BASIS. WITHOUT\r\nLIMITING THE FOREGOING TO THE FULL EXTENT PERMITTED BY LAW, PT/WEBSITE\r\nDISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, OF MERCHANT-ABILITY, and FITNESS\r\nFOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l5 level1 lfo1\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">b.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">PT/website does not give any\r\nimplied or explicit guarantee or warranty of marriage or alliance by you\r\nchoosing to register on our website and using PT services (both paid and free).</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l5 level1 lfo1\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">c.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Notwithstanding anything\r\ncontrary contained anywhere, under no circumstances, PT/website shall be held\r\nresponsible or liable whatsoever or howsoever, arising out of, relating to or\r\nconnected with;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-36.0pt;\r\nmso-text-indent-alt:-18.0pt;mso-list:l0 level1 lfo6\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\"><span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span>I.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Any untrue or incorrect\r\ninformation submitted by you or on your behalf;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-36.0pt;\r\nmso-text-indent-alt:-18.0pt;mso-list:l0 level1 lfo6\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\"><span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span>II.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Any decision taken by you or on\r\nyour behalf or any consequences thereof, based on any information provided by\r\nany other user (including suspension/deletion of the profile from PT);</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-36.0pt;\r\nmso-text-indent-alt:-18.0pt;mso-list:l0 level1 lfo6\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\"><span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;\r\n</span>III.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Any unauthorized or illegal act\r\ndone by any third party relating to or connected with any information submitted\r\nby you or on your behalf;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-36.0pt;\r\nmso-text-indent-alt:-18.0pt;mso-list:l0 level1 lfo6\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\"><span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;\r\n</span>IV.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Any cyber-crime attempted or\r\ncommitted by anyone and</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-36.0pt;\r\nmso-text-indent-alt:-18.0pt;mso-list:l0 level1 lfo6\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\"><span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span>V.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Any incident of force-majeure\r\nor act of god;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-36.0pt;\r\nmso-text-indent-alt:-18.0pt;mso-list:l0 level1 lfo6\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\"><span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;\r\n</span>VI.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Any issue already stated in\r\nthese terms and conditions including limitation of liability clause of these\r\nterms and conditions;</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-36.0pt;\r\nmso-text-indent-alt:-18.0pt;mso-list:l0 level1 lfo6\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\"><span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp; </span>VII.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">PT members are requested to\r\nexercise due care and caution while shortlisting the prospect and satisfy\r\nthemselves before making a choice of your match through adequate efforts,\r\ninitiatives and due diligence. PT/website will not be liable for any damages of\r\nany kind arising from the use of this website, including, but not limited to\r\ndirect, indirect, incidental, punitive, and consequential damages.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpLast\" style=\"text-align:justify;text-indent:-36.0pt;\r\nmso-text-indent-alt:-18.0pt;mso-list:l0 level1 lfo6\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">VIII.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">PT/website shall not be liable\r\nfor the outcome of during any interaction in a meeting, call, sms, chat, email\r\nor social media posts at any point of time. You expressly agree that use of\r\nthis website is at your sole risk.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">Indemnity:</span></b></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">By using our PT\r\nservices you agree to defend, indemnify, and hold harmless PT/website its\r\nsubsidiaries, affiliates, directors, officers, agents and other partners and\r\nemployees, fully indemnified and harmless from any loss, damage, liability,\r\nclaim, or demand, including reasonable attorney’s fees, made by any person\r\nthrough improper use of the service provided by PT/website. This defense and\r\nindemnification obligation will survive in perpetuity.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">Breach:</span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpFirst\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l1 level1 lfo2\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">a.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">You agree that if we\r\nreceive<span style=\"mso-spacerun:yes\">&nbsp; </span>feedback/complaints against your\r\nprofile in relation to the facts that you are seeking physical/financial favors\r\nfrom our other registered members or have provided incorrect information on our\r\nwebsite or committed any unlawful/illegal activities through the use of our\r\nwebsite<span style=\"mso-spacerun:yes\">&nbsp; </span>or created a profile on our\r\nwebsite by impersonation / fake/bogus/false/misrepresentation/without consent\r\nof the person whose profile is being registered or use only part information\r\nincluding using photo of third parties without the permission of such third\r\nparties or act with other members/employees in indecent/improper manner, then\r\nwe PT/website in good faith reserve our right to suspend/delete your profile at\r\nour sole discretion without any notice to you, we also reserve to stop all PT\r\nservices to you and take any action as mentioned in clause 2(b) of the terms\r\nand conditions.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpLast\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l1 level1 lfo2\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">b.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">PT/website reserves the right\r\nto forthwith terminate your PT membership, block/delete your profile and\r\nforfeit entire amount paid as membership fee; if at any time PT/website, in its\r\nsole discretion, is of the opinion or has any reason to believe that, you have\r\nviolated these terms and conditions of use. We also reserve our right to file\r\nappropriate police complaint against you, if the breach of these terms and\r\nconditions is/are criminal in nature.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">Termination:</span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpFirst\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l2 level1 lfo3\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">a.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">All PT paid package users can\r\nrenew the paid package to carry forward the un-used contacts (mobile No.\r\nviewing and SMS).</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l2 level1 lfo3\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">b.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">The payments made by PT member\r\nto PT/website by way of registration/membership/renewal fee/ auto renewal\r\nis/are treated as non-refundable. Payment once made for PT service cannot be\r\nassigned to any person/party or adjusted towards any other product or packages\r\nprovided by PT.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpLast\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l2 level1 lfo3\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">c.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">PT members cannot put the paid PT\r\nservice on hold even temporarily, for any reason whatsoever. For an every\r\nregistered member from the date of issuing GST invoice in token receipt of payment\r\nby the member is to be taken into consideration and from that day to 120 days\r\nis the tenure period for every member.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">&nbsp;</span></b></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">&nbsp;</span></b></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">&nbsp;</span></b></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">&nbsp;</span></b></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">Jurisdiction and applicable law:</span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpFirst\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l3 level1 lfo5\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">a.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">The registration of PT\r\nmembership and all PT services/website are deemed to have been entered into\r\nwithin the territorial jurisdiction of Hyderabad, Telangana, India.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l3 level1 lfo5\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">b.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">The PT members unconditionally\r\nagree that all such disputes and/or differences if any shall be governed by the\r\nlaws of India and submitting to the exclusive jurisdiction of appropriate court\r\nof law in Hyderabad, Telangana, India.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpLast\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l3 level1 lfo5\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">c.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">You hereby, unconditionally and\r\nirrevocably confirm that you have read terms and conditions and agree to abide\r\nby them and the information provided by you is true and correct.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><b style=\"mso-bidi-font-weight:\r\nnormal\"><span style=\"font-size:12.0pt;mso-bidi-font-size:11.0pt;\r\nline-height:115%\" lang=\"EN-US\">Privacy Policy:</span></b></p>\r\n\r\n<p class=\"MsoListParagraphCxSpFirst\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l4 level1 lfo4\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">a.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Pellithoranam is an online\r\nmarriages portal endeavoring constantly to provide you with marriages services.\r\nSince we are strongly committed to your right to privacy, we have drawn out a\r\nprivacy statement with regard to the information we collect from you. You\r\nacknowledge that you are disclosing information voluntarily. By using the\r\nwebsite and/or by providing your information, you consent to the collection and\r\nuse of the information you disclose on the website in accordance with the\r\nprivacy policy. If you do not agree for use of your information, please do not\r\nuse or access this website.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l4 level1 lfo4\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">b.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">The information<span style=\"mso-spacerun:yes\">&nbsp; </span>we gather from members and visitors who apply\r\nfor<span style=\"mso-spacerun:yes\">&nbsp; </span>the various services our site offers\r\nincludes, but may not be limited to, email address, name, date of birth,\r\neducational qualifications a user-specified pass word, mailing address, zip/pin\r\ncode and telephone/mobile number.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l4 level1 lfo4\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">c.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Any information you give us is\r\nheld with the utmost care and security. We are also bound to cooperate fully\r\nshould a situation arise where we are required by law or legal process to\r\nprovide information about a customer/visitor/member.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l4 level1 lfo4\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">d.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">The members are requested to\r\nlogin to the relevant pages for un-subscription.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpMiddle\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l4 level1 lfo4\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">e.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">As a paid member of this site,\r\nyou have the privilege to contact number of profiles. However, there is a\r\nspecified un-limited message per day due to fair online usage policy.</span></p>\r\n\r\n<p class=\"MsoListParagraphCxSpLast\" style=\"text-align:justify;text-indent:-18.0pt;\r\nmso-list:l4 level1 lfo4\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">f.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">We may change this privacy\r\npolicy without notice from time to time based on your comments or as a result\r\nof a change of policy in our company.</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">This document is\r\nan electronic record in terms of the information technology Act, 2000 and rules\r\nthere under pertaining to electronic records as applicable and amended. This\r\nelectronic record is generated by a computer system and does not require any\r\nphysical or digital signatures</span></p>\r\n\r\n<p class=\"MsoNormal\" style=\"text-align:justify\"><span lang=\"EN-US\">NB:<span style=\"mso-spacerun:yes\">&nbsp;&nbsp; </span>ANY TYPE OR GRPTMATICAL MISTAKES IF NOTICED\r\nIN TERMS AND CONDITIONS KINDLY BROUGHT TO THE NOTICE OF HELP DESK OR GRIEVANCE\r\nOFFICER.</span></p>'),(2,'faq-s','FAQ\'s','<p>FAQ\'s page<br></p>'),(3,'about-us','About Us',''),(4,'privacy-policy','Privacy policy','<p class=\"MsoListParagraph\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">1.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Pellithoranam.com is an online\r\nmarriages portal endeavoring constantly to provide you with marriages services.\r\nSince we are strongly committed to your right to privacy, we have drawn out a\r\nprivacy statement with regard to the information we collect from you.\r\nYouacknowledge that you are disclosing information voluntarily. By using\r\nthewebsite and/or by providing your information, you consent to the collection\r\nanduse of the information you disclose on the website in accordance with\r\ntheprivacy policy. If you do not agree for use of your information, please do\r\nnotuse or access this website.</span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoListParagraph\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">2.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">The information we gather from\r\nmembers and visitors who applythe various services our site offersincludes, but\r\nmay not be limited to, email address, name, date of birth,educational\r\nqualifications a user-specified pass word, mailing address, zip/pincode and\r\ntelephone/mobile number.</span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoListParagraph\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">3.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">Any information you give us is\r\nheld with theutmost care and security. We are also bound to cooperate fully\r\nshould asituation arise where we are required by law or legal process to\r\nprovideinformation about a customer/visitor/member.</span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoListParagraph\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">4.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">The members are requested to\r\nlogin to therelevant pages for un-subscription. As a paid member of this site,\r\nyou havethe privilege to contact number of profiles. However, there is a\r\nspecified un-limitedmessage per day due to fair online usage policy.</span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoListParagraph\" style=\"text-indent:-18.0pt;mso-list:l0 level1 lfo1\"><span style=\"mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin\" lang=\"EN-US\"><span style=\"mso-list:Ignore\">5.<span style=\"font:7.0pt &quot;Times New Roman&quot;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n</span></span></span><span lang=\"EN-US\">We may change this privacy\r\npolicy withoutnotice from time to time based on your comments or as a result of\r\na change ofpolicy in our company.</span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"EN-US\">This document is an electronic record in\r\ntermsof the information technology Act, 2000 and rules there under pertaining\r\ntoelectronic records as applicable and amended. This electronic record\r\nisgenerated by a computer system and does not require any physical or digital\r\nsignatures.</span></p>\r\n\r\n<p class=\"MsoNormal\"><span lang=\"EN-US\">&nbsp;</span></p>\r\n\r\n<p class=\"MsoNormal\"><a name=\"_GoBack\"></a><span lang=\"EN-US\">ANY TYPE OR\r\nGRAMMATICAL MISTAKES IF NOTICED INTERMS AND CONDITIONS KINDLY BROUGHT TO THE\r\nNOTICE OF HELP DESK OR GRIEVANCE OFFICER.</span></p>'),(5,'safety-tips','Safety Tips','<p>Safety Tips: </p>');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parish`
--

DROP TABLE IF EXISTS `parish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parish` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `parish_name` varchar(100) NOT NULL,
  `parish_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parish`
--

LOCK TABLES `parish` WRITE;
/*!40000 ALTER TABLE `parish` DISABLE KEYS */;
INSERT INTO `parish` VALUES (12,1,2,11,'Angalakuduru - Guntur Diocese',0),(13,1,2,11,'Attalur - Guntur Diocese',0),(14,1,2,11,'Kanaparyu - Guntur Diocese',0),(15,1,2,11,'Kuchipudi - Guntur Diocese',0),(16,1,2,11,'Mutluru - Guntur Diocese',0),(17,1,2,11,'Patibandla - Guntur Diocese',0),(18,1,2,11,'Phirangipuram - Guntur Diocese',0),(19,1,2,11,'Ravipadu - Guntur Diocese',0),(20,1,2,11,'Rentachintala - Guntur Diocese',1),(21,1,2,11,'Reddipalem - Guntur Diocese',1),(22,1,2,11,'Repalle - Guntur Diocese',1),(23,1,2,11,'Siripuram - Guntur Diocese',1),(24,1,2,11,'Tenali - Guntur Diocese',1),(25,1,2,11,'Thallacheruvu - Guntur Diocese',1),(26,1,2,11,'Thubadu - Guntur Diocese',1),(27,1,2,11,'Thurakapalem - Guntur Diocese',1),(28,1,2,14,'Our Lady of Lourdes Cathedral - Kurnool -2',1),(29,1,2,14,'Adoni - Kurnool Diocese',1),(30,1,2,8,'Anantapur North -  Kurnool Diocese',1),(31,1,2,8,'Anantapur South - Kurnool Diocese',1),(32,1,2,14,'Atmakur - Kurnool Diocese',1),(33,1,2,14,'Banaganapalle - Kurnool Diocese',1),(34,1,2,14,'Bandi Atmakur - Kurnool Diocese',1),(35,1,2,14,'Bethamcherla - Kurnool Diocese',1),(36,1,2,14,'Chagalamarri - Kurnool Diocese',1),(37,1,2,14,'Chapirevula - Kurnool Diocese',1),(38,1,2,8,'Chennamanayanikota - Kurnool Diocese',1),(39,1,2,8,'Dharmavaram - Kurnool Diocese',1),(40,1,2,14,'Dhone - Kurnool Diocese',1),(41,1,2,14,'Gadivemula - Kurnool Diocese',1),(42,1,2,8,'Gooty - Kurnool Diocese',1),(43,1,2,14,'Gospadu - Kurnool Diocese',1),(44,1,2,8,'Guntakal - Kurnool Diocese',1),(45,1,2,8,'Hindupur -  Kurnool Diocese',1),(46,1,2,14,'Joharapuram - Kurnool Diocese',1),(47,1,2,14,'Jupadu Banglow - Kurnool Diocese',1),(48,1,2,8,'Kadiri - Kurnool Diocese',1),(49,1,2,8,'KALYANADURGAM - Kurnool Diocese',1),(50,1,2,14,'Pedda Kadubur - Kurnool Diocese',1),(51,1,2,14,'Koilakuntla - Kurnool Diocese',1),(52,1,2,14,'Kosigi - Kurnool Diocese',0),(53,1,2,14,'Maddikera - Kurnool Diocese',1),(54,1,2,14,'Nandikotkur - Kurnool Diocese',1),(55,1,2,14,'Nandyal - Kurnool Diocese',1),(56,1,2,14,'ONTEDDUPALLE - Kurnool Diocese',1),(57,1,2,14,'Orvakal - Kurnool Diocese',1),(58,1,2,14,'OWK - Kurnool Diocese',1),(59,1,2,14,'Pathikonda - Kurnool Diocese',1),(60,1,2,14,'PEDDA KOTTALA - Kurnool Diocese',0),(61,1,2,14,'Polur - Kurnool Diocese',0),(62,1,2,14,'PREMAGIRI - Kurnool Diocese',1),(63,1,2,14,'RAMADURGAM - Kurnool Diocese',1),(64,1,2,10,'ALLIPALLI  - East Godavari Diocese',0),(65,1,2,10,' ELURU -  East Godavari Diocese',0),(66,1,2,10,'DONDAPUDI - East Godavari Diocese',0),(72,1,19,1,'vazhakkala',1),(73,1,12,0,'VARMA',1);
/*!40000 ALTER TABLE `parish` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `purchase_amount` varchar(100) DEFAULT NULL,
  `purchase_date` datetime NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `status` varchar(255) NOT NULL,
  `txnid` varchar(255) NOT NULL,
  `booking_id` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (107,46690,16,'2000','2019-06-19 15:17:07','cheque','','',''),(108,46690,18,'6000','2019-06-19 15:39:50','cheque','','',''),(109,46690,5,'400','2019-06-19 17:29:54','cheque','','',''),(110,10249,18,'6000','2019-06-30 19:08:43','paypal','','',''),(111,29653,5,'400','2019-07-23 12:39:41','paypal','','',''),(112,16302,5,'400','2019-07-25 12:53:06','cheque','','',''),(113,29653,5,'400','2019-07-25 12:58:02','paypal','','',''),(114,29653,5,'400','2019-07-25 12:58:18','dd','','',''),(115,29653,4,'300','2019-07-25 12:58:30','dd','','',''),(116,16912,5,'400','2019-07-29 13:23:06','paypal','','',''),(117,17181,3,'50','2019-08-10 21:55:13','paypal','','',''),(118,15809,3,'50','2019-08-13 15:06:24','cheque','','',''),(119,46690,1,'0','2019-08-13 15:27:21','paypal','','',''),(120,16636,3,'1500','2019-09-05 14:25:34','Razorpay','Completed','pay_DESWOJEwqkl7Ao','SM1567673734'),(121,16636,3,'1','2019-09-06 13:43:55','Razorpay','Completed','pay_DEqHaWkAJnueeq','SM1567757635'),(122,16636,4,'1','2019-09-06 13:49:32','Razorpay','Completed','pay_DEqNGZKq1zl3eA','SM1567757972'),(123,13950,3,'1','2019-09-06 21:22:14','Razorpay','Completed','pay_DEy9IL9j4QQe7T','SM1567785134');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pic_gallery`
--

DROP TABLE IF EXISTS `pic_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pic_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `image_path` varchar(750) NOT NULL,
  `image_path_blur` varchar(750) NOT NULL,
  `date_time` datetime NOT NULL,
  `pic_approval` int(11) NOT NULL,
  `pict_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `shop_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pic_gallery`
--

LOCK TABLES `pic_gallery` WRITE;
/*!40000 ALTER TABLE `pic_gallery` DISABLE KEYS */;
INSERT INTO `pic_gallery` VALUES (1,5136172,'assets/uploads/gallery/5136172-about.png','assets/uploads/gallery/1495610861_blur.png','2017-05-24 12:37:59',1,1),(2,5136172,'assets/uploads/gallery/5136172-add1.png','assets/uploads/gallery/1495610822_blur.png','2017-05-24 12:37:59',1,1),(3,5136172,'assets/uploads/gallery/5136172-basic.png','','2017-05-24 12:37:59',0,0),(4,5136172,'assets/uploads/gallery/5136172-101.jpg','assets/uploads/gallery/1495610822_blur.jpg','2017-05-24 12:44:11',1,1),(7,42566,'assets/uploads/gallery/42566-krishnan.jpg','assets/uploads/gallery/1561022868_blur.jpg','2019-06-20 14:56:24',1,1),(8,42566,'assets/uploads/gallery/42566-IMG-20190408-WA0001.jpg','assets/uploads/gallery/1561027806_blur.jpg','2019-06-20 14:57:06',1,1),(9,15809,'assets/uploads/gallery/15809-Desert.jpg','assets/uploads/gallery/1565689268_blur.jpg','2019-08-13 15:08:27',1,1),(10,15809,'assets/uploads/gallery/15809-Hydrangeas.jpg','assets/uploads/gallery/1565689391_blur.jpg','2019-08-13 15:08:27',1,1),(11,16791,'assets/uploads/gallery/16791-11.jpg','assets/uploads/gallery/1566230835_blur.jpg','2019-08-19 16:30:07',1,1),(12,16791,'assets/uploads/gallery/16791-DSC_5276.JPG','','2019-08-19 16:30:51',1,1),(13,16791,'assets/uploads/gallery/16791-DSC_5287.JPG','','2019-08-19 16:30:51',1,1),(14,16791,'assets/uploads/gallery/16791-DSC_5288.JPG','','2019-08-19 16:30:51',1,1),(15,22525,'assets/uploads/gallery/22525-3.jpg','','2019-08-26 16:05:10',0,1);
/*!40000 ALTER TABLE `pic_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preferences` (
  `preference_id` int(20) NOT NULL AUTO_INCREMENT,
  `profile_id` int(20) NOT NULL,
  `age_from` int(20) NOT NULL,
  `age_to` int(20) NOT NULL,
  `height_from_id` int(10) NOT NULL,
  `height_to_id` int(10) NOT NULL,
  `maritial_status` varchar(255) NOT NULL,
  `physical_status` varchar(255) DEFAULT NULL,
  `eating_habit` varchar(255) NOT NULL,
  `smoking_habit` varchar(255) NOT NULL,
  `drinking_habit` varchar(255) NOT NULL,
  `religion` varchar(255) NOT NULL,
  `caste` varchar(255) NOT NULL,
  `mother_language` varchar(50) NOT NULL,
  `star` varchar(50) NOT NULL,
  `country` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `education` varchar(255) NOT NULL,
  `occupation` varchar(255) NOT NULL,
  `min_income` varchar(30) NOT NULL,
  `about_partner` longtext,
  `preference_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `subcaste` varchar(255) NOT NULL,
  `raasi` varchar(255) NOT NULL,
  `star_id` int(11) NOT NULL,
  `dosham` varchar(255) NOT NULL,
  `weight_from` int(11) NOT NULL,
  `weight_to` int(11) NOT NULL,
  `max_income` varchar(255) NOT NULL,
  `income_currency` varchar(100) NOT NULL,
  `body_type` varchar(255) NOT NULL,
  `complexion` varchar(255) NOT NULL,
  `citizenship` varchar(255) NOT NULL,
  PRIMARY KEY (`preference_id`),
  KEY `profile_id` (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1 COMMENT='Profile preferences';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferences`
--

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
INSERT INTO `preferences` VALUES (25,46690,20,27,13,18,'1','1','0','1','1','3','1856','1','','1','2','','97','1','500000','','2019-06-19 15:11:00','','',0,'',0,0,'0','Lek - ALL','','',''),(26,42566,18,33,1,1,'1','1','1','1','1','14','734','14','','','','','23,24,26','16','1000000','hdiidfidfisi','2019-06-20 12:52:34','','',0,'',0,0,'1000001','? - LKR','','',''),(27,13629,24,30,14,22,'1','0','0','0','0','1','108','1','','','','','','','0','','2019-07-30 19:43:07','','',0,'',0,0,'0','Lek - ALL','','',''),(28,10560,18,30,1,18,'1','0','0','0','0','0','','0','','','','','','','0','','2019-08-07 17:02:12','','',0,'',0,0,'0','Lek - ALL','','',''),(29,16791,18,34,15,19,'1','1','1','1','1','1','2272','1','','1','2,33','','33,38,61,66,67,85','4,49,52,61,64','0','Any Graduate Girl required','2019-08-19 16:38:55','','',0,'',0,0,'0','Lek - ALL','','','');
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_deactivate`
--

DROP TABLE IF EXISTS `profile_deactivate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_deactivate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `deactvated_date` datetime NOT NULL,
  `expiry_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_deactivate`
--

LOCK TABLES `profile_deactivate` WRITE;
/*!40000 ALTER TABLE `profile_deactivate` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_deactivate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_delete`
--

DROP TABLE IF EXISTS `profile_delete`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_delete` (
  `delete_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `delete_reason` varchar(500) DEFAULT NULL,
  `delete_datetime` datetime NOT NULL,
  PRIMARY KEY (`delete_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_delete`
--

LOCK TABLES `profile_delete` WRITE;
/*!40000 ALTER TABLE `profile_delete` DISABLE KEYS */;
INSERT INTO `profile_delete` VALUES (1,74,'marriage fixed','2019-07-29 12:03:35');
/*!40000 ALTER TABLE `profile_delete` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_hobbies`
--

DROP TABLE IF EXISTS `profile_hobbies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_hobbies` (
  `hobby_id` int(20) NOT NULL AUTO_INCREMENT,
  `hobby` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`hobby_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Details of hobbies of members';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_hobbies`
--

LOCK TABLES `profile_hobbies` WRITE;
/*!40000 ALTER TABLE `profile_hobbies` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_hobbies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_interest`
--

DROP TABLE IF EXISTS `profile_interest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_interest` (
  `interest_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `interest_from` int(11) unsigned NOT NULL,
  `interest_to` int(11) unsigned NOT NULL,
  `interest_status` int(10) NOT NULL DEFAULT '0',
  `interest_datetime` datetime NOT NULL,
  PRIMARY KEY (`interest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_interest`
--

LOCK TABLES `profile_interest` WRITE;
/*!40000 ALTER TABLE `profile_interest` DISABLE KEYS */;
INSERT INTO `profile_interest` VALUES (5,46690,16912,0,'2019-06-19 17:30:26'),(6,10249,16912,0,'2019-07-04 09:02:40'),(7,29653,46690,0,'2019-07-23 12:40:03'),(8,29653,10249,0,'2019-07-25 12:58:56'),(9,29653,69285,0,'2019-07-25 12:58:59');
/*!40000 ALTER TABLE `profile_interest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_mails`
--

DROP TABLE IF EXISTS `profile_mails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_mails` (
  `mail_id` int(11) NOT NULL AUTO_INCREMENT,
  `mail_from` int(30) NOT NULL,
  `mail_to` int(30) NOT NULL,
  `mail_content` varchar(500) DEFAULT NULL,
  `mail_datetime` datetime NOT NULL,
  `mail_received` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`mail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_mails`
--

LOCK TABLES `profile_mails` WRITE;
/*!40000 ALTER TABLE `profile_mails` DISABLE KEYS */;
INSERT INTO `profile_mails` VALUES (27,46690,16912,'Hi mounikanarayana','2019-06-19 17:30:22',0),(28,10249,29516,'Hy swetha','2019-06-30 19:28:42',0),(29,10249,16912,'Hi mounikanarayana','2019-06-30 19:42:31',0),(30,10249,16912,'Hy mounikanarayana','2019-07-04 09:03:51',0),(31,10249,16912,'Hy mounikanarayana','2019-07-16 11:54:46',0),(32,29653,10249,'Hi Siva\r\n\r\nHiokasok msaoojkmsam as ','2019-07-25 12:46:28',0),(33,29653,69285,'Hi Munipalle Rajesh Kumar','2019-07-25 12:59:17',0),(34,29653,69285,'Hi Munipalle Rajesh Kumar','2019-07-25 12:59:17',0),(35,29653,10249,'Hi Siva','2019-07-25 12:59:27',0);
/*!40000 ALTER TABLE `profile_mails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_musics`
--

DROP TABLE IF EXISTS `profile_musics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_musics` (
  `music_id` int(20) NOT NULL AUTO_INCREMENT,
  `music` varchar(100) NOT NULL,
  PRIMARY KEY (`music_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Details of interested musics, eg : western';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_musics`
--

LOCK TABLES `profile_musics` WRITE;
/*!40000 ALTER TABLE `profile_musics` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_musics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_photo_request`
--

DROP TABLE IF EXISTS `profile_photo_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_photo_request` (
  `photo_request_id` int(50) NOT NULL AUTO_INCREMENT,
  `photo_request_from` int(30) NOT NULL,
  `photo_request_to` int(30) NOT NULL,
  `photo_request_status` int(10) NOT NULL DEFAULT '0',
  `photo_request_datetime` datetime NOT NULL,
  PRIMARY KEY (`photo_request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_photo_request`
--

LOCK TABLES `profile_photo_request` WRITE;
/*!40000 ALTER TABLE `profile_photo_request` DISABLE KEYS */;
INSERT INTO `profile_photo_request` VALUES (1,29653,10249,1,'2019-07-25 12:42:07');
/*!40000 ALTER TABLE `profile_photo_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_pic_verification`
--

DROP TABLE IF EXISTS `profile_pic_verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_pic_verification` (
  `pic_verification_id` int(30) NOT NULL AUTO_INCREMENT,
  `user_id` int(20) NOT NULL,
  `pic_name` varchar(1000) DEFAULT NULL,
  `pic_location` varchar(1000) DEFAULT NULL,
  `pic_datetime` datetime NOT NULL DEFAULT '2017-01-06 00:00:00',
  `pic_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pic_verification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_pic_verification`
--

LOCK TABLES `profile_pic_verification` WRITE;
/*!40000 ALTER TABLE `profile_pic_verification` DISABLE KEYS */;
INSERT INTO `profile_pic_verification` VALUES (18,52,'1560937038_bride&groom.png','assets/uploads/profile_pics/1560937038_bridegroom.png','2019-06-19 15:07:18',1),(19,55,'1560945343_1494050902_8.jpg','assets/uploads/profile_pics/1560945343_1494050902_8.jpg','2019-06-19 17:25:43',1),(20,60,'1561187452_Profile_img.png','assets/uploads/profile_pics/1561187452_Profile_img.png','2019-06-22 12:40:52',1),(21,61,'1561528976_46450973_2165300903482399_8502430745082462208_n.jpg','assets/uploads/profile_pics/1561528976_46450973_2165300903482399_8502430745082462208_n.jpg','2019-06-26 11:32:56',1),(22,63,'1561702546_IMG-20190408-WA0000.jpg','assets/uploads/profile_pics/1561702546_IMG-20190408-WA0000.jpg','2019-06-28 11:45:46',2),(23,55,'1561966836_package-bg.jpg','assets/uploads/profile_pics/1561966836_package-bg.jpg','2019-07-01 13:10:36',1),(24,69,'1563607405_rhfuidnsv.jpg','assets/uploads/profile_pics/1563607405_rhfuidnsv.jpg','2019-07-20 12:53:25',3),(25,77,'1564481819_phanindra.jpg','assets/uploads/profile_pics/1564481819_phanindra.jpg','2019-07-30 15:46:59',1),(26,84,'1565684973_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1565684973_aravind-kumar-298640.jpg','2019-08-13 13:59:33',1),(27,67,'1566211747_10.JPG','assets/uploads/profile_pics/1566211747_10.JPG','2019-08-19 16:19:07',1),(28,90,'1566814046_1.jpg','assets/uploads/profile_pics/1566814046_1.jpg','2019-08-26 15:37:26',1),(29,91,'1566815758_3.jpg','assets/uploads/profile_pics/1566815758_3.jpg','2019-08-26 16:05:58',1),(30,91,'1566816772_1.jpg','assets/uploads/profile_pics/1566816772_1.jpg','2019-08-26 16:22:52',3),(31,91,'1566816996_4.jpg','assets/uploads/profile_pics/1566816996_4.jpg','2019-08-26 16:26:36',3),(32,91,NULL,'assets/uploads/profile_pics/','2019-08-28 15:10:38',2),(33,91,'1566985332_776534_windows-7-wallpaper-hd-1366x768-free-download.jpg','assets/uploads/profile_pics/1566985332_776534_windows-7-wallpaper-hd-1366x768-free-download.jpg','2019-08-28 15:12:12',1),(34,91,'1566985841_maxresdefault.jpg','assets/uploads/profile_pics/1566985841_maxresdefault.jpg','2019-08-28 15:20:41',1),(35,91,'1566986332_128116-red-omen-black-HP_Omen-video_games-laptop-Hewlett_Packard-Beats-knight-gamers.jpg','assets/uploads/profile_pics/1566986332_128116-red-omen-black-HP_Omen-video_games-laptop-Hewlett_Packard-Beats-knight-gamers.jpg','2019-08-28 15:28:52',1),(36,91,'1566987524_star.jpg','assets/uploads/profile_pics/1566987524_star.jpg','2019-08-28 15:48:44',1),(37,96,'1567055091_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1567055091_aravind-kumar-298640.jpg','2019-08-29 10:34:51',1),(38,96,'1567056067_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1567056067_aravind-kumar-298640.jpg','2019-08-29 10:51:07',1),(39,96,'1567056952_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1567056952_aravind-kumar-298640.jpg','2019-08-29 11:05:52',1),(40,96,'1567057303_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1567057303_aravind-kumar-298640.jpg','2019-08-29 11:11:43',1),(41,96,'1567057459_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1567057459_aravind-kumar-298640.jpg','2019-08-29 11:14:19',1),(42,96,'1567057833_1564481819_phanindra.jpg','assets/uploads/profile_pics/1567057833_1564481819_phanindra.jpg','2019-08-29 11:20:33',1),(43,97,'1567059520_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1567059520_aravind-kumar-298640.jpg','2019-08-29 11:48:40',1),(44,92,'1567784942_kr.ramu.jpeg','assets/uploads/profile_pics/1567784942_kr_ramu.jpeg','2019-09-06 21:19:02',1),(45,103,'1568009700_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1568009700_aravind-kumar-298640.jpg','2019-09-09 11:45:00',1),(46,103,'1568009925_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1568009925_aravind-kumar-298640.jpg','2019-09-09 11:48:45',1),(47,103,'1568010122_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1568010122_aravind-kumar-298640.jpg','2019-09-09 11:52:02',1),(48,103,'1568010715_aravind-kumar-298640.jpg','assets/uploads/profile_pics/1568010715_aravind-kumar-298640.jpg','2019-09-09 12:01:55',1),(49,107,'1568451412_IMG-20190829-WA0016.jpg','assets/uploads/profile_pics/1568451412_IMG-20190829-WA0016.jpg','2019-09-14 14:26:52',1),(50,108,'1569136804_IMG_20190719_221819__01-01.jpeg','assets/uploads/profile_pics/1569136804_IMG_20190719_221819__01-01.jpeg','2019-09-22 12:50:04',1),(51,103,'1569305811_wallpaper.wiki-Rain-Window-Wallpaper-Full-HD-PIC-WPD001200.jpg','assets/uploads/profile_pics/1569305811_wallpaper_wiki-Rain-Window-Wallpaper-Full-HD-PIC-WPD001200.jpg','2019-09-24 11:46:51',3),(52,103,'1569306005_wallpaper.wiki-Pictures-Background-Full-HD-PIC-WPD0013541.png','assets/uploads/profile_pics/1569306005_wallpaper_wiki-Pictures-Background-Full-HD-PIC-WPD0013541.png','2019-09-24 11:50:05',1),(53,103,'1569313351_wallpaper.wiki-Background-Full-HD-Images-For-Desktop-PIC-WPD0013531.png','assets/uploads/profile_pics/1569313351_wallpaper_wiki-Background-Full-HD-Images-For-Desktop-PIC-WPD0013531.png','2019-09-24 13:52:31',1),(54,103,'1569314851_776534_windows-7-wallpaper-hd-1366x768-free-download.jpg','assets/uploads/profile_pics/1569314851_776534_windows-7-wallpaper-hd-1366x768-free-download.jpg','2019-09-24 14:17:31',2),(55,103,'1569317828_128116-red-omen-black-HP_Omen-video_games-laptop-Hewlett_Packard-Beats-knight-gamers.jpg','assets/uploads/profile_pics/1569317828_128116-red-omen-black-HP_Omen-video_games-laptop-Hewlett_Packard-Beats-knight-gamers.jpg','2019-09-24 15:07:08',1),(56,103,'1569390552_Spectrum-Of-The-Sky-Multi-Colors-View-HD-Wallpapers.jpg','assets/uploads/profile_pics/1569390552_Spectrum-Of-The-Sky-Multi-Colors-View-HD-Wallpapers.jpg','2019-09-25 11:19:12',1),(57,103,'1569392022_sample-avatar-300x300.jpg','assets/uploads/profile_pics/1569392022_sample-avatar-300x300.jpg','2019-09-25 11:43:42',1),(58,103,'1569394610_bavatar.jpg','assets/uploads/profile_pics/1569394610_bavatar.jpg','2019-09-25 12:26:50',1),(59,103,'1569395518_avatar2.png','assets/uploads/profile_pics/1569395518_avatar2.png','2019-09-25 12:41:58',1),(60,103,'1569396812_sample-avatar-300x300.jpg','assets/uploads/profile_pics/1569396812_sample-avatar-300x300.jpg','2019-09-25 13:03:32',3),(61,103,'1569396951_1.jpg','assets/uploads/profile_pics/1569396951_1.jpg','2019-09-25 13:05:51',1),(62,103,'1569401181_bavatar.jpg','assets/uploads/profile_pics/1569401181_bavatar.jpg','2019-09-25 14:16:21',1),(63,103,'1569403137_avatar2.png','assets/uploads/profile_pics/1569403137_avatar2.png','2019-09-25 14:48:57',1),(64,103,'1569405214_sample-avatar-300x300.jpg','assets/uploads/profile_pics/1569405214_sample-avatar-300x300.jpg','2019-09-25 15:23:34',1),(65,103,'1569408210_avatar2.png','assets/uploads/profile_pics/1569408210_avatar2.png','2019-09-25 16:13:30',3),(66,103,'1569411369_avatar2.png','assets/uploads/profile_pics/1569411369_avatar2.png','2019-09-25 17:06:09',1),(67,103,'1569412687_sample-avatar-300x300.jpg','assets/uploads/profile_pics/1569412687_sample-avatar-300x300.jpg','2019-09-25 17:28:07',1),(68,103,'1569412815_bavatar.jpg','assets/uploads/profile_pics/1569412815_bavatar.jpg','2019-09-25 17:30:15',1),(69,103,'1569413027_sample-avatar-300x300.jpg','assets/uploads/profile_pics/1569413027_sample-avatar-300x300.jpg','2019-09-25 17:33:51',1),(70,103,'1569413625_images.jpg','assets/uploads/profile_pics/1569413625_images.jpg','2019-09-25 17:43:45',1),(71,103,'1569415148_bavatar.jpg','assets/uploads/profile_pics/1569415148_bavatar.jpg','2019-09-25 18:09:08',1),(72,103,'1569415277_images.jpg','assets/uploads/profile_pics/1569415277_images.jpg','2019-09-25 18:11:17',1),(73,103,'1569415599_sample-avatar-300x300.jpg','assets/uploads/profile_pics/1569415599_sample-avatar-300x300.jpg','2019-09-25 18:16:39',1),(74,103,'1569415901_avatar2.png','assets/uploads/profile_pics/1569415901_avatar2.png','2019-09-25 18:21:41',3),(75,103,'1569416331_images.jpg','assets/uploads/profile_pics/1569416331_images.jpg','2019-09-25 18:28:51',1),(76,103,'1569416494_bavatar.jpg','assets/uploads/profile_pics/1569416494_bavatar.jpg','2019-09-25 18:31:35',1),(77,103,'1569417111_sample-avatar-300x300.jpg','assets/uploads/profile_pics/1569417111_sample-avatar-300x300.jpg','2019-09-25 18:41:51',1),(78,115,'1573133757_careers-banner.png','assets/uploads/profile_pics/1573133757_careers-banner.png','2019-11-07 19:05:57',0);
/*!40000 ALTER TABLE `profile_pic_verification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_recent`
--

DROP TABLE IF EXISTS `profile_recent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_recent` (
  `view_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `viewer` int(11) unsigned NOT NULL,
  `viewed` int(11) unsigned NOT NULL,
  `view_datetime` datetime NOT NULL,
  PRIMARY KEY (`view_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_recent`
--

LOCK TABLES `profile_recent` WRITE;
/*!40000 ALTER TABLE `profile_recent` DISABLE KEYS */;
INSERT INTO `profile_recent` VALUES (30,10249,29516,'2019-06-20 11:37:10'),(31,42566,46690,'2019-06-20 13:01:14'),(32,42566,33188,'2019-06-20 17:54:58'),(33,42566,29516,'2019-06-20 17:56:05'),(34,10249,16912,'2019-06-22 12:10:15'),(35,16380,42566,'2019-06-30 21:46:17'),(36,69285,16912,'2019-07-10 19:48:58'),(37,69285,29516,'2019-07-10 20:31:53'),(38,28380,46690,'2019-07-20 00:38:30'),(39,16380,41905,'2019-07-24 13:52:47'),(40,13629,42566,'2019-07-30 19:17:31'),(41,16380,30742,'2019-08-02 09:31:57'),(42,16380,10249,'2019-08-02 09:52:31'),(43,16380,13629,'2019-08-02 09:53:00'),(44,16380,33188,'2019-08-02 09:53:17'),(45,16380,16791,'2019-08-02 13:25:54'),(46,16380,16912,'2019-08-04 09:33:57'),(47,16380,29516,'2019-08-04 09:37:45'),(48,16380,29653,'2019-08-07 21:57:04'),(49,16380,16302,'2019-08-08 21:50:02'),(50,16380,17181,'2019-08-11 11:33:39'),(51,16380,10432,'2019-08-11 11:34:05'),(52,15809,16302,'2019-08-13 15:21:50'),(53,15809,29516,'2019-08-13 15:35:01'),(54,16380,10967,'2019-08-15 20:47:10'),(55,16380,15032,'2019-08-15 20:54:47');
/*!40000 ALTER TABLE `profile_recent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_shortlist`
--

DROP TABLE IF EXISTS `profile_shortlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_shortlist` (
  `shortlist_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `shot_lister` int(11) unsigned NOT NULL,
  `shot_listed` int(11) unsigned NOT NULL,
  `short_list_datetime` datetime NOT NULL,
  PRIMARY KEY (`shortlist_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_shortlist`
--

LOCK TABLES `profile_shortlist` WRITE;
/*!40000 ALTER TABLE `profile_shortlist` DISABLE KEYS */;
INSERT INTO `profile_shortlist` VALUES (7,46690,16912,'2019-06-19 15:39:15'),(9,10249,16912,'2019-06-30 19:37:58'),(11,16380,41905,'2019-07-15 18:18:43'),(13,69285,29516,'2019-07-23 10:51:33');
/*!40000 ALTER TABLE `profile_shortlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile_sports`
--

DROP TABLE IF EXISTS `profile_sports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile_sports` (
  `sports_id` int(20) NOT NULL AUTO_INCREMENT,
  `sports_name` varchar(100) NOT NULL,
  PRIMARY KEY (`sports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Details of interested sports of members';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile_sports`
--

LOCK TABLES `profile_sports` WRITE;
/*!40000 ALTER TABLE `profile_sports` DISABLE KEYS */;
/*!40000 ALTER TABLE `profile_sports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profiles` (
  `profile_id` int(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(20) DEFAULT NULL,
  `profile_for` varchar(100) DEFAULT NULL,
  `profile_name` varchar(200) DEFAULT NULL,
  `profile_surname` varchar(100) NOT NULL,
  `matrimony_id` int(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_countrycode` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `alt_mobile_country_code` varchar(100) NOT NULL,
  `alt_mobile_no` varchar(100) NOT NULL,
  `dob` date DEFAULT NULL,
  `is_catholic` int(11) NOT NULL DEFAULT '0',
  `age` int(10) DEFAULT NULL,
  `religion` int(10) DEFAULT NULL,
  `caste` int(10) DEFAULT NULL,
  `sub_caste` varchar(100) DEFAULT NULL,
  `division` varchar(100) DEFAULT NULL,
  `income` varchar(100) DEFAULT NULL,
  `income_actual` varchar(100) DEFAULT NULL,
  `mother_language` int(20) DEFAULT NULL,
  `maritial_status` int(20) DEFAULT NULL,
  `children_number` int(11) DEFAULT NULL,
  `children_living` int(11) DEFAULT NULL,
  `willing_intercast` int(11) DEFAULT NULL,
  `mothers_maiden_name` varchar(200) NOT NULL,
  `country` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `city_name_1` varchar(100) NOT NULL,
  `resident_status` varchar(100) DEFAULT NULL,
  `parish` varchar(100) DEFAULT NULL,
  `parish_village` varchar(100) NOT NULL,
  `education_id` int(20) DEFAULT NULL,
  `college` varchar(200) DEFAULT NULL,
  `education_detail` varchar(300) DEFAULT NULL,
  `occupation_id` int(20) DEFAULT NULL,
  `occupation_detail` varchar(300) DEFAULT NULL,
  `employed_in` varchar(100) DEFAULT NULL,
  `occupation_sector` int(20) DEFAULT NULL,
  `height_id` int(20) DEFAULT NULL,
  `weight_id` int(20) DEFAULT NULL,
  `sports_id` int(20) DEFAULT NULL,
  `hobby_id` int(20) DEFAULT NULL,
  `smoking` int(20) DEFAULT NULL,
  `drinking` int(20) DEFAULT NULL,
  `eating` int(20) DEFAULT NULL,
  `music_id` int(20) DEFAULT NULL,
  `complexion` int(20) DEFAULT NULL,
  `physical_status` int(20) DEFAULT NULL,
  `body_type` int(20) DEFAULT NULL,
  `profile_photo` varchar(1000) DEFAULT NULL,
  `profile_photo_blured` varchar(750) NOT NULL,
  `profile_preference` int(11) NOT NULL DEFAULT '0',
  `star_id` int(20) DEFAULT NULL,
  `padam` varchar(50) NOT NULL,
  `gothram` varchar(255) NOT NULL,
  `dosham` int(3) NOT NULL,
  `horo_img` varchar(255) NOT NULL,
  `raasi_id` int(20) DEFAULT NULL,
  `have_dosham` int(10) DEFAULT NULL,
  `dosham_details` varchar(100) DEFAULT NULL,
  `family_type` int(20) DEFAULT NULL,
  `family_status` int(20) DEFAULT NULL,
  `family_value` int(20) DEFAULT NULL,
  `family_origin` varchar(100) DEFAULT NULL,
  `family_location` varchar(100) DEFAULT NULL,
  `family_about` longtext NOT NULL,
  `father_status` varchar(100) DEFAULT NULL,
  `mother_status` varchar(100) DEFAULT NULL,
  `brothers` int(10) DEFAULT '0',
  `sisters` int(10) DEFAULT '0',
  `brothers_married` int(11) DEFAULT NULL,
  `sisters_married` int(11) DEFAULT NULL,
  `partner_preference` int(20) DEFAULT NULL,
  `about_you` longtext,
  `created_date` date NOT NULL,
  `modified_date` date NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `citizenship` varchar(255) DEFAULT NULL,
  `currency` varchar(255) NOT NULL,
  `dnd` int(11) NOT NULL,
  `is_premium` int(11) DEFAULT NULL,
  `is_phone_verified` int(11) DEFAULT NULL,
  `profile_approval` int(11) DEFAULT NULL,
  `profile_status` int(11) DEFAULT NULL,
  `email_unique_id` varchar(100) NOT NULL,
  `profile_highlight` int(11) NOT NULL,
  PRIMARY KEY (`profile_id`),
  KEY `user_id` (`user_id`),
  KEY `religion` (`religion`),
  KEY `caste` (`caste`),
  KEY `sub_caste` (`sub_caste`),
  KEY `mother_language` (`mother_language`),
  KEY `country` (`country`),
  KEY `state` (`state`),
  KEY `city` (`city`),
  KEY `education_id` (`education_id`),
  KEY `occupation_id` (`occupation_id`),
  KEY `height_id` (`height_id`),
  KEY `weight_id` (`weight_id`),
  KEY `sports_id` (`sports_id`),
  KEY `hobby_id` (`hobby_id`),
  KEY `music_id` (`music_id`),
  KEY `star_id` (`star_id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=latin1 COMMENT='All Details of members';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
INSERT INTO `profiles` VALUES (61,61,'myself','Munipalle Rajesh Kumar','kumar',69285,'male','munipallerajesh@gmail.com','09866859925','9866859925','','','1977-08-02',0,41,3,1502,'Niyogi',NULL,'0.00','12000000',1,1,NULL,NULL,NULL,'Go9llapudi',1,33,23,'',NULL,NULL,'',61,NULL,NULL,0,NULL,NULL,2,13,19,NULL,NULL,2,2,1,NULL,1,2,1,'assets/uploads/profile_pics/1561528976_46450973_2165300903482399_8502430745082462208_n.jpg','assets/uploads/profile_pics/1561703134_blur.jpg',0,16,'','Kanvasa',3,'',NULL,NULL,NULL,2,2,1,'','','','','',0,0,NULL,NULL,NULL,'nn','2019-06-26','2019-06-26','',NULL,'Lek',0,2,1,1,1,'',0),(67,67,'myself','V H SUDARSANA RAO ALAMURI','ALAMURI',16791,'male','sudarsan_84vh@yahoo.co.in','09533700153','9533700153','','','1984-07-09',0,35,3,1502,'Brahmin - 6000 Niyogi',NULL,'0.00','300000',1,1,NULL,NULL,NULL,'',1,33,23,'',NULL,NULL,'',72,NULL,NULL,52,NULL,NULL,2,28,24,NULL,NULL,1,1,1,NULL,1,1,1,'assets/uploads/profile_pics/1566211747_10.JPG','',0,11,'4 Padam','Bharadwajasa ',1,'',NULL,NULL,NULL,1,1,1,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,'','2019-07-12','2019-08-23','',NULL,'Rp',0,0,0,1,1,'',0),(77,77,'son','Phaneendra','Devulapalli',13629,'male','devulapalli@gmail.com','+91 ','9949746917','','','1988-10-13',0,30,1,666,'6000 Niyogi',NULL,'17 LAKHS','17 LAKHS',1,1,NULL,NULL,NULL,'',1,33,23,'33','0',NULL,'',96,NULL,NULL,3,'Working In NESS Technologies','Privet',2,34,0,NULL,NULL,1,1,1,NULL,1,1,1,'assets/uploads/profile_pics/1564481819_phanindra.jpg','assets/uploads/profile_pics/1566811549_blur.jpg',0,7,'1 Padam','kasyapasa',0,'phanindra.jpg',NULL,NULL,NULL,0,0,1,'','','','Retired Head Master','Home Maker',0,1,NULL,NULL,1,'','2019-07-30','2019-07-30','',NULL,'INR',0,0,0,1,1,'',0),(82,82,'myself','Raviteja','Viriyala',17181,'male','vrt0594@gmail.com','+91 ','7702939365','','','1994-05-22',0,25,1,109,'ABCD',NULL,'0.00','300000',1,1,NULL,NULL,NULL,'Pulapaka Amulya',1,33,NULL,'33',NULL,NULL,'',96,NULL,NULL,44,NULL,NULL,2,18,16,NULL,NULL,1,2,3,NULL,2,1,1,NULL,'',0,7,'2 Padam','',1,'',NULL,NULL,NULL,1,1,1,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'','2019-08-10','2019-08-10','',NULL,'Rp',0,1,1,0,2,'',0),(88,88,'relative','Sreenivaas','Donepudi',13862,'male','sreenivaas19@gmail.com','+91 ','9959158936','','','1984-03-19',0,35,1,2272,'Velanadu',NULL,'0.00','3.00LPA',1,1,NULL,NULL,NULL,'Parvathi Devi',1,33,NULL,'33',NULL,NULL,'',92,NULL,NULL,64,NULL,NULL,1,13,15,NULL,NULL,1,1,1,NULL,2,1,2,NULL,'',0,26,'3 Padam','Sounakasa',1,'',NULL,NULL,NULL,2,1,2,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'','2019-08-15','2019-08-15','',NULL,'Lek',0,0,1,1,1,'',0),(89,89,'son','Karthik','Koppolu',15258,'male','mathru.k@adityacc.com','+91 ','6301980563','','','1990-08-28',0,28,1,108,'Brahmin - 6000 Niyogi',NULL,'0.00','11,00,000',1,1,NULL,NULL,NULL,'Vijaya Lakshmi',1,33,NULL,'33',NULL,NULL,'',96,NULL,NULL,35,NULL,NULL,2,11,35,NULL,NULL,1,1,1,NULL,2,1,2,NULL,'',0,11,'2 Padam','Kasyapasa',3,'',NULL,NULL,NULL,1,1,2,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'My son is working in FACTSET, Hyd. Earlier he worked in Deloitte, EY. Has one sister who is married. She has one daughter and one son.   The boy is teetotaler.  Loves his family. He is good boy. We are looking for a bride who is caring and sharing and  who is  adjustable to the groom for their continued married life. \r\n','2019-08-21','2019-08-21','',NULL,'Rp',0,0,1,1,1,'',0),(92,92,'myself','Renuka ramu','karri',13950,'male','krrcan@gmail.com','+91 ','9885324983','','','1987-08-09',0,32,1,262,'kapu',NULL,'0.00','50000',1,1,NULL,NULL,NULL,'',1,33,NULL,'33',NULL,NULL,'',82,NULL,NULL,52,NULL,NULL,1,11,20,NULL,NULL,1,1,2,NULL,2,1,1,'assets/uploads/profile_pics/1567784942_kr_ramu.jpeg','',0,3,'0','Tambel Gothram ',1,'',NULL,NULL,NULL,2,2,3,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'I am so sensitive guy and good soul and heart good attitude with others. presently  i  working as a accountants manager in pharma company  ','2019-08-28','2019-08-28','',NULL,'Rp',0,1,1,1,1,'',0),(103,103,'relative','sameer','r',16636,'male','kvs116.wi@gmail.com','+91 ','9603460016','','','1990-08-14',0,29,1,1,'k',NULL,'0.00','400000',1,1,NULL,NULL,NULL,'k',1,2,NULL,'2',NULL,NULL,'',96,NULL,NULL,0,NULL,NULL,2,16,15,NULL,NULL,1,1,2,NULL,2,1,2,'assets/uploads/profile_pics/1569417111_sample-avatar-300x300.jpg','assets/uploads/profile_pics/1569423825_blur.jpg',0,14,'1 Padam','nil',3,'',NULL,NULL,NULL,2,2,2,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'','2019-09-05','2019-09-05','',NULL,'Lek',0,1,1,1,1,'',0),(104,104,'myself','sushmita','avasarala',28297,'female','susmitha567@gmail.com','+91 ','7893419636','','','1981-08-19',0,38,1,62,'golkonda vayaparulu',NULL,'0.00','1,20,000',1,1,NULL,NULL,NULL,'avasarala',1,33,NULL,'33',NULL,NULL,'',82,NULL,NULL,4,NULL,NULL,2,8,20,NULL,NULL,1,1,1,NULL,2,1,2,NULL,'',0,20,'4 Padam','bharadwaja',0,'',NULL,NULL,NULL,1,2,2,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'','2019-09-06','2019-09-06','',NULL,'Lek',0,0,1,1,1,'',0),(105,105,'relative','Venkata Ramya','Raalabandi',28471,'female','rjyhouse77@gmail.com','+91 ','8008813195','','','1993-02-21',0,26,1,64,'vaidikulu velanadu',NULL,'0.00','',1,1,NULL,NULL,NULL,'',-1,-1,-1,'',NULL,NULL,'',96,NULL,NULL,0,NULL,NULL,1,14,10,NULL,NULL,1,1,1,NULL,1,1,1,NULL,'',0,20,'0','bharadwaja',1,'',NULL,NULL,NULL,1,1,1,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'','2019-09-08','2019-09-08','',NULL,'Lek',0,0,0,1,1,'',0),(106,106,'brother','Shasidhar','Yeddula',NULL,'male','neelimaroyal369@gmail.com','+91 ','9741646128','','','1994-09-20',0,24,1,34,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/profile_pics/1569401208_blur.jpg',0,NULL,'','',0,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,NULL,'2019-09-09','2019-09-09','',NULL,'',0,NULL,NULL,NULL,NULL,'',0),(107,107,'brother','Hema Sai Krishna','Atchutuni',14784,'male','atchutunisahi@gmail.com','+91 ','8341006612','','','1992-09-22',0,26,1,108,'Brahmin 6000 niyogi',NULL,'0.00','',1,1,NULL,NULL,NULL,'Katrapati',1,33,NULL,'33',NULL,NULL,'',96,NULL,NULL,51,NULL,NULL,1,27,30,NULL,NULL,1,1,1,NULL,1,1,2,'assets/uploads/profile_pics/1568451412_IMG-20190829-WA0016.jpg','assets/uploads/profile_pics/1569000513_blur.jpg',0,2,'0','Kowndinyasa',1,'',NULL,NULL,NULL,1,1,1,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'','2019-09-14','2019-09-14','',NULL,'Lek',0,0,1,1,1,'',0),(108,108,'brother','Krishna Mohan ','Arimilli',10969,'male','arimillikalyan@gmail.com','+91 ','9032228155','','','1986-07-25',0,33,1,256,'Kamma',NULL,'0.00','1200000',1,1,NULL,NULL,NULL,'Sesha Ratnam',1,33,NULL,'33',NULL,NULL,'',103,NULL,NULL,3,NULL,NULL,2,24,55,NULL,NULL,1,1,1,NULL,2,1,2,'assets/uploads/profile_pics/1569136804_IMG_20190719_221819__01-01.jpeg','',0,0,'0','Chenamalla',1,'',NULL,NULL,NULL,2,1,3,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,'','2019-09-22','2019-09-22','',NULL,'Rp',0,0,1,1,1,'',0),(109,109,'relative','Gayathri','Budaraju',NULL,'female','sandhyagayathrib@gmail.com','+91 ','8143405464','','','1993-11-22',0,25,1,108,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'assets/uploads/profile_pics/1569401208_blur.jpg',0,NULL,'','',0,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,NULL,NULL,'2019-09-22','2019-09-22','',NULL,'',0,NULL,NULL,NULL,NULL,'',0);
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `raasi`
--

DROP TABLE IF EXISTS `raasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `raasi` (
  `raasi_id` int(10) NOT NULL AUTO_INCREMENT,
  `raasi_name` varchar(100) NOT NULL,
  `raasi_status` int(10) DEFAULT '1',
  PRIMARY KEY (`raasi_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 COMMENT='Base raasi';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `raasi`
--

LOCK TABLES `raasi` WRITE;
/*!40000 ALTER TABLE `raasi` DISABLE KEYS */;
INSERT INTO `raasi` VALUES (1,'Aries / Mesh',NULL),(2,'Taurus / Vrishab',NULL),(3,'Gemini / Mithun',NULL),(4,'Cancer / Karka',NULL),(5,'Leo / Simha',NULL),(6,'Virgo / Kanya',NULL),(7,'Libra / Tula',NULL),(8,'Scorpio / Vritchik',NULL),(9,'Sagittarius / Dhanus',NULL),(10,'Capricorn / Makar',NULL),(11,'Aquarius / Kumbh',NULL),(12,'Pisces / Meen',NULL);
/*!40000 ALTER TABLE `raasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `religions`
--

DROP TABLE IF EXISTS `religions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `religions` (
  `religion_id` int(11) NOT NULL AUTO_INCREMENT,
  `religion_name` varchar(17) NOT NULL,
  `religion_status` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`religion_id`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `religions`
--

LOCK TABLES `religions` WRITE;
/*!40000 ALTER TABLE `religions` DISABLE KEYS */;
INSERT INTO `religions` VALUES (3,'Roman Catholic',0),(2,'Christian',1),(1,'Hindu',1),(4,'Muslim - Shia',1),(5,'Muslim - Sunni',1),(6,'Muslim - Others',1),(7,'Sikh',1),(8,'Jain - Digambar',1),(9,'Jain - Shwetambar',1),(10,'Jain - Others',1),(11,'Parsi',1),(12,'Buddhist',1),(13,'Jewish',1),(14,'Inter - Religion',1),(15,'Test ',0),(16,'New',0),(17,'Testt',0),(18,'New Test',0);
/*!40000 ALTER TABLE `religions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `religions_old`
--

DROP TABLE IF EXISTS `religions_old`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `religions_old` (
  `religion_id` int(20) NOT NULL AUTO_INCREMENT,
  `religion_name` varchar(100) NOT NULL,
  `religion_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`religion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COMMENT='Religion table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `religions_old`
--

LOCK TABLES `religions_old` WRITE;
/*!40000 ALTER TABLE `religions_old` DISABLE KEYS */;
INSERT INTO `religions_old` VALUES (1,'Hindu',1),(2,'Muslim - Shia',1),(3,'Muslim - Sunni',1),(4,'Muslim - Others',1),(5,'Christian',1),(6,'Sikh',1),(7,'Jain - Digambar',1),(8,'Jain - Shwetambar',1),(9,'Jain - Others',1),(10,'Parsi',1),(11,'Buddhist',1),(12,'Inter-Religion',1),(13,'testingw',0),(14,'Sikkim',1),(15,'Test',0),(16,'Roman Catholic  (RCM)',1);
/*!40000 ALTER TABLE `religions_old` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `save_search`
--

DROP TABLE IF EXISTS `save_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `save_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `matrimony_id` varchar(50) NOT NULL,
  `age_from` int(11) NOT NULL,
  `age_to` int(11) NOT NULL,
  `height_from` int(11) NOT NULL,
  `height_to` int(11) NOT NULL,
  `mart` varchar(100) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `mother` varchar(100) NOT NULL,
  `caste` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `educs` varchar(100) DEFAULT NULL,
  `occupa` varchar(100) DEFAULT NULL,
  `min_income` varchar(100) NOT NULL,
  `max_income` varchar(100) NOT NULL,
  `eating` varchar(50) NOT NULL,
  `drinking` varchar(50) NOT NULL,
  `smoking` varchar(50) NOT NULL,
  `misc_type` varchar(50) NOT NULL,
  `dont_show` varchar(50) NOT NULL,
  `search_type` int(11) DEFAULT NULL,
  `save_search_name` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `query` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `save_search`
--

LOCK TABLES `save_search` WRITE;
/*!40000 ALTER TABLE `save_search` DISABLE KEYS */;
INSERT INTO `save_search` VALUES (39,'42566',18,18,1,1,'Array','','','','','','',NULL,NULL,'','','','','','','',1,'krei','male',''),(40,'69285',18,70,1,15,'Array','','','','','','',NULL,NULL,'','','','','','','',1,'rajesh1','male',''),(41,'13862',25,35,0,0,'Array','1','1','2272','1','33','23','82,76,97,108,17,16,107',NULL,'','','','','','with_photo','',1,'My Search','male',''),(42,'15258',23,27,1,1,'Array','','1','108','1','33','0','96','52,64,22,60,51,54,62,53,15,31,35,23,49,41','500000','50000','1','1','1','with_photo','',1,'Karthik','','');
/*!40000 ALTER TABLE `save_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `send_sms`
--

DROP TABLE IF EXISTS `send_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `send_sms` (
  `send_sms_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_sms_from` int(11) unsigned NOT NULL,
  `send_sms_to` int(11) unsigned NOT NULL,
  `message` text NOT NULL,
  `send_sms_datetime` datetime NOT NULL,
  PRIMARY KEY (`send_sms_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `send_sms`
--

LOCK TABLES `send_sms` WRITE;
/*!40000 ALTER TABLE `send_sms` DISABLE KEYS */;
INSERT INTO `send_sms` VALUES (6,6539442,9103429,'I am  Akhil (T6539442) from knvknv.com ph: 95634343 i would like to reach out to you.please share your contact details','2017-01-17 14:29:09'),(7,7535161,7180214,'I am  Doan (T7535161) from knck.com ph: 1234567898 i would like to reach out to you.please share your contact details','2017-05-04 23:58:43'),(8,10249,16912,'I am  Siva (T10249) from Pellithoranam.com ph: 9966337383 i would like to reach out to you.please share your contact details','2019-07-04 09:02:21');
/*!40000 ALTER TABLE `send_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `icon` varchar(255) NOT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_username` varchar(255) DEFAULT NULL,
  `smtp_password` varchar(255) DEFAULT NULL,
  `sender_id` int(100) DEFAULT NULL,
  `sms_username` varchar(255) DEFAULT NULL,
  `sms_password` varchar(255) DEFAULT NULL,
  `admin_email` varchar(255) DEFAULT NULL,
  `id_prefix` varchar(255) DEFAULT NULL,
  `paypal` varchar(255) NOT NULL,
  `paypalid` varchar(255) NOT NULL,
  `currency` varchar(255) NOT NULL,
  `currency_symbol` varchar(255) NOT NULL,
  `payment_type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Pellithoranam','https://www.pellithoranam.com/admin/assets/uploads/logo/1565690848_Lighthouse.jpg','https://www.pellithoranam.com/admin/assets/uploads/favicon/1565853733_pellithoranam_logo.png','mail.ooimatrimonial.tk','info@ooimatrimonial.tk','Info@Ooi@89',101,'Pellithoranam','222','info@ooimatrimonial.tk','PT','https://www.sandbox.paypal.com/cgi-bin/webscr','shajeermhmmd@gmail.com','?','INR',0);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings_preferences`
--

DROP TABLE IF EXISTS `settings_preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings_preferences` (
  `settings_id` int(50) NOT NULL AUTO_INCREMENT,
  `matrimony_id` varchar(30) NOT NULL,
  `contact_preference` int(11) NOT NULL DEFAULT '1',
  `autologin_preference` int(11) NOT NULL DEFAULT '1',
  `weeklyphotos_preference` int(11) NOT NULL DEFAULT '1',
  `weeklymatch_preference` int(11) NOT NULL DEFAULT '1',
  `promotions_preference` int(11) NOT NULL DEFAULT '1',
  `profilevisibility_preference` int(11) NOT NULL DEFAULT '1',
  `shortlist_preference` int(11) NOT NULL DEFAULT '1',
  `dailyrecommendations_preference` int(11) NOT NULL DEFAULT '1',
  `notifications_preference` int(10) NOT NULL DEFAULT '1',
  `matchingprofiles_preference` int(10) NOT NULL DEFAULT '1',
  `smsalerts_preference` int(10) NOT NULL DEFAULT '1',
  `call_preference` int(10) NOT NULL DEFAULT '1',
  `shortlistedme_preference` int(11) NOT NULL DEFAULT '1',
  `whoviewedmyprofile_preference` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`settings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings_preferences`
--

LOCK TABLES `settings_preferences` WRITE;
/*!40000 ALTER TABLE `settings_preferences` DISABLE KEYS */;
INSERT INTO `settings_preferences` VALUES (231,'46690',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(232,'39069',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(233,'16912',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(234,'10249',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(235,'29516',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(236,'42566',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(237,'33188',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(238,'89905',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(239,'41905',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(240,'69285',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(241,'30742',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(242,'16380',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(243,'17260',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(244,'10432',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(245,'16791',1,1,1,1,1,0,1,1,1,1,1,1,1,1),(246,'13205',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(247,'28380',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(248,'17908',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(249,'15265',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(250,'14987',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(251,'16302',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(252,'29653',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(253,'13629',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(254,'11125',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(255,'10560',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(256,'17181',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(257,'15809',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(258,'15032',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(259,'10967',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(260,'13862',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(261,'15258',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(262,'16115',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(263,'22525',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(264,'13950',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(265,'11946',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(266,'12033',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(267,'24032',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(268,'16636',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(269,'23496',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(270,'28297',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(271,'28471',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(272,'14784',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(273,'10969',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(274,'14021',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(275,'19027',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(276,'11022',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(277,'19077',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(278,'14018',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(279,'13548',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(280,'12673',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(281,'12984',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(282,'18750',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(283,'12517',1,1,1,1,1,1,1,1,1,1,1,1,1,1),(284,'18184',1,1,1,1,1,1,1,1,1,1,1,1,1,1);
/*!40000 ALTER TABLE `settings_preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `user_type` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `staff_status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'test','e10adc3949ba59abbe56e057f20f883e','test@gmail.com','123456',3,0,0),(2,'jaise','d41d8cd98f00b204e9800998ecf8427e','jaise@gmail.com','123456',3,0,0),(4,'test1','d41d8cd98f00b204e9800998ecf8427e','admin1@gmail.com','123456',3,0,0),(5,'cadmin','e10adc3949ba59abbe56e057f20f883e','cadmin@gmail.com','9447413883',3,0,0),(6,'cadmin','d41d8cd98f00b204e9800998ecf8427e','cadmin@gmail.com','9447413883',3,0,0),(7,'cadmin','d41d8cd98f00b204e9800998ecf8427e','cadmin@gmail.com','9447413883',3,0,0),(8,'cadmin@gmail.com','e10adc3949ba59abbe56e057f20f883e','cadmin@gmail.com','9447413883',3,0,0),(9,'cadmin@gmail.com','e10adc3949ba59abbe56e057f20f883e','cadmin@gmail.com','9447413883',3,0,0),(10,'cadmin@gmail.com','6537e99af2c2223642df9f70a0b5afca','cadmin@gmail.com','9447413883',3,0,0),(11,'admin2@gmail.com','e10adc3949ba59abbe56e057f20f883e','admin2@gmail.com','1212',3,0,0),(12,'admin3@gmail.com','d41d8cd98f00b204e9800998ecf8427e','admin3@gmail.com','123456',3,0,0),(13,'Mariya','d41d8cd98f00b204e9800998ecf8427e','mariya@gmail.com','9998887776',3,0,0),(14,'staff','e10adc3949ba59abbe56e057f20f883e','staff@gmail.com','123456789',3,0,0),(15,'abhishek','07592a7eb95f9fec3fc9340fcf34849a','ABHISHEK@GMAIL.COM','8906785678',3,0,0),(16,'abhishek','f589a6959f3e04037eb2b3eb0ff726ac','ABHISHEK@GMAIL.COM','7896785679',3,0,0),(17,'varma','434eb8d3ae761237261a98bee14f21ca','varma@GMAIL.COM','8790986789',3,0,0),(18,'kiran','b1a5b64256e27fa5ae76d62b95209ab3','kiran@GMAIL.COM','7896789098',3,0,0),(19,'Shankar','a9bc867ac4bd6b29c435578e7702ff54','shankar@ooisolutions.com','9966337383',3,0,1);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staff_roles`
--

DROP TABLE IF EXISTS `staff_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staff_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) DEFAULT NULL,
  `matrimony_members` varchar(100) DEFAULT '0',
  `packages` int(11) DEFAULT '0',
  `settings` int(11) DEFAULT '0',
  `staff` int(11) DEFAULT '0',
  `index_management` int(11) DEFAULT '0',
  `classifieds_management` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff_roles`
--

LOCK TABLES `staff_roles` WRITE;
/*!40000 ALTER TABLE `staff_roles` DISABLE KEYS */;
INSERT INTO `staff_roles` VALUES (19,19,'0',0,0,0,0,0);
/*!40000 ALTER TABLE `staff_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stars`
--

DROP TABLE IF EXISTS `stars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stars` (
  `star_id` int(20) NOT NULL AUTO_INCREMENT,
  `star_name` varchar(100) NOT NULL,
  `star_status` int(10) NOT NULL,
  PRIMARY KEY (`star_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1 COMMENT='Base stars';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stars`
--

LOCK TABLES `stars` WRITE;
/*!40000 ALTER TABLE `stars` DISABLE KEYS */;
INSERT INTO `stars` VALUES (1,'Ashwini',0),(2,'Pushya',0),(3,'Swati',0),(4,'Sravana',0),(5,'Bharani',0),(6,'Ashlesha',0),(7,'Vishakha',0),(8,'Dhanishtha',0),(9,'Krittika',0),(10,'Magha',0),(11,'Anuradha',0),(12,'Satabisha',0),(13,'Rohini',0),(14,'Poorvaphalguni',0),(15,'Jyeshta',0),(16,'Poorvabhadra',0),(17,'Mrigashirsa',0),(18,'Uttaraphalguni',0),(19,'Moola',0),(20,'Uttarabhadra',0),(21,'Ardra',0),(22,'Hasta',0),(23,'Poorvashada',0),(24,'Revati',0),(25,'Punarvasu',0),(26,'Chitra',0),(27,'Uttarashadha',0);
/*!40000 ALTER TABLE `stars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states` (
  `state_id` int(20) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(100) NOT NULL,
  `country_id` int(20) NOT NULL,
  `state_status` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=latin1 COMMENT='Details of states';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states`
--

LOCK TABLES `states` WRITE;
/*!40000 ALTER TABLE `states` DISABLE KEYS */;
INSERT INTO `states` VALUES (1,'Andaman & Nicobar',1,1),(2,'Andhra Pradesh',1,1),(3,'Arunachal Pradesh',1,1),(4,'Assam',1,1),(5,'Bihar',1,1),(6,'Chandigarh',1,1),(7,'Chhattisgarh',1,1),(8,'Dadra & Nagar  Haveli',1,1),(10,'Daman & Diu',1,1),(11,'Delhi / NCR',1,1),(12,'Goa',1,1),(13,'Gujarat',1,1),(14,'Haryana',1,1),(15,'Himachal Pradesh',1,1),(16,'Jammu & Kashmir',1,1),(17,'Jharkand',1,1),(18,'Karnataka',1,1),(19,'Kerala',1,1),(20,'Lakshwadeep',1,1),(21,'Madhya Pradesh',1,1),(22,'Maharashtra',1,1),(23,'Manipur',1,1),(24,'Meghalaya',1,1),(25,'Mizoram',1,1),(26,'Nagaland',1,1),(27,'Orissa',1,1),(28,'Pondicherry',1,1),(29,'Punjab',1,1),(30,'Rajasthan',1,1),(31,'Sikkim',1,1),(32,'Tamil Nadu',1,1),(33,'Telangana',1,1),(34,'Tripura',1,1),(35,'Uttar Pradesh',1,1),(36,'Uttarakhand',1,1),(37,'West Bengal',1,1),(38,'eswrdfeswrf',2,1),(39,'australia',2,1),(72,'The Government of NCT of Delhi',1,1),(73,'Dadra and Nagar Haveli',1,1),(74,'Daman and Diu',1,1),(76,'Puducherry',1,1),(77,'Capital Region',23,1),(78,'Southern Peninsula',23,1),(79,'Western Region',23,1),(80,'Westfjords',23,1),(81,'Northwestern Region',23,1),(82,'Northeastern Region',23,1),(83,'Eastern Region',23,1),(84,'Southern Region',23,1),(85,'Andhra Pradesh',201,0),(86,'Arunachal Pradesh',201,1),(87,'Assam',201,1),(88,'Bihar',201,1),(89,'Telangana',201,1),(90,'Chandigarh',201,1),(91,'Chhattisgarh',201,1),(92,'Dadra and Nagar Haveli',201,1),(93,'Daman and Diu ',201,1),(94,'National Capital Territory of Delhi  ',201,1),(95,'Goa',201,1),(96,'Gujarat',201,1),(97,'Haryana',201,1),(98,'Himachal Pradesh',201,1),(99,'Jammu and Kashmir',201,1),(100,'Jharkhand',201,1),(101,'Karnataka',201,1),(102,'Kerala',201,1),(103,'Lakshadweep',201,1),(104,'Madhya Pradesh',201,1),(105,'Maharashtra',201,1),(106,'Manipur',201,1),(107,'Meghalaya',201,1),(108,'Mizoram',201,1),(109,'Nagaland',201,1),(110,'Odisha',201,1),(111,'Puducherry  ',201,1),(112,'Punjab',201,1),(113,'Rajasthan',201,1),(114,'Sikkim',201,1),(115,'Tamil Nadu',201,1),(116,'Tripura',201,1),(117,'Uttar Pradesh',201,1),(118,'Uttarakhand',201,1),(119,'West Bengal',201,1),(120,'shaju state rr',203,1),(121,'shaju state',203,1),(122,'shaju state',203,1),(123,'wales',6,1),(124,'Alabama',5,1),(125,'Alabama',5,1),(126,'Arizona',5,1),(127,'Arkansas',5,1),(128,'California',5,1),(129,'Colorado',5,1),(130,'Connecticut',5,1),(131,'Delaware',5,1),(132,'Florida',5,1),(133,'Georgia',5,1),(134,'Hawaii',5,1),(135,'Idaho',5,1),(136,' Illinois',5,1),(137,'Indiana',5,1),(138,' Iowa',5,1),(139,'Kansas',5,1),(140,'Kentucky[D]',5,1),(141,'Louisiana',5,1),(142,'Maine',5,1),(143,'Maryland',5,1),(144,'Massachusetts',5,1),(145,'Michigan',5,1),(146,'Mississippi',5,1),(147,'Montana',5,1),(148,'Nebraska',5,1),(149,'Nevada',5,1),(150,'New Hampshire',5,1),(151,'New Jersey',5,1),(152,'New Mexico',5,1),(153,'New York',5,1),(154,'North Carolina',5,1),(155,'North Dakota',5,1),(156,'Ohio',5,1),(157,'Oklahoma',5,1),(158,'Oregon',5,1),(159,'Pennsylvania',5,1),(160,'Rhode Island',5,1),(161,'South Carolina',5,1),(162,'South Dakota',5,1),(163,'Tennessee',5,1),(164,'Texas',5,1),(165,'Utah',5,1),(166,'Vermont',5,1),(167,'Virginia',5,1),(168,'Washington',5,1),(169,'West Virginia',5,1),(170,'Wisconsin',5,1),(171,'Wyoming',5,1),(172,'Abbr',5,1),(173,' District of Columbia',5,1),(174,'American Samoa',5,1),(175,'Guam',5,1),(176,'Northern Mariana Islands',5,1),(177,'Puerto Rico',5,1),(178,'U.S. Virgin Islands',5,1),(179,'Baker Island',5,1),(180,'Howland Island',5,1),(181,'Jarvis Island',5,1),(182,'Johnston Atoll',5,1),(183,'Kingman Reef',5,1),(184,'Midway Atoll',5,1),(185,'Navassa Island',5,1),(186,'Palmyra Atoll',5,1),(187,'Wake Island',5,1),(188,'Petrel Island',5,1),(189,'Serranilla Bank',5,1),(190,'Ontario',50,1),(191,'Quebec',50,1),(192,'British Columbia',50,1),(193,'Alberta',50,1),(194,'Manitoba',50,1),(195,'Saskatchewan',50,1),(196,'Nova Scotia',50,1),(197,'New Brunswick',50,1),(198,' Newfoundland and Labrador',50,1),(199,'Prince Edward Island',50,1),(200,'Northwest Territories',50,1),(201,'Nunavut',50,1),(202,'Yukon',50,1),(203,'England',6,1),(204,'Northern Ireland',6,1),(205,'Scotland',6,1),(206,'Wales',6,1),(207,'New South Wales',12,1),(208,'Victoria',12,1),(209,'Queensland',12,1),(210,'Western Australia',12,1),(211,'South Australia',12,1),(212,'Australian Capital Territory	',12,1),(213,'Tasmania',12,1),(214,'Northern Territory',12,1),(215,'Testtest',1,0);
/*!40000 ALTER TABLE `states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `states_new`
--

DROP TABLE IF EXISTS `states_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `states_new` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(47) NOT NULL,
  `country_id` int(11) NOT NULL,
  `state_status` bit(1) NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `states_new`
--

LOCK TABLES `states_new` WRITE;
/*!40000 ALTER TABLE `states_new` DISABLE KEYS */;
INSERT INTO `states_new` VALUES (1,'Alabama',1,''),(2,'Alaska',1,''),(3,'Arizona',1,''),(4,'Arkansas',1,''),(5,'California',1,''),(6,'Colorado',1,''),(7,'Connecticut',1,''),(8,'Delaware',1,''),(9,'Florida',1,''),(10,'Georgia',1,''),(11,'Hawaii',1,''),(12,'Idaho',1,''),(13,'Illinois',1,''),(14,'Indiana',1,''),(15,'Iowa',1,''),(16,'Kansas',1,''),(17,'Kentucky[D]',1,''),(18,'Louisiana',1,''),(19,'Maine',1,''),(20,'Maryland',1,''),(21,'Massachusetts[E]',1,''),(22,'Michigan',1,''),(23,'Minnesota',1,''),(24,'Mississippi',1,''),(25,'Missouri',1,''),(26,'Montana',1,''),(27,'Nebraska',1,''),(28,'Nevada',1,''),(29,'New Hampshire',1,''),(30,'New Jersey',1,''),(31,'New Mexico',1,''),(32,'New York',1,''),(33,'North Carolina',1,''),(34,'North Dakota',1,''),(35,'Ohio',1,''),(36,'Oklahoma',1,''),(37,'Oregon',1,''),(38,'Pennsylvania[F]',1,''),(39,'Rhode Island[G]',1,''),(40,'South Carolina',1,''),(41,'South Dakota',1,''),(42,'Tennessee',1,''),(43,'Texas',1,''),(44,'Utah',1,''),(45,'Vermont',1,''),(46,'Virginia[H]',1,''),(47,'Washington',1,''),(48,'West Virginia',1,''),(49,'Wisconsin',1,''),(50,'Wyoming',1,''),(51,'District of Columbia',1,''),(52,'American Samoa',1,''),(53,'Guam',1,''),(54,'Northern Mariana Islands[J]',1,''),(55,'Puerto Rico[K]',1,''),(56,'U.S. Virgin Islands',1,''),(57,'Baker Island',1,''),(58,'Howland Island',1,''),(59,'Jarvis Island',1,''),(60,'Johnston Atoll',1,''),(61,'Kingman Reef',1,''),(62,'Midway Atoll[N]',1,''),(63,'Navassa Island[O]',1,''),(64,'Palmyra Atoll[P]',1,''),(65,'Wake Island[Q]',1,''),(66,'Bajo Nuevo Bank (Petrel Island)[19]',1,''),(67,'Serranilla Bank[19]',1,''),(68,'Port Blair',2,''),(69,'Andhra Pradesh',2,''),(70,'Arunachal Pradesh',2,''),(71,'Assam',2,''),(72,'Bihar',2,''),(73,'Chandigarh',2,''),(74,'Chhattisgarh',2,''),(75,'Dadra and Nagar Haveli',2,''),(76,'Daman and Diu',2,''),(77,'National Capital Territory of Delhi',2,''),(78,'Goa',2,''),(79,'Gujarat',2,''),(80,'Haryana',2,''),(81,'Himachal Pradesh',2,''),(82,'Jammu and Kashmir',2,''),(83,'Jharkhand',2,''),(84,'Karnataka',2,''),(85,'Kerala',2,''),(86,'Lakshadweep',2,''),(87,'Madhya Pradesh',2,''),(88,'Maharashtra',2,''),(89,'Manipur',2,''),(90,'Meghalaya',2,''),(91,'Mizoram',2,''),(92,'Nagaland',2,''),(93,'Odisha',2,''),(94,'Puducherry',2,''),(95,'Punjab',2,''),(96,'Rajasthan',2,''),(97,'Sikkim',2,''),(98,'Tamil Nadu',2,''),(99,'Telangana',2,''),(100,'Tripura',2,''),(101,'Uttar Pradesh',2,''),(102,'Uttarakhand',2,''),(103,'West Bengal',2,''),(104,'Pakistan State Oil',3,''),(105,'Pak-Arab Refinery',3,''),(106,'Sui Northern Gas Pipelines',3,''),(107,'Shell Pakistan',3,''),(108,'Oil and Gas Development Co.',3,''),(109,'National Refinery',3,''),(110,'Hub Power Co.',3,''),(111,'K-Electric',3,''),(112,'Attock Refinery',3,''),(113,'Attock Petroleum',3,''),(114,'Lahore Electric Supply Co.',3,''),(115,'Pakistan Refinery',3,''),(116,'Sui Southern Gas Pipelines',3,''),(117,'Pakistan International Airlines',3,''),(118,'Engro Corporation',3,''),(119,'Bangued',4,''),(120,'Agusan',4,''),(121,'del Norte[i]',4,''),(122,'Agusan',4,''),(123,'del Sur',4,''),(124,'Aklan',4,''),(125,'Albay',4,''),(126,'Antique',4,''),(127,'Apayao',4,''),(128,'Aurora',4,''),(129,'Basilan[iv]',4,''),(130,'Bataan',4,''),(131,'Batanes',4,''),(132,'Batangas',4,''),(133,'Benguet[vi]',4,''),(134,'Biliran',4,''),(135,'Bohol',4,''),(136,'Bukidnon',4,''),(137,'Bulacan',4,''),(138,'Cagayan',4,''),(139,'Camarines',4,''),(140,'Norte',4,''),(141,'Camarines',4,''),(142,'Sur[vii]',4,''),(143,'Camiguin',4,''),(144,'Capiz',4,''),(145,'Catanduanes',4,''),(146,'Cavite',4,''),(147,'Cebu[viii]',4,''),(148,'Compostela Valley',4,''),(149,'Cotabato',4,''),(150,'Davao',4,''),(151,'del Norte',4,''),(152,'Davao',4,''),(153,'del Sur[ix]',4,''),(154,'Davao',4,''),(155,'Occidental',4,''),(156,'Davao',4,''),(157,'Oriental',4,''),(158,'Dinagat Islands',4,''),(159,'Eastern Samar',4,''),(160,'Guimaras',4,''),(161,'Ifugao',4,''),(162,'Ilocos',4,''),(163,'Norte',4,''),(164,'Ilocos',4,''),(165,'Sur',4,''),(166,'Iloilo[x]',4,''),(167,'Isabela[xi]',4,''),(168,'Kalinga',4,''),(169,'La Union',4,''),(170,'Laguna',4,''),(171,'Lanao',4,''),(172,'del Norte[xii]',4,''),(173,'Lanao',4,''),(174,'del Sur',4,''),(175,'Leyte[xiii]',4,''),(176,'Maguindanao[xiv]',4,''),(177,'Marinduque',4,''),(178,'Masbate',4,''),(179,'Misamis',4,''),(180,'Occidental',4,''),(181,'Misamis',4,''),(182,'Oriental[xv]',4,''),(183,'Mountain',4,''),(184,'Province',4,''),(185,'Negros',4,''),(186,'Occidental[xvi]',4,''),(187,'Negros',4,''),(188,'Oriental',4,''),(189,'Northern Samar',4,''),(190,'Nueva Ecija',4,''),(191,'Nueva Vizcaya',4,''),(192,'Occidental',4,''),(193,'Mindoro',4,''),(194,'Oriental',4,''),(195,'Mindoro',4,''),(196,'Palawan[xviii]',4,''),(197,'Pampanga[xix]',4,''),(198,'Pangasinan[xx]',4,''),(199,'Quezon[xxi]',4,''),(200,'Quirino',4,''),(201,'Rizal',4,''),(202,'Romblon',4,''),(203,'Samar',4,''),(204,'Sarangani',4,''),(205,'Siquijor',4,''),(206,'Sorsogon',4,''),(207,'South Cotabato[xxiii]',4,''),(208,'Southern Leyte',4,''),(209,'Sultan Kudarat',4,''),(210,'Sulu',4,''),(211,'Surigao',4,''),(212,'del Norte',4,''),(213,'Surigao',4,''),(214,'del Sur',4,''),(215,'Tarlac',4,''),(216,'Tawi-Tawi',4,''),(217,'Zambales[xxiv]',4,''),(218,'Zamboanga',4,''),(219,'del Norte',4,''),(220,'Zamboanga',4,''),(221,'del Sur[xxv]',4,''),(222,'Zamboanga',4,''),(223,'Sibugay',4,''),(224,'Metro Manila',4,''),(225,'Abia',5,''),(226,'Adamawa',5,''),(227,'Anambra',5,''),(228,'Akwa Ibom',5,''),(229,'Bauchi',5,''),(230,'Bayelsa',5,''),(231,'Benue',5,''),(232,'Borno',5,''),(233,'Cross River',5,''),(234,'Delta',5,''),(235,'Ebonyi',5,''),(236,'Enugu',5,''),(237,'Edo',5,''),(238,'Ekiti',5,''),(239,'Gombe',5,''),(240,'Imo',5,''),(241,'Jigawa',5,''),(242,'Kaduna',5,''),(243,'Kano',5,''),(244,'Katsina',5,''),(245,'Kebbi',5,''),(246,'Kogi',5,''),(247,'Kwara',5,''),(248,'Lagos',5,''),(249,'Nasarawa',5,''),(250,'Niger',5,''),(251,'Ogun',5,''),(252,'Ondo',5,''),(253,'Osun',5,''),(254,'Oyo',5,''),(255,'Plateau',5,''),(256,'Rivers',5,''),(257,'Sokoto',5,''),(258,'Taraba',5,''),(259,'Yobe',5,''),(260,'Zamfara',5,''),(261,'Federal Capital Territory (FCT)',5,''),(262,'England',6,''),(263,'Northern Ireland',6,''),(264,'Scotland',6,''),(265,'Wales',6,''),(266,'Winfried Kretschmann (Greens)',7,''),(267,'Bavaria',7,''),(268,'(Freistaat Bayern)',7,''),(269,'Berlin',7,''),(270,'Brandenburg',7,''),(271,'Bremen',7,''),(272,'(Freie Hansestadt Bremen)',7,''),(273,'Hamburg',7,''),(274,'(Freie und Hansestadt Hamburg)',7,''),(275,'Hesse',7,''),(276,'(Hessen)',7,''),(277,'Lower Saxony',7,''),(278,'(Niedersachsen)',7,''),(279,'Mecklenburg-Vorpommern',7,''),(280,'North Rhine-',7,''),(281,'Westphalia',7,''),(282,'(Nordrhein-Westfalen)',7,''),(283,'Rhineland-Palatinate',7,''),(284,'(Rheinland-Pfalz)',7,''),(285,'Saarland',7,''),(286,'Saxony',7,''),(287,'(Freistaat Sachsen)',7,''),(288,'Saxony-Anhalt',7,''),(289,'(Sachsen-Anhalt)',7,''),(290,'Schleswig-Holstein',7,''),(291,'Thuringia',7,''),(292,'(Freistaat Th?ringen)',7,''),(293,'Quebec',8,''),(294,'Nova Scotia',8,''),(295,'New Brunswick',8,''),(296,'Manitoba',8,''),(297,'British Columbia',8,''),(298,'Prince Edward Island',8,''),(299,'Saskatchewan',8,''),(300,'Alberta',8,''),(301,'Newfoundland and Labrador',8,''),(302,'?le-de-France (Paris)',9,''),(303,'Berry (Bourges)',9,''),(304,'Orl?anais (Orl?ans)',9,''),(305,'Normandy (Rouen)',9,''),(306,'Languedoc (Toulouse)',9,''),(307,'Lyonnais (Lyon)',9,''),(308,'Dauphin? (Grenoble)',9,''),(309,'Champagne (Troyes)',9,''),(310,'Aunis (La Rochelle)',9,''),(311,'Saintonge (Saintes)',9,''),(312,'Poitou (Poitiers)',9,''),(313,'Guyenne and Gascony (Bordeaux)',9,''),(314,'Burgundy (Dijon)',9,''),(315,'Picardy (Amiens)',9,''),(316,'Anjou (Angers)',9,''),(317,'Provence (Aix-en-Provence)',9,''),(318,'Angoumois (Angoul?me)',9,''),(319,'Bourbonnais (Moulins)',9,''),(320,'Marche (Gu?ret)',9,''),(321,'Brittany (Rennes)',9,''),(322,'Maine (Le Mans)',9,''),(323,'Touraine (Tours)',9,''),(324,'Limousin (Limoges)',9,''),(325,'Foix (Foix)',9,''),(326,'Auvergne (Clermont-Ferrand)',9,''),(327,'B?arn (Pau)',9,''),(328,'Alsace',9,''),(329,'Artois',9,''),(330,'Roussillon',9,''),(331,'Flanders and Hainaut',9,''),(332,'Franche-Comt?',9,''),(333,'Lorraine (Nancy);',9,''),(334,'Trois-?v?ch?s',9,''),(335,'Corsica',9,''),(336,'Nivernais',9,''),(337,'Australian Antarctic Territory',10,''),(338,'Australian Capital Territory',10,''),(339,'Christmas Island',10,''),(340,'Cocos (Keeling) Islands',10,''),(341,'Coral Sea Islands',10,''),(342,'Heard Island and McDonald Islands',10,''),(343,'Jervis Bay Territory',10,''),(344,'New South Wales',10,''),(345,'Norfolk Island',10,''),(346,'Northern Territory',10,''),(347,'Queensland',10,''),(348,'South Australia',10,''),(349,'Tasmania',10,''),(350,'Victoria',10,''),(351,'Western Australia',10,''),(352,'Agrigento',11,''),(353,'Alessandria',11,''),(354,'Ancona',11,''),(355,'Aosta',11,''),(356,'Arezzo',11,''),(357,'Ascoli Piceno',11,''),(358,'Asti',11,''),(359,'Avellino',11,''),(360,'Bari',11,''),(361,'Barletta-Andria-Trani',11,''),(362,'Belluno',11,''),(363,'Benevento',11,''),(364,'Bergamo',11,''),(365,'Biella',11,''),(366,'Bologna',11,''),(367,'South Tyrol[note 1]',11,''),(368,'Brescia',11,''),(369,'Brindisi',11,''),(370,'Cagliari',11,''),(371,'Caltanissetta',11,''),(372,'Campobasso',11,''),(373,'Carbonia-Iglesias',11,''),(374,'Caserta',11,''),(375,'Catania',11,''),(376,'Catanzaro',11,''),(377,'Chieti',11,''),(378,'Como',11,''),(379,'Cosenza',11,''),(380,'Cremona',11,''),(381,'Crotone',11,''),(382,'Cuneo',11,''),(383,'Enna',11,''),(384,'Fermo',11,''),(385,'Ferrara',11,''),(386,'Florence',11,''),(387,'Foggia',11,''),(388,'Forl?-Cesena',11,''),(389,'Frosinone',11,''),(390,'Genoa',11,''),(391,'Gorizia',11,''),(392,'Grosseto',11,''),(393,'Imperia',11,''),(394,'Isernia',11,''),(395,'La Spezia',11,''),(396,'L\'Aquila',11,''),(397,'Latina',11,''),(398,'Lecce',11,''),(399,'Lecco',11,''),(400,'Livorno',11,''),(401,'Lodi',11,''),(402,'Lucca',11,''),(403,'Macerata',11,''),(404,'Mantua',11,''),(405,'Massa and Carrara',11,''),(406,'Matera',11,''),(407,'Medio Campidano',11,''),(408,'Messina',11,''),(409,'Milan',11,''),(410,'Modena',11,''),(411,'Monza and Brianza',11,''),(412,'Naples',11,''),(413,'Novara',11,''),(414,'Nuoro',11,''),(415,'Ogliastra',11,''),(416,'Olbia-Tempio',11,''),(417,'Oristano',11,''),(418,'Padua',11,''),(419,'Palermo',11,''),(420,'Parma',11,''),(421,'Pavia',11,''),(422,'Perugia',11,''),(423,'Pesaro and Urbino',11,''),(424,'Pescara',11,''),(425,'Piacenza',11,''),(426,'Pisa',11,''),(427,'Pistoia',11,''),(428,'Pordenone',11,''),(429,'Potenza',11,''),(430,'Prato',11,''),(431,'Ragusa',11,''),(432,'Ravenna',11,''),(433,'Reggio Calabria',11,''),(434,'Reggio Emilia',11,''),(435,'Rieti',11,''),(436,'Rimini',11,''),(437,'Rome',11,''),(438,'Rovigo',11,''),(439,'Salerno',11,''),(440,'Sassari',11,''),(441,'Savona',11,''),(442,'Siena',11,''),(443,'Sondrio',11,''),(444,'Syracuse',11,''),(445,'Taranto',11,''),(446,'Teramo',11,''),(447,'Terni',11,''),(448,'Trapani',11,''),(449,'Trentino',11,''),(450,'Treviso',11,''),(451,'Trieste',11,''),(452,'Turin',11,''),(453,'Udine',11,''),(454,'Varese',11,''),(455,'Venice',11,''),(456,'Verbano-Cusio-Ossola',11,''),(457,'Vercelli',11,''),(458,'Verona',11,''),(459,'Vibo Valentia',11,''),(460,'Vicenza',11,''),(461,'Viterbo',11,''),(462,'Barisal Division',12,''),(463,'Chittagong Division',12,''),(464,'Dhaka Division',12,''),(465,'Khulna Division',12,''),(466,'Mymensingh Division',12,''),(467,'Rajshahi Division',12,''),(468,'Rangpur Division',12,''),(469,'Sylhet Division',12,''),(470,'Alexandria',13,''),(471,'Aswan',13,''),(472,'Asyut',13,''),(473,'Beheira',13,''),(474,'Beni Suef',13,''),(475,'Cairo',13,''),(476,'Dakahlia',13,''),(477,'Damietta',13,''),(478,'Faiyum',13,''),(479,'Gharbia',13,''),(480,'Giza',13,''),(481,'Ismailia',13,''),(482,'Kafr El Sheikh',13,''),(483,'Luxor',13,''),(484,'Matruh',13,''),(485,'Minya',13,''),(486,'Monufia',13,''),(487,'New Valley',13,''),(488,'North Sinai',13,''),(489,'Port Said',13,''),(490,'Qalyubia',13,''),(491,'Qena',13,''),(492,'Red Sea',13,''),(493,'Sharqia',13,''),(494,'Sohag',13,''),(495,'South Sinai',13,''),(496,'Suez',13,''),(497,'Amnat Charoen',14,''),(498,'Ang Thong',14,''),(499,'Bangkok Metropolis',14,''),(500,'Bueng Kan',14,''),(501,'Buri Ram',14,''),(502,'Chachoengsao',14,''),(503,'Chai Nat',14,''),(504,'Chaiyaphum',14,''),(505,'Chanthaburi',14,''),(506,'Chiang Mai',14,''),(507,'Chiang Rai',14,''),(508,'Chon Buri',14,''),(509,'Chumphon',14,''),(510,'Kalasin',14,''),(511,'Kamphaeng Phet',14,''),(512,'Kanchanaburi',14,''),(513,'Khon Kaen',14,''),(514,'Krabi',14,''),(515,'Lampang',14,''),(516,'Lamphun',14,''),(517,'Loei',14,''),(518,'Lop Buri',14,''),(519,'Mae Hong Son',14,''),(520,'Maha Sarakham',14,''),(521,'Mukdahan',14,''),(522,'Nakhon Nayok',14,''),(523,'Nakhon Pathom',14,''),(524,'Nakhon Phanom',14,''),(525,'Nakhon Ratchasima',14,''),(526,'Nakhon Sawan',14,''),(527,'Nakhon Si Thammarat',14,''),(528,'Nan',14,''),(529,'Narathiwat',14,''),(530,'Nong Bua Lam Phu',14,''),(531,'Nong Khai',14,''),(532,'Nonthaburi',14,''),(533,'Pathum Thani',14,''),(534,'Pattani',14,''),(535,'Phangnga',14,''),(536,'Phatthalung',14,''),(537,'Phayao',14,''),(538,'Phetchabun',14,''),(539,'Phetchaburi',14,''),(540,'Phichit',14,''),(541,'Phitsanulok',14,''),(542,'Phrae',14,''),(543,'Phra Nakhon Si Ayutthaya',14,''),(544,'Phuket',14,''),(545,'Prachin Buri',14,''),(546,'Prachuap Khiri Khan',14,''),(547,'Ranong',14,''),(548,'Ratchaburi',14,''),(549,'Rayong',14,''),(550,'Roi Et',14,''),(551,'Sa Kaeo',14,''),(552,'Sakon Nakhon',14,''),(553,'Samut Prakan',14,''),(554,'Samut Sakhon',14,''),(555,'Samut Songkhram',14,''),(556,'Saraburi',14,''),(557,'Satun',14,''),(558,'Sing Buri',14,''),(559,'Si Sa Ket',14,''),(560,'Songkhla',14,''),(561,'Sukhothai',14,''),(562,'Suphan Buri',14,''),(563,'Surat Thani',14,''),(564,'Surin',14,''),(565,'Tak',14,''),(566,'Trang',14,''),(567,'Trat',14,''),(568,'Ubon Ratchathani',14,''),(569,'Udon Thani',14,''),(570,'Uthai Thani',14,''),(571,'Uttaradit',14,''),(572,'Yala',14,''),(573,'Yasothon',14,''),(574,'Drenthe',15,''),(575,'Flevoland',15,''),(576,'Friesland (Frysl?n)[A]',15,''),(577,'Gelderland',15,''),(578,'Groningen[B]',15,''),(579,'Limburg',15,''),(580,'North Brabant',15,''),(581,'North Holland',15,''),(582,'Overijssel',15,''),(583,'South Holland',15,''),(584,'Utrecht',15,''),(585,'Zeeland',15,''),(586,'Koshi',16,''),(587,'Janakpur',16,''),(588,'Bagmati',16,''),(589,'Gandaki',16,''),(590,'Lumbini',16,''),(591,'Karnali',16,''),(592,'Far West',16,''),(593,'The Eastern Cape',17,''),(594,'The Free State',17,''),(595,'Gauteng',17,''),(596,'KwaZulu-Natal',17,''),(597,'Limpopo',17,''),(598,'Mpumalanga',17,''),(599,'The Northern Cape',17,''),(600,'North West',17,''),(601,'The Western Cape',17,''),(602,'Greater Poland (Wielkopolskie)',18,''),(603,'Kuyavian-Pomeranian (Kujawsko-pomorskie)',18,''),(604,'Lesser Poland (Ma?opolskie)',18,''),(605,'Lodz (L?dzkie)',18,''),(606,'Lower Silesian (Dolnoslaskie)',18,''),(607,'Lublin (Lubelskie)',18,''),(608,'Lubusz (Lubuskie)',18,''),(609,'Masovian (Mazowieckie)',18,''),(610,'Opole (Opolskie)',18,''),(611,'Podlasie (Podlaskie)',18,''),(612,'Pomeranian (Pomorskie)',18,''),(613,'Silesian (Slaskie)',18,''),(614,'Subcarpathian (Podkarpackie)',18,''),(615,'Swietokrzyskie (Swietokrzyskie)',18,''),(616,'Warmian-Masurian (Warminsko-mazurskie)',18,''),(617,'Western Pomeranian (Zachodniopomorskie)',18,''),(618,'Adana',19,''),(619,'Ad?yaman',19,''),(620,'Afyonkarahisar',19,''),(621,'A?r?',19,''),(622,'Amasya',19,''),(623,'Ankara',19,''),(624,'Antalya',19,''),(625,'Artvin',19,''),(626,'Ayd?n',19,''),(627,'Bal?kesir',19,''),(628,'Bilecik',19,''),(629,'Bing?l',19,''),(630,'Bitlis',19,''),(631,'Bolu',19,''),(632,'Burdur',19,''),(633,'Bursa',19,''),(634,'?anakkale',19,''),(635,'?ank?r?',19,''),(636,'?orum',19,''),(637,'Denizli',19,''),(638,'Diyarbak?r',19,''),(639,'Edirne',19,''),(640,'Elaz??',19,''),(641,'Erzincan',19,''),(642,'Erzurum',19,''),(643,'Eski?ehir',19,''),(644,'Gaziantep',19,''),(645,'Giresun',19,''),(646,'G?m??hane',19,''),(647,'Hakk?ri',19,''),(648,'Hatay',19,''),(649,'Isparta',19,''),(650,'Mersin',19,''),(651,'Istanbul',19,''),(652,'?zmir',19,''),(653,'Kars',19,''),(654,'Kastamonu',19,''),(655,'Kayseri',19,''),(656,'K?rklareli',19,''),(657,'K?r?ehir',19,''),(658,'Kocaeli',19,''),(659,'Konya',19,''),(660,'K?tahya',19,''),(661,'Malatya',19,''),(662,'Manisa',19,''),(663,'Kahramanmara?',19,''),(664,'Mardin',19,''),(665,'Mu?la',19,''),(666,'Mu?',19,''),(667,'Nev?ehir',19,''),(668,'Ni?de',19,''),(669,'Ordu',19,''),(670,'Rize',19,''),(671,'Sakarya',19,''),(672,'Samsun',19,''),(673,'Siirt',19,''),(674,'Sinop',19,''),(675,'Sivas',19,''),(676,'Tekirda?',19,''),(677,'Tokat',19,''),(678,'Trabzon',19,''),(679,'Tunceli',19,''),(680,'?anl?urfa',19,''),(681,'U?ak',19,''),(682,'Van',19,''),(683,'Yozgat',19,''),(684,'Zonguldak',19,''),(685,'Aksaray',19,''),(686,'Bayburt',19,''),(687,'Karaman',19,''),(688,'K?r?kkale',19,''),(689,'Batman',19,''),(690,'??rnak',19,''),(691,'Bart?n',19,''),(692,'Ardahan',19,''),(693,'I?d?r',19,''),(694,'Yalova',19,''),(695,'Karab?k',19,''),(696,'Kilis',19,''),(697,'Osmaniye',19,''),(698,'D?zce',19,''),(699,'Al-Anbar',20,''),(700,'Al-Basrah',20,''),(701,'Al-Muthanna',20,''),(702,'Al-Qadisiyah',20,''),(703,'An-Najaf',20,''),(704,'Arbil',20,''),(705,'As-Sulaymaniyah',20,''),(706,'Babil',20,''),(707,'Baghdad',20,''),(708,'Dahuk',20,''),(709,'Dhi Qar',20,''),(710,'Diyala',20,''),(711,'Halabja',20,''),(712,'Karbala\'',20,''),(713,'Kirkuk',20,''),(714,'Maysan',20,''),(715,'Ninawa',20,''),(716,'Salah ad-Din',20,''),(717,'Wasit',20,''),(718,'Northern',21,''),(719,'North Western',21,''),(720,'Western',21,''),(721,'North Central',21,''),(722,'Central',21,''),(723,'Sabaragamuwa',21,''),(724,'Eastern',21,''),(725,'Uva',21,''),(726,'Southern',21,''),(727,'Badajoz',22,''),(728,'C?ceres',22,''),(729,'Ciudad Real',22,''),(730,'Zaragoza',22,''),(731,'Cuenca',22,''),(732,'Huesca',22,''),(733,'Le?n',22,''),(734,'Toledo',22,''),(735,'Albacete',22,''),(736,'Teruel',22,''),(737,'Burgos',22,''),(738,'Seville',22,''),(739,'C?rdoba',22,''),(740,'Ja?n',22,''),(741,'Granada',22,''),(742,'Salamanca',22,''),(743,'Guadalajara',22,''),(744,'Lleida',22,''),(745,'Murcia',22,''),(746,'Valencia',22,''),(747,'Asturias',22,''),(748,'Zamora',22,''),(749,'Navarre',22,''),(750,'Soria',22,''),(751,'Huelva',22,''),(752,'Lugo',22,''),(753,'Almer?a',22,''),(754,'Valladolid',22,''),(755,'Palencia',22,''),(756,'?vila',22,''),(757,'Madrid',22,''),(758,'A Coru?a',22,''),(759,'Barcelona',22,''),(760,'C?diz',22,''),(761,'M?laga',22,''),(762,'Ourense',22,''),(763,'Segovia',22,''),(764,'Castell?n',22,''),(765,'Tarragona',22,''),(766,'Girona',22,''),(767,'Alicante',22,''),(768,'Cantabria',22,''),(769,'La Rioja',22,''),(770,'Balearic Islands',22,''),(771,'Pontevedra',22,''),(772,'Las Palmas',22,''),(773,'Santa Cruz de Tenerife',22,''),(774,'?lava',22,''),(775,'Biscay',22,''),(776,'Gipuzkoa',22,''),(777,'Melilla',22,''),(778,'Ceuta',22,''),(779,'Beijing Municipality',23,''),(780,'Tianjin Municipality',23,''),(781,'Hebei Province',23,''),(782,'Shanxi Province',23,''),(783,'Inner Mongolia Autonomous Region',23,''),(784,'Liaoning Province',23,''),(785,'Jilin Province',23,''),(786,'Heilongjiang Province',23,''),(787,'Shanghai Municipality',23,''),(788,'Jiangsu Province',23,''),(789,'Zhejiang Province',23,''),(790,'Anhui Province',23,''),(791,'Fujian Province',23,''),(792,'Jiangxi Province',23,''),(793,'Shandong Province',23,''),(794,'Henan Province',23,''),(795,'Hubei Province',23,''),(796,'Hunan Province',23,''),(797,'Guangdong Province',23,''),(798,'Guangxi Zhuang Autonomous Region',23,''),(799,'Hainan Province',23,''),(800,'Chongqing Municipality',23,''),(801,'Sichuan Province',23,''),(802,'Guizhou Province',23,''),(803,'Yunnan Province',23,''),(804,'Tibet Autonomous Region',23,''),(805,'Shaanxi Province',23,''),(806,'Gansu Province',23,''),(807,'Qinghai Province',23,''),(808,'Ningxia Hui Autonomous Region',23,''),(809,'Xinjiang Uyghur Autonomous Region',23,''),(810,'Taiwan Province5',23,''),(811,'Hong Kong Special Administrative Region',23,''),(812,'Macau Special Administrative Region',23,''),(813,'Acre',24,''),(814,'Alagoas',24,''),(815,'Amap?',24,''),(816,'Amazonas',24,''),(817,'Bahia',24,''),(818,'Cear?',24,''),(819,'Distrito Federal',24,''),(820,'Esp?rito Santo',24,''),(821,'Goi?s',24,''),(822,'Maranh?o',24,''),(823,'Mato Grosso',24,''),(824,'Mato Grosso do Sul',24,''),(825,'Minas Gerais',24,''),(826,'Par?',24,''),(827,'Para?ba',24,''),(828,'Paran?',24,''),(829,'Pernambuco',24,''),(830,'Piau?',24,''),(831,'Rio de Janeiro',24,''),(832,'Rio Grande do Norte',24,''),(833,'Rio Grande do Sul',24,''),(834,'Rond?nia',24,''),(835,'Roraima',24,''),(836,'Santa Catarina',24,''),(837,'S?o Paulo',24,''),(838,'Sergipe',24,''),(839,'Tocantins',24,''),(840,'?ngermanland',25,''),(841,'Blekinge',25,''),(842,'Bohusl?n',25,''),(843,'Dalarna',25,''),(844,'Dalsland',25,''),(845,'Gotland',25,''),(846,'G?strikland',25,''),(847,'Halland',25,''),(848,'H?lsingland',25,''),(849,'H?rjedalen',25,''),(850,'J?mtland',25,''),(851,'Lappland',25,''),(852,'Medelpad',25,''),(853,'Norrbotten',25,''),(854,'N?rke',25,''),(855,'?land',25,''),(856,'?sterg?tland',25,''),(857,'Sk?ne',25,''),(858,'Sm?land',25,''),(859,'S?dermanland',25,''),(860,'Uppland',25,''),(861,'V?rmland',25,''),(862,'V?stmanland',25,''),(863,'V?sterbotten',25,''),(864,'V?sterg?tland',25,''),(865,'Central',26,''),(866,'Coast',26,''),(867,'Eastern',26,''),(868,'Nairobi',26,''),(869,'North Eastern',26,''),(870,'Nyanza',26,''),(871,'Rift Valley',26,''),(872,'Western',26,''),(873,'Adamawa (Adamaoua)',27,''),(874,'Centre',27,''),(875,'East (Est)',27,''),(876,'Far North (Extreme-Nord)',27,''),(877,'Littoral',27,''),(878,'North (Nord)',27,''),(879,'Northwest (Nord-Ouest)',27,''),(880,'South (Sud)',27,''),(881,'Southwest (Sud-Ouest)',27,''),(882,'West (Ouest)',27,''),(883,'See also',27,''),(884,'References',27,''),(885,'Johor',28,''),(886,'Kedah',28,''),(887,'Kelantan',28,''),(888,'Kuala Lumpur',28,''),(889,'Labuan',28,''),(890,'Melaka',28,''),(891,'Negeri Sembilan',28,''),(892,'Pahang',28,''),(893,'Perak',28,''),(894,'Perlis',28,''),(895,'Pulau Pinang',28,''),(896,'Putrajaya',28,''),(897,'Sabah',28,''),(898,'Sarawak',28,''),(899,'Selangor',28,''),(900,'Terengganu',28,''),(901,'Adygea, Republic of',29,''),(902,'Maykop',29,''),(903,'Bashkortostan, Republic of',29,''),(904,'Buryatia, Republic of',29,''),(905,'Altai Republic',29,''),(906,'Dagestan, Republic of',29,''),(907,'Ingushetia, Republic of',29,''),(908,'Kabardino-Balkar Republic',29,''),(909,'Kalmykia, Republic of',29,''),(910,'Karachay-Cherkess Republic',29,''),(911,'Karelia, Republic of',29,''),(912,'Komi Republic',29,''),(913,'Mari El Republic',29,''),(914,'Mordovia, Republic of',29,''),(915,'Sakha (Yakutia) Republic',29,''),(916,'North Ossetia-Alania, Republic of',29,''),(917,'Tatarstan, Republic of',29,''),(918,'Tuva Republic',29,''),(919,'Udmurt Republic',29,''),(920,'Khakassia, Republic of',29,''),(921,'Chechen Republic',29,''),(922,'Chuvash Republic',29,''),(923,'Altai Krai',29,''),(924,'Zabaykalsky Krai',29,''),(925,'Kamchatka Krai',29,''),(926,'Krasnodar Krai',29,''),(927,'Krasnoyarsk Krai',29,''),(928,'Perm Krai',29,''),(929,'Primorsky Krai',29,''),(930,'Stavropol Krai',29,''),(931,'Khabarovsk Krai',29,''),(932,'Amur Oblast',29,''),(933,'Arkhangelsk Oblast',29,''),(934,'Astrakhan Oblast',29,''),(935,'Belgorod Oblast',29,''),(936,'Bryansk Oblast',29,''),(937,'Vladimir Oblast',29,''),(938,'Volgograd Oblast',29,''),(939,'Vologda Oblast',29,''),(940,'Voronezh Oblast',29,''),(941,'Ivanovo Oblast',29,''),(942,'Irkutsk Oblast',29,''),(943,'Kaliningrad Oblast',29,''),(944,'Kaluga Oblast',29,''),(945,'Kemerovo Oblast',29,''),(946,'Kirov Oblast',29,''),(947,'Kostroma Oblast',29,''),(948,'Kurgan Oblast',29,''),(949,'Kursk Oblast',29,''),(950,'Leningrad Oblast',29,''),(951,'Lipetsk Oblast',29,''),(952,'Magadan Oblast',29,''),(953,'Moscow Oblast',29,''),(954,'Murmansk Oblast',29,''),(955,'Nizhny Novgorod Oblast',29,''),(956,'Novgorod Oblast',29,''),(957,'Novosibirsk Oblast',29,''),(958,'Omsk Oblast',29,''),(959,'Orenburg Oblast',29,''),(960,'Oryol Oblast',29,''),(961,'Penza Oblast',29,''),(962,'Pskov Oblast',29,''),(963,'Rostov Oblast',29,''),(964,'Ryazan Oblast',29,''),(965,'Samara Oblast',29,''),(966,'Saratov Oblast',29,''),(967,'Sakhalin Oblast',29,''),(968,'Sverdlovsk Oblast',29,''),(969,'Smolensk Oblast',29,''),(970,'Tambov Oblast',29,''),(971,'Tver Oblast',29,''),(972,'Tomsk Oblast',29,''),(973,'Tula Oblast',29,''),(974,'Tyumen Oblast',29,''),(975,'Ulyanovsk Oblast',29,''),(976,'Chelyabinsk Oblast',29,''),(977,'Yaroslavl Oblast',29,''),(978,'Moscow',29,''),(979,'Saint Petersburg',29,''),(980,'Jewish Autonomous Oblast',29,''),(981,'Nenets Autonomous Okrug',29,''),(982,'Khanty?Mansi Autonomous Okrug ? Yugra',29,''),(983,'Chukotka Autonomous Okrug',29,''),(984,'Yamalo-Nenets Autonomous Okrug',29,''),(985,'Crimea, Republic of[d]',29,''),(986,'Sevastopol[d]',29,''),(987,'Antwerpen',30,''),(988,'Anvers',30,''),(989,'East Flanders',30,''),(990,'Flemish Brabant',30,''),(991,'Limburg',30,''),(992,'West Flanders',30,''),(993,'Hainaut',30,''),(994,'Li?ge',30,''),(995,'Luxembourg',30,''),(996,'Namur',30,''),(997,'Walloon Brabant',30,''),(998,'Northern District',31,''),(999,'Southern District',31,''),(1000,'Central District',31,''),(1001,'Haifa District',31,''),(1002,'Jerusalem District',31,''),(1003,'Tel Aviv District',31,''),(1004,'Other',31,''),(1005,'Burgenland.',32,''),(1006,'Carinthia.',32,''),(1007,'Lower Austria.',32,''),(1008,'Upper Austria.',32,''),(1009,'Salzburg.',32,''),(1010,'Styria.',32,''),(1011,'Tyrol.',32,''),(1012,'Vorarlberg.',32,''),(1013,'Wallachia',33,''),(1014,'Moldavia',33,''),(1015,'Dobruja',33,''),(1016,'Transylvania',33,''),(1017,'Bulawayo',34,''),(1018,'Harare Province',34,''),(1019,'Manicaland',34,''),(1020,'Mashonaland Central',34,''),(1021,'Mashonaland East',34,''),(1022,'Mashonaland West',34,''),(1023,'Masvingo',34,''),(1024,'Matabeleland North',34,''),(1025,'Matabeleland South',34,''),(1026,'Midlands',34,''),(1027,'Athens',35,''),(1028,'Central Greece',35,''),(1029,'Central Macedonia',35,''),(1030,'Crete',35,''),(1031,'Eastern Macedonia and Thrace',35,''),(1032,'Epirus',35,''),(1033,'Ionian Islands',35,''),(1034,'North Aegean',35,''),(1035,'Peloponnese',35,''),(1036,'South Aegean',35,''),(1037,'Thessaly',35,''),(1038,'Western Greece',35,''),(1039,'Western Macedonia',35,''),(1040,'Kailahun',36,''),(1041,'Kenema',36,''),(1042,'Kono',36,''),(1043,'Bombali',36,''),(1044,'Kambia',36,''),(1045,'Koinadugu',36,''),(1046,'Port Loko',36,''),(1047,'Tonkolili',36,''),(1048,'Bo',36,''),(1049,'Bonthe',36,''),(1050,'Moyamba',36,''),(1051,'Pujehun',36,''),(1052,'Western Rural',36,''),(1053,'Western Urban',36,''),(1054,'Chihuahua',37,''),(1055,'Sonora',37,''),(1056,'Coahuila',37,''),(1057,'Durango',37,''),(1058,'Oaxaca',37,''),(1059,'Tamaulipas',37,''),(1060,'Jalisco',37,''),(1061,'Zacatecas',37,''),(1062,'Baja California Sur',37,''),(1063,'Chiapas',37,''),(1064,'Veracruz',37,''),(1065,'Baja California',37,''),(1066,'Nuevo Le?n',37,''),(1067,'Guerrero',37,''),(1068,'San Luis Potos?',37,''),(1069,'Michoac?n',37,''),(1070,'Campeche',37,''),(1071,'Sinaloa',37,''),(1072,'Quintana Roo',37,''),(1073,'Yucat?n',37,''),(1074,'Puebla',37,''),(1075,'Guanajuato',37,''),(1076,'Nayarit',37,''),(1077,'Tabasco',37,''),(1078,'M?xico',37,''),(1079,'Hidalgo',37,''),(1080,'Quer?taro',37,''),(1081,'Colima',37,''),(1082,'Aguascalientes',37,''),(1083,'Morelos',37,''),(1084,'Tlaxcala',37,''),(1085,'Mexico City',37,''),(1086,'Capital Region of Denmark',38,''),(1087,'Central Denmark Region',38,''),(1088,'North Denmark Region',38,''),(1089,'Region Zealand',38,''),(1090,'Region of Southern Denmark',38,''),(1091,'Z?rich',39,''),(1092,'Bern',39,''),(1093,'Luzern',39,''),(1094,'Uri',39,''),(1095,'Schwyz',39,''),(1096,'Obwalden',39,''),(1097,'Nidwalden',39,''),(1098,'Glarus',39,''),(1099,'Zug',39,''),(1100,'Fribourg',39,''),(1101,'Solothurn',39,''),(1102,'Basel-Stadt',39,''),(1103,'Basel-Landschaft',39,''),(1104,'Schaffhausen',39,''),(1105,'Appenzell Ausserrhoden',39,''),(1106,'Appenzell Innerrhoden',39,''),(1107,'St. Gallen',39,''),(1108,'Graub?nden',39,''),(1109,'Aargau',39,''),(1110,'Thurgau',39,''),(1111,'Ticino',39,''),(1112,'Vaud',39,''),(1113,'Valais',39,''),(1114,'Neuch?tel',39,''),(1115,'Geneva',39,''),(1116,'Jura',39,''),(1117,'Tanger-Tetouan-Al Hoceima',40,''),(1118,'Oriental',40,''),(1119,'F?s-Mekn?s',40,''),(1120,'Rabat-Sal?-K?nitra',40,''),(1121,'B?ni Mellal-Kh?nifra',40,''),(1122,'Casablanca-Settat',40,''),(1123,'Marrakesh-Safi',40,''),(1124,'Dr?a-Tafilalet',40,''),(1125,'Souss-Massa',40,''),(1126,'Guelmim-Oued Noun[A]',40,''),(1127,'La?youne-Sakia El Hamra[A]',40,''),(1128,'Dakhla-Oued Ed-Dahab[A]',40,''),(1129,'Northern Norway (Nord-Norge/Nord-Noreg)',41,''),(1130,'Tr?ndelag (alt. Midt-Norge/Midt-Noreg) ...',41,''),(1131,'Western Norway (Vestlandet)',41,''),(1132,'Southern Norway (S?rlandet or Agder)',41,''),(1133,'Eastern Norway (?stlandet/Austlandet)',41,''),(1134,'Leinster',42,''),(1135,'Ulster',42,''),(1136,'Munster',42,''),(1137,'Connacht',42,''),(1138,'Central Singapore Community Development Council',43,''),(1139,'North East Community Development Council',43,''),(1140,'North West Community Development Council',43,''),(1141,'South East Community Development Council',43,''),(1142,'South West Community Development Council',43,''),(1143,'Ashanti',44,''),(1144,'Brong-Ahafo',44,''),(1145,'Greater Accra',44,''),(1146,'Central',44,''),(1147,'Eastern',44,''),(1148,'Northern',44,''),(1149,'Western',44,''),(1150,'Upper East',44,''),(1151,'Upper West',44,''),(1152,'Volta',44,''),(1153,'Arusha',45,''),(1154,'Dar es Salaam',45,''),(1155,'Dodoma',45,''),(1156,'Geita',45,''),(1157,'Iringa',45,''),(1158,'Kagera',45,''),(1159,'Katavi',45,''),(1160,'Kigoma',45,''),(1161,'Kilimanjaro',45,''),(1162,'Lindi',45,''),(1163,'Manyara',45,''),(1164,'Mara',45,''),(1165,'Mbeya',45,''),(1166,'Morogoro',45,''),(1167,'Mtwara',45,''),(1168,'Mwanza',45,''),(1169,'Njombe',45,''),(1170,'Pemba North',45,''),(1171,'Pemba South',45,''),(1172,'Pwani',45,''),(1173,'Rukwa',45,''),(1174,'Ruvuma',45,''),(1175,'Shinyanga',45,''),(1176,'Simiyu',45,''),(1177,'Singida',45,''),(1178,'Tabora',45,''),(1179,'Tanga',45,''),(1180,'Zanzibar North',45,''),(1181,'Zanzibar South and Central',45,''),(1182,'Zanzibar West',45,''),(1183,'Auckland',46,''),(1184,'New Plymouth [* 1]',46,''),(1185,'Hawke\'s Bay',46,''),(1186,'Wellington',46,''),(1187,'Nelson',46,''),(1188,'Marlborough',46,''),(1189,'Westland',46,''),(1190,'Canterbury',46,''),(1191,'Otago',46,''),(1192,'Southland',46,''),(1193,'Province of Turku and Pori',47,''),(1194,'Province of Nyland and Tavastehus',47,''),(1195,'Province of Ostrobothnia',47,''),(1196,'Province of Viborg and Nyslott',47,''),(1197,'Province of Kexholm',47,''),(1198,'Province of Kymmeneg?rd and Nyslott',47,''),(1199,'Province of Savolax and Kymmeneg?rd',47,''),(1200,'Province of Vaasa',47,''),(1201,'Province of Oulu',47,''),(1202,'Province of Kymmeneg?rd',47,''),(1203,'Province of Savolax and Karelia',47,''),(1204,'Province of Viipuri',47,''),(1205,'Province of Uusimaa',47,''),(1206,'Province of H?me',47,''),(1207,'Province of Mikkeli',47,''),(1208,'Province of Kuopio',47,''),(1209,'Province of ?land',47,''),(1210,'Province of Petsamo',47,''),(1211,'Province of Lapland',47,''),(1212,'Province of Kymi',47,''),(1213,'Province of Central Finland',47,''),(1214,'Province of Northern Karelia',47,''),(1215,'Province of Southern Finland',47,''),(1216,'Province of Western Finland',47,''),(1217,'Province of Eastern Finland',47,''),(1218,'Alentejo.',48,''),(1219,'Algarve.',48,''),(1220,'Beira.',48,''),(1221,'Entre Douro e Minho.',48,''),(1222,'Estremadura.',48,''),(1223,'Tr?s-os-Montes',48,''),(1224,'Papua Region',49,''),(1225,'Highlands Region',49,''),(1226,'Islands Region',49,''),(1227,'Momase Region',49,''),(1228,'Papua Region',49,''),(1229,'Momase Region',49,''),(1230,'Islands Region',49,''),(1231,'Papua Region',49,''),(1232,'Islands Region',49,''),(1233,'Highlands Region',49,''),(1234,'Grand Bassa County',50,''),(1235,'Nimba County',50,''),(1236,'Bong County',50,''),(1237,'Lofa County',50,''),(1238,'Grand Cape Mount County',50,''),(1239,'Margibi County',50,''),(1240,'Bomi County',50,''),(1241,'Sinoe County',50,''),(1242,'Montserrado County',50,''),(1243,'Maryland County',50,''),(1244,'Grand Gedeh County',50,''),(1245,'Gbarpolu County',50,''),(1246,'River Gee County',50,''),(1247,'River Cess County',50,''),(1248,'Grand Kru County',50,''),(1249,'Other',50,''),(1250,'Irbid',51,''),(1251,'Ajloun',51,''),(1252,'Jerash',51,''),(1253,'Mafraq',51,''),(1254,'Balqa',51,''),(1255,'Amman',51,''),(1256,'Zarqa',51,''),(1257,'Madaba',51,''),(1258,'Karak',51,''),(1259,'Tafilah',51,''),(1260,'Ma\'an',51,''),(1261,'Aqaba',51,''),(1262,'Hanover',52,''),(1263,'Saint Elizabeth',52,''),(1264,'Saint James',52,''),(1265,'Trelawny',52,''),(1266,'Westmoreland',52,''),(1267,'Clarendon',52,''),(1268,'Manchester',52,''),(1269,'Saint Ann',52,''),(1270,'Saint Catherine',52,''),(1271,'Saint Mary',52,''),(1272,'Kingston Parish(1) (2)',52,''),(1273,'Portland',52,''),(1274,'Saint Andrew(1)',52,''),(1275,'Saint Thomas',52,''),(1276,'Adrar',53,''),(1277,'Chlef',53,''),(1278,'Laghouat',53,''),(1279,'Oum el-Bouaghi',53,''),(1280,'Batna',53,''),(1281,'B?ja?a',53,''),(1282,'Biskra',53,''),(1283,'B?char',53,''),(1284,'Blida',53,''),(1285,'Bou?ra',53,''),(1286,'Tamanghasset',53,''),(1287,'T?bessa',53,''),(1288,'Tlemcen',53,''),(1289,'Tiaret',53,''),(1290,'Tizi Ouzou',53,''),(1291,'Algiers',53,''),(1292,'Djelfa',53,''),(1293,'Jijel',53,''),(1294,'S?tif',53,''),(1295,'Sa?da',53,''),(1296,'Skikda',53,''),(1297,'Sidi Bel Abb?s',53,''),(1298,'Annaba',53,''),(1299,'Guelma',53,''),(1300,'Constantine',53,''),(1301,'M?d?a',53,''),(1302,'Mostaganem',53,''),(1303,'M\'Sila',53,''),(1304,'Mascara',53,''),(1305,'Ouargla',53,''),(1306,'Oran',53,''),(1307,'El Bayadh',53,''),(1308,'Illizi',53,''),(1309,'Bordj Bou Arr?ridj',53,''),(1310,'Boumerd?s',53,''),(1311,'El Taref',53,''),(1312,'Tindouf',53,''),(1313,'Tissemsilt',53,''),(1314,'El Oued',53,''),(1315,'Khenchela',53,''),(1316,'Souk Ahras',53,''),(1317,'Tipasa',53,''),(1318,'Mila',53,''),(1319,'A?n Defla',53,''),(1320,'Na?ma',53,''),(1321,'A?n T?mouchent',53,''),(1322,'Gharda?a',53,''),(1323,'Relizane',53,''),(1324,'Central',54,''),(1325,'Western',54,''),(1326,'Eastern',54,''),(1327,'Northern',54,''),(1328,'Central and Western',55,''),(1329,'Eastern',55,''),(1330,'Islands',55,''),(1331,'Kowloon City',55,''),(1332,'Kwai Tsing',55,''),(1333,'Kwun Tong',55,''),(1334,'North',55,''),(1335,'Sai Kung',55,''),(1336,'Sham Shui Po',55,''),(1337,'Sha Tin',55,''),(1338,'Southern',55,''),(1339,'Tai Po',55,''),(1340,'Tsuen Wan',55,''),(1341,'Tuen Mun',55,''),(1342,'Wan Chai',55,''),(1343,'Wong Tai Sin',55,''),(1344,'Yau Tsim Mong',55,''),(1345,'Yuen Long',55,''),(1346,'Prague',56,''),(1347,'Central Bohemia',56,''),(1348,'South Bohemia',56,''),(1349,'Plze?',56,''),(1350,'Karlovy Vary',56,''),(1351,'?st? nad Labem',56,''),(1352,'Liberec',56,''),(1353,'Hradec Kr?lov?',56,''),(1354,'Pardubice',56,''),(1355,'Olomouc',56,''),(1356,'Moravia-Silesia',56,''),(1357,'South Moravia',56,''),(1358,'Zl?n',56,''),(1359,'Highlands',56,''),(1360,'Ciudad de Buenos Aires (Distrito Federal)',57,''),(1361,'Buenos Aires',57,''),(1362,'Catamarca',57,''),(1363,'Chaco',57,''),(1364,'Chubut',57,''),(1365,'C?rdoba',57,''),(1366,'Corrientes',57,''),(1367,'Entre R?os',57,''),(1368,'Formosa',57,''),(1369,'Jujuy',57,''),(1370,'La Pampa',57,''),(1371,'La Rioja',57,''),(1372,'Mendoza',57,''),(1373,'Misiones',57,''),(1374,'Neuqu?n',57,''),(1375,'R?o Negro',57,''),(1376,'Salta',57,''),(1377,'San Juan',57,''),(1378,'San Luis',57,''),(1379,'Santa Cruz',57,''),(1380,'Santa Fe',57,''),(1381,'Santiago del Estero',57,''),(1382,'Tierra del Fuego',57,''),(1383,'Tucum?n',57,''),(1384,'Amran',58,''),(1385,'Al Bayda',58,''),(1386,'Al Hudaydah',58,''),(1387,'Al Jawf',58,''),(1388,'Al Mahwit',58,''),(1389,'Amanat Al Asimah',58,''),(1390,'Dhamar',58,''),(1391,'Hajjah',58,''),(1392,'Ibb',58,''),(1393,'Ma\'rib',58,''),(1394,'Raymah',58,''),(1395,'Sa\'dah',58,''),(1396,'Sana\'a',58,''),(1397,'Taiz',58,''),(1398,'Former South Yemen',58,''),(1399,'Aden',58,''),(1400,'Abyan',58,''),(1401,'Dhale',58,''),(1402,'Al Mahrah',58,''),(1403,'Hadramaut',58,''),(1404,'Socotra',58,''),(1405,'Lahij',58,''),(1406,'Shabwah',58,''),(1407,'Croatia.',59,''),(1408,'Dalmatia.',59,''),(1409,'Sclavonia (Slavonia)',59,''),(1410,'Istria.',59,''),(1411,'Ragusina Respublica (Dubrovnik Republic)',59,''),(1412,'AntioquiaAntioquia',60,''),(1413,'Bol?var',60,''),(1414,'Boyac?',60,''),(1415,'Caldas',60,''),(1416,'Cauca',60,''),(1417,'Cundinamarca',60,''),(1418,'Huila',60,''),(1419,'La Guajira',60,''),(1420,'Meta',60,''),(1421,'Nari?o',60,''),(1422,'Norte de Santander',60,''),(1423,'Santander',60,''),(1424,'Sucre',60,''),(1425,'Tolima',60,''),(1426,'Valle del Cauca',60,''),(1427,'Northern Hungary',61,''),(1428,'Northern Great Plain',61,''),(1429,'Southern Great Plain',61,''),(1430,'Central Hungary',61,''),(1431,'Central Transdanubia',61,''),(1432,'Western Transdanubia',61,''),(1433,'Southern Transdanubia',61,''),(1434,'Aguadilla',62,''),(1435,'Arecibo',62,''),(1436,'Bayam?n',62,''),(1437,'Guayama',62,''),(1438,'Humacao',62,''),(1439,'Mayag?ez',62,''),(1440,'Ponce',62,''),(1441,'San Juan',62,''),(1442,'Central',63,''),(1443,'Copperbelt',63,''),(1444,'Eastern',63,''),(1445,'Luapula',63,''),(1446,'Lusaka',63,''),(1447,'Muchinga',63,''),(1448,'North-Western',63,''),(1449,'Northern',63,''),(1450,'Southern',63,''),(1451,'Western',63,''),(1452,'Zambia',63,''),(1453,'Blagoevgrad',64,''),(1454,'Burgas',64,''),(1455,'Dobrich',64,''),(1456,'Gabrovo',64,''),(1457,'Haskovo',64,''),(1458,'Kardzhali',64,''),(1459,'Kyustendil',64,''),(1460,'Lovech',64,''),(1461,'Montana',64,''),(1462,'Pazardzhik',64,''),(1463,'Pernik',64,''),(1464,'Pleven',64,''),(1465,'Plovdiv',64,''),(1466,'Razgrad',64,''),(1467,'Ruse',64,''),(1468,'Shumen',64,''),(1469,'Silistra',64,''),(1470,'Sliven',64,''),(1471,'Smolyan',64,''),(1472,'Sofia City',64,''),(1473,'Sofia (province)',64,''),(1474,'Stara Zagora',64,''),(1475,'Targovishte',64,''),(1476,'Varna',64,''),(1477,'Veliko Tarnovo',64,''),(1478,'Vidin',64,''),(1479,'Vratsa',64,''),(1480,'Yambol',64,''),(1481,'Akmola Region',65,''),(1482,'Aktobe Region',65,''),(1483,'Almaty',65,''),(1484,'Almaty Region',65,''),(1485,'Astana',65,''),(1486,'Atyrau Region',65,''),(1487,'Baikonur',65,''),(1488,'East Kazakhstan Region',65,''),(1489,'Jambyl Region',65,''),(1490,'Karaganda Region',65,''),(1491,'Kostanay Region',65,''),(1492,'Kyzylorda Region',65,''),(1493,'Mangystau Region',65,''),(1494,'North Kazakhstan Region',65,''),(1495,'Pavlodar Region',65,''),(1496,'South Kazakhstan Region',65,''),(1497,'West Kazakhstan Region',65,''),(1498,'Aakkar',66,''),(1499,'An Naba??yah',66,''),(1500,'Baalbek-Hermel',66,''),(1501,'Beirut',66,''),(1502,'Beqaa',66,''),(1503,'Mount Lebanon',66,''),(1504,'North Lebanon',66,''),(1505,'South Lebanon',66,''),(1506,'Arica',67,''),(1507,'Parinacota',67,''),(1508,'Iquique',67,''),(1509,'Tamarugal',67,''),(1510,'Antofagasta',67,''),(1511,'El Loa',67,''),(1512,'Tocopilla',67,''),(1513,'Copiap?',67,''),(1514,'Huasco',67,''),(1515,'Cha?aral',67,''),(1516,'Elqui',67,''),(1517,'Limar?',67,''),(1518,'Choapa',67,''),(1519,'Isla de Pascua',67,''),(1520,'Los Andes',67,''),(1521,'Marga Marga',67,''),(1522,'Petorca',67,''),(1523,'Quillota',67,''),(1524,'San Antonio',67,''),(1525,'San Felipe de Aconcagua',67,''),(1526,'Valpara?so',67,''),(1527,'Cachapoal',67,''),(1528,'Colchagua',67,''),(1529,'Cardenal Caro',67,''),(1530,'Talca',67,''),(1531,'Linares',67,''),(1532,'Curic?',67,''),(1533,'Cauquenes',67,''),(1534,'Concepci?n',67,''),(1535,'?uble',67,''),(1536,'Biob?o',67,''),(1537,'Arauco',67,''),(1538,'Cautin',67,''),(1539,'Malleco',67,''),(1540,'Valdivia',67,''),(1541,'Ranco',67,''),(1542,'Kigali',68,''),(1543,'Southern',68,''),(1544,'Western',68,''),(1545,'Northern',68,''),(1546,'Eastern',68,''),(1547,'Bratislava',69,''),(1548,'Trnava',69,''),(1549,'Tren??n',69,''),(1550,'Nitra',69,''),(1551,'?ilina',69,''),(1552,'Bansk? Bystrica',69,''),(1553,'Pre?ov',69,''),(1554,'Ko?ice',69,''),(1555,'County of Saint George',70,''),(1556,'Tobago',70,''),(1557,'County of Saint Patrick',70,''),(1558,'County of Victoria',70,''),(1559,'County of Saint Andrew',70,''),(1560,'County of Caroni',70,''),(1561,'County of Saint David',70,''),(1562,'Other',70,''),(1563,'Mayaro',70,''),(1564,'County of Nariva',70,''),(1565,'Port of Spain',70,''),(1566,'San Fernando',70,''),(1567,'Arima',70,''),(1568,'Mura',71,''),(1569,'Drava',71,''),(1570,'Carinthia',71,''),(1571,'Savinja',71,''),(1572,'Central Sava',71,''),(1573,'Lower Sava',71,''),(1574,'Southeast Slovenia',71,''),(1575,'Littoral?Inner Carniola',71,''),(1576,'Central Slovenia',71,''),(1577,'Upper Carniola',71,''),(1578,'Gorizia',71,''),(1579,'Coastal?Karst',71,''),(1580,'Brest Litovsk Voivodeship',72,''),(1581,'Minsk Voivodeship',72,''),(1582,'Mstsislaw Voivodeship',72,''),(1583,'Nowogr?dek Voivodeship',72,''),(1584,'Polotsk Voivodeship',72,''),(1585,'Samogitian Eldership',72,''),(1586,'Trakai Voivodeship',72,''),(1587,'Vilnius Voivodeship',72,''),(1588,'Vitebsk Voivodeship',72,''),(1589,'Jurmala',73,''),(1590,'Other',73,''),(1591,'Ventspils Rajons',73,''),(1592,'Talsu Rajons',73,''),(1593,'Cesu Rajons',73,''),(1594,'Kuldigas Rajons',73,''),(1595,'Saldus Rajons',73,''),(1596,'Liepajas Rajons',73,''),(1597,'Ludzas Rajons',73,''),(1598,'Madonas Rajons',73,''),(1599,'Rigas Rajons',73,''),(1600,'Jekabpils Rajons',73,''),(1601,'Balvu Rajons',73,''),(1602,'Rezeknes Rajons',73,''),(1603,'Kraslavas Rajons',73,''),(1604,'Limbazu Rajons',73,''),(1605,'Daugavpils Rajons',73,''),(1606,'Tukuma Rajons',73,''),(1607,'Preilu Rajons',73,''),(1608,'Valkas Rajons',73,''),(1609,'Valmieras Rajons',73,''),(1610,'Aizkraukles Rajons',73,''),(1611,'Aluksnes Rajons',73,''),(1612,'Gulbenes Rajons',73,''),(1613,'Ogres Rajons',73,''),(1614,'Bauskas Rajons',73,''),(1615,'Riga',73,''),(1616,'Ventspils',73,''),(1617,'Liepaja',73,''),(1618,'Rezekne',73,''),(1619,'Daugavpils',73,''),(1620,'Barima-Waini',74,''),(1621,'Pomeroon-Supenaam',74,''),(1622,'Essequibo Islands-West Demerara',74,''),(1623,'Demerara-Mahaica',74,''),(1624,'Mahaica-Berbice',74,''),(1625,'East Berbice-Corentyne',74,''),(1626,'Cuyuni-Mazaruni',74,''),(1627,'Potaro-Siparuni',74,''),(1628,'Upper Takutu-Upper Essequibo',74,''),(1629,'Upper Demerara-Berbice',74,''),(1630,'Gaborone',75,''),(1631,'Francistown',75,''),(1632,'Lobatse',75,''),(1633,'Selebi-Phikwe',75,''),(1634,'Jwaneng',75,''),(1635,'Orapa',75,''),(1636,'Sowa',75,''),(1637,'Southern District',75,''),(1638,'South-East District',75,''),(1639,'Kweneng District',75,''),(1640,'Kgatleng District',75,''),(1641,'Central District',75,''),(1642,'North-East District',75,''),(1643,'North-West District',75,''),(1644,'Ghanzi District',75,''),(1645,'Kgalagadi District',75,''),(1646,'Harju County',76,''),(1647,'Hiiu County',76,''),(1648,'Ida-Viru County',76,''),(1649,'J?geva County',76,''),(1650,'J?rva County',76,''),(1651,'L??ne County',76,''),(1652,'L??ne-Viru County',76,''),(1653,'P?lva County',76,''),(1654,'P?rnu County',76,''),(1655,'Rapla County',76,''),(1656,'Saare County',76,''),(1657,'Tartu County',76,''),(1658,'Valga County',76,''),(1659,'Viljandi County',76,''),(1660,'V?ru County',76,''),(1661,'Famagusta',77,''),(1662,'Kyrenia',77,''),(1663,'Larnaca',77,''),(1664,'Limassol',77,''),(1665,'Nicosia',77,''),(1666,'Paphos',77,''),(1667,'Dedza',78,''),(1668,'Dowa',78,''),(1669,'Kasungu',78,''),(1670,'Lilongwe',78,''),(1671,'Mchinji',78,''),(1672,'Nkhotakota',78,''),(1673,'Ntcheu',78,''),(1674,'Ntchisi',78,''),(1675,'Salima',78,''),(1676,'Chitipa',78,''),(1677,'Karonga',78,''),(1678,'Likoma',78,''),(1679,'Mzimba',78,''),(1680,'Nkhata Bay',78,''),(1681,'Rumphi',78,''),(1682,'Balaka',78,''),(1683,'Blantyre',78,''),(1684,'Chikwawa',78,''),(1685,'Chiradzulu',78,''),(1686,'Machinga',78,''),(1687,'Mangochi',78,''),(1688,'Mulanje',78,''),(1689,'Mwanza',78,''),(1690,'Nsanje',78,''),(1691,'Thyolo',78,''),(1692,'Phalombe',78,''),(1693,'Zomba',78,''),(1694,'Neno',78,''),(1695,'Berea',79,''),(1696,'Butha-Buthe',79,''),(1697,'Leribe',79,''),(1698,'Mafeteng',79,''),(1699,'Maseru',79,''),(1700,'Mohale\'s Hoek',79,''),(1701,'Mokhotlong',79,''),(1702,'Qacha\'s Nek',79,''),(1703,'Quthing',79,''),(1704,'Thaba-Tseka',79,''),(1705,'Brokopondo',80,''),(1706,'Commewijne',80,''),(1707,'Coronie',80,''),(1708,'Marowijne',80,''),(1709,'Nickerie',80,''),(1710,'Para',80,''),(1711,'Paramaribo',80,''),(1712,'Saramacca',80,''),(1713,'Sipaliwini',80,''),(1714,'Wanica',80,''),(1715,'Central Region',81,''),(1716,'Gozo Region',81,''),(1717,'Northern Region',81,''),(1718,'South Eastern Region',81,''),(1719,'Southern Region',81,''),(1720,'Zambezi Region',82,''),(1721,'Erongo Region',82,''),(1722,'Hardap Region',82,''),(1723,'?Karas Region',82,''),(1724,'Kavango East Region',82,''),(1725,'Kavango West Region',82,''),(1726,'Khomas Region',82,''),(1727,'Kunene Region',82,''),(1728,'Ohangwena Region',82,''),(1729,'Omaheke Region',82,''),(1730,'Omusati Region',82,''),(1731,'Oshana Region',82,''),(1732,'Oshikoto Region',82,''),(1733,'Otjozondjupa Region',82,''),(1734,'Arlon',83,''),(1735,'Attert',83,''),(1736,'Aubange',83,''),(1737,'Bastogne',83,''),(1738,'Bertogne',83,''),(1739,'Bertrix',83,''),(1740,'Bouillon',83,''),(1741,'Chiny',83,''),(1742,'Daverdisse',83,''),(1743,'Durbuy',83,''),(1744,'?rez?e',83,''),(1745,'?talle',83,''),(1746,'Fauvillers',83,''),(1747,'Florenville',83,''),(1748,'Gouvy',83,''),(1749,'Habay',83,''),(1750,'Herbeumont',83,''),(1751,'Hotton',83,''),(1752,'Houffalize',83,''),(1753,'La Roche-en-Ardenne',83,''),(1754,'L?glise',83,''),(1755,'Libin',83,''),(1756,'Libramont-Chevigny',83,''),(1757,'Manhay',83,''),(1758,'Marche-en-Famenne',83,''),(1759,'Martelange',83,''),(1760,'Meix-devant-Virton',83,''),(1761,'Messancy',83,''),(1762,'Musson',83,''),(1763,'Nassogne',83,''),(1764,'Neufch?teau',83,''),(1765,'Paliseul',83,''),(1766,'Rendeux',83,''),(1767,'Rouvroy',83,''),(1768,'Sainte-Ode',83,''),(1769,'Saint-Hubert',83,''),(1770,'Saint-L?ger',83,''),(1771,'Tellin',83,''),(1772,'Tenneville',83,''),(1773,'Tintigny',83,''),(1774,'Vaux-sur-S?re',83,''),(1775,'Vielsalm',83,''),(1776,'Virton',83,''),(1777,'Wellin',83,''),(1778,'Exuma District',84,''),(1779,'New Providence District',84,''),(1780,'Kemps Bay District',84,''),(1781,'Marsh Harbour District',84,''),(1782,'Acklins Island District',84,''),(1783,'Nichollstown and Berry Islands District',84,''),(1784,'Long Island District',84,''),(1785,'Green Turtle Cay District',84,''),(1786,'Ragged Island District',84,''),(1787,'Cat Island District',84,''),(1788,'City of Freeport District',84,''),(1789,'Bimini District',84,''),(1790,'San Salvador and Rum Cay District',84,''),(1791,'Fresh Creek District',84,''),(1792,'High Rock District',84,''),(1793,'Inagua District',84,''),(1794,'Governors Harbour District',84,''),(1795,'Harbour Island District',84,''),(1796,'Mayaguana District',84,''),(1797,'Rock Sound District',84,''),(1798,'Other',84,''),(1799,'Sandy Point District',84,''),(1800,'Christ Church',85,''),(1801,'Saint Andrew',85,''),(1802,'Saint George',85,''),(1803,'Saint James',85,''),(1804,'Saint John',85,''),(1805,'Saint Joseph',85,''),(1806,'Saint Lucy',85,''),(1807,'Saint Michael',85,''),(1808,'Saint Peter',85,''),(1809,'Saint Philip',85,''),(1810,'Saint Thomas',85,''),(1811,'Belize',86,''),(1812,'Cayo',86,''),(1813,'Corozal',86,''),(1814,'Orange Walk',86,''),(1815,'Stann Creek',86,''),(1816,'Toledo',86,''),(1817,'Antananarivo',87,''),(1818,'Antsiranana',87,''),(1819,'Fianarantsoa',87,''),(1820,'Mahajanga',87,''),(1821,'Toamasina',87,''),(1822,'Toliara',87,''),(1823,'Black River',88,''),(1824,'Flacq',88,''),(1825,'Grand Port',88,''),(1826,'Moka',88,''),(1827,'Pamplemousses',88,''),(1828,'Plaines Wilhems',88,''),(1829,'Port Louis (Capital of Mauritius)',88,''),(1830,'Rivi?re du Rempart',88,''),(1831,'Savanne',88,''),(1832,'Malampa',89,''),(1833,'Penama',89,''),(1834,'Sanma',89,''),(1835,'Shefa',89,''),(1836,'Tafea',89,''),(1837,'Torba',89,''),(1838,'Ba Province',90,''),(1839,'Bua Province',90,''),(1840,'Cakaudrove Province',90,''),(1841,'Kadavu Province',90,''),(1842,'Lau Province',90,''),(1843,'Lomaiviti Province',90,''),(1844,'Macuata Province',90,''),(1845,'Nadroga-Navosa Province',90,''),(1846,'Naitasiri Province',90,''),(1847,'Namosi Province',90,''),(1848,'Ra Province',90,''),(1849,'Rewa Province',90,''),(1850,'Serua Province',90,''),(1851,'Central Province',91,''),(1852,'Choiseul Province',91,''),(1853,'Guadalcanal Province[1]',91,''),(1854,'Isabel Province',91,''),(1855,'Makira-Ulawa Province',91,''),(1856,'Malaita Province',91,''),(1857,'Rennell and Bellona Province',91,''),(1858,'Temotu Province',91,''),(1859,'Western Province',91,''),(1860,'Capital Territory',91,''),(1861,'Other',92,''),(1862,'Belait',93,''),(1863,'Brunei-Muara',93,''),(1864,'Temburong',93,''),(1865,'Tutong',93,''),(1866,'Grenadines',94,''),(1867,'Saint George',94,''),(1868,'Charlotte',94,''),(1869,'Other',94,''),(1870,'Saint Andrew',94,''),(1871,'Saint David',94,''),(1872,'Saint Patrick',94,''),(1873,'St. Croix',95,''),(1874,'St. John',95,''),(1875,'St. Thomas',95,''),(1876,'Saint George',96,''),(1877,'Saint Andrew',96,''),(1878,'Saint Patrick',96,''),(1879,'Saint David',96,''),(1880,'Other',96,''),(1881,'Saint John',96,''),(1882,'Saint Mark',96,''),(1883,'Other',97,''),(1884,'other',98,''),(1885,'Other',99,''),(1886,'Paro Dzongkhag',99,''),(1887,'Bumthang Dzongkhag',99,''),(1888,'Lhuentse Dzongkhag',99,''),(1889,'Sarpang Dzongkhag',99,''),(1890,'Trashigang Dzongkhag',99,''),(1891,'Wangdue Phodrang Dzongkhag',99,''),(1892,'Chhukha Dzongkhag',99,''),(1893,'Haa Dzongkhag',99,''),(1894,'Samdrup Jongkhar Dzongkhag',99,''),(1895,'Mongar Dzongkhag',99,''),(1896,'Samtse Dzongkhag',99,''),(1897,'Thimphu Dzongkhag',99,''),(1898,'Tsirang Dzongkhag',99,''),(1899,'Zhemgang Dzongkhag',99,''),(1900,'Dagana Dzongkhag',99,''),(1901,'Trongsa Dzongkhag',99,''),(1902,'Castries',100,''),(1903,'Gros Islet',100,''),(1904,'Vieux Fort',100,''),(1905,'Soufriere',100,''),(1906,'Micoud',100,''),(1907,'Dennery',100,''),(1908,'Dauphin',100,''),(1909,'Anse la Raye',100,''),(1910,'Praslin',100,''),(1911,'Laborie',100,''),(1912,'Other',100,''),(1913,'Choiseul',100,''),(1914,'Other',101,''),(1915,'Saint John',102,''),(1916,'Saint Mary',102,''),(1917,'Saint Philip',102,''),(1918,'Saint Paul',102,''),(1919,'Barbuda',102,''),(1920,'Saint Peter',102,''),(1921,'Saint George',102,''),(1922,'Other',102,''),(1923,'Other',103,''),(1924,'State of Pohnpei',104,''),(1925,'Yap',104,''),(1926,'Chuuk',104,''),(1927,'Pohnpei',104,''),(1928,'Kosrae',104,''),(1929,'Saint George Parish',105,''),(1930,'Sandys Parish',105,''),(1931,'Southampton Parish',105,''),(1932,'Warwick Parish',105,''),(1933,'Pembroke Parish',105,''),(1934,'Hamilton Parish',105,''),(1935,'Smiths Parish',105,''),(1936,'Paget Parish',105,''),(1937,'Devonshire Parish',105,''),(1938,'Saint George',105,''),(1939,'Other',105,''),(1940,'Hamilton',105,''),(1941,'Saint Andrew',106,''),(1942,'Saint David',106,''),(1943,'Saint Patrick',106,''),(1944,'Saint John',106,''),(1945,'Saint George',106,''),(1946,'Saint Joseph',106,''),(1947,'Saint Paul',106,''),(1948,'Saint Peter',106,''),(1949,'Other',106,''),(1950,'Saint Mark',106,''),(1951,'Saint Luke',106,''),(1952,'Ailinglaplap Atoll',107,''),(1953,'Ailuk Atoll',107,''),(1954,'Arno Atoll',107,''),(1955,'Aur Atoll',107,''),(1956,'Ebon Atoll',107,''),(1957,'Enewetok/Ujelang',107,''),(1958,'Jabat Island',107,''),(1959,'Jaluit Atoll',107,''),(1960,'Kili/Bikini/Ejit',107,''),(1961,'Kwajalein Atoll',107,''),(1962,'Lae Atoll',107,''),(1963,'Lib Island',107,''),(1964,'Likiep Atoll',107,''),(1965,'Majuro Atoll (capital)',107,''),(1966,'Maloelap Atoll',107,''),(1967,'Mejit Island',107,''),(1968,'Mili Atoll',107,''),(1969,'Namorik Atoll',107,''),(1970,'Namu Atoll',107,''),(1971,'Rongelap Atoll',107,''),(1972,'Ujae Atoll',107,''),(1973,'Utirik Atoll',107,''),(1974,'Wotho Atoll',107,''),(1975,'Wotje Atoll',107,''),(1976,'Hhohho',108,''),(1977,'Lubombo',108,''),(1978,'Manzini',108,''),(1979,'Shiselweni',108,''),(1980,'Aruba (general)',109,''),(1981,'Other',110,''),(1982,'Western Division',110,''),(1983,'North Bank Division',110,''),(1984,'Lower River Division',110,''),(1985,'City of Banjul',110,''),(1986,'Central River Division',110,''),(1987,'Upper River Division',110,''),(1988,'Other',111,''),(1989,'Saint George Basseterre',111,''),(1990,'Saint James Windward',111,''),(1991,'Saint George Gingerland',111,''),(1992,'Saint John Capesterre',111,''),(1993,'Saint John Figtree',111,''),(1994,'Saint Peter Basseterre',111,''),(1995,'Saint Thomas Middle Island',111,''),(1996,'Saint Thomas Lowland',111,''),(1997,'Saint Paul Capesterre',111,''),(1998,'Christ Church Nichola Town',111,''),(1999,'Saint Mary Cayon',111,''),(2000,'Trinity Palmetto Point',111,''),(2001,'Saint Anne Sandy Point',111,''),(2002,'Saint Paul Charlestown',111,''),(2003,'Other',112,''),(2004,'Other',113,''),(2005,'Anse aux Pins',113,''),(2006,'Beau Vallon',113,''),(2007,'Bel Ombre',113,''),(2008,'Anse Boileau',113,''),(2009,'Anse Etoile',113,''),(2010,'Anse Royale',113,''),(2011,'Au Cap',113,''),(2012,'Baie Lazare',113,''),(2013,'Baie Sainte Anne',113,''),(2014,'Bel Air',113,''),(2015,'Cascade',113,''),(2016,'Grand Anse Mahe',113,''),(2017,'Grand Anse Praslin',113,''),(2018,'Les Mamelles',113,''),(2019,'Mont Buxton',113,''),(2020,'Mont Fleuri',113,''),(2021,'Plaisance',113,''),(2022,'Pointe Larue',113,''),(2023,'Roche Caiman',113,''),(2024,'Saint Louis',113,''),(2025,'Takamaka',113,''),(2026,'Other',114,''),(2027,'Other',115,''),(2028,'Gilbert Islands',116,''),(2029,'Anegada',117,''),(2030,'Jost Van Dyke',117,''),(2031,'Tortola',117,''),(2032,'Road Town',117,''),(2033,'Virgin Gorda',117,''),(2034,'other inhabitated smaller islands',117,''),(2035,'institutional & marine population',117,''),(2036,'State of Ngiwal',118,''),(2037,'Other',119,''),(2038,'Parroquia Andorra la Vella',119,''),(2039,'Parroquia de Sant Julia de Loria',119,''),(2040,'Parroquia de la Massana',119,''),(2041,'Parroquia de Canillo',119,''),(2042,'Parroquia Ordino',119,''),(2043,'Parroquia Encamp',119,''),(2044,'Parroquia Escaldes Engordany',119,''),(2045,'Other',120,''),(2046,'Anguilla',120,''),(2047,'Other',121,''),(2048,'Other',122,''),(2049,'Saint Georges',123,''),(2050,'Saint Peter',123,''),(2051,'Saint Anthony',123,''),(2052,'Other',123,'');
/*!40000 ALTER TABLE `states_new` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sub_castes`
--

DROP TABLE IF EXISTS `sub_castes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_castes` (
  `sub_caste_id` int(20) NOT NULL AUTO_INCREMENT,
  `religion_id` int(30) NOT NULL DEFAULT '1',
  `caste_id` int(10) NOT NULL,
  `sub_caste_name` varchar(100) NOT NULL,
  `sub_caste_status` int(10) NOT NULL,
  PRIMARY KEY (`sub_caste_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COMMENT='Sub castes of members';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sub_castes`
--

LOCK TABLES `sub_castes` WRITE;
/*!40000 ALTER TABLE `sub_castes` DISABLE KEYS */;
INSERT INTO `sub_castes` VALUES (1,1,1,'24 Manai A',1),(2,1,1,'24 Manai B',1);
/*!40000 ALTER TABLE `sub_castes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `success_story`
--

DROP TABLE IF EXISTS `success_story`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `success_story` (
  `success_id` int(11) NOT NULL AUTO_INCREMENT,
  `matrimony_id` varchar(200) NOT NULL,
  `story` longtext NOT NULL,
  `date` datetime DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `source` varchar(750) NOT NULL,
  `success_status` int(11) NOT NULL,
  `success_approval` int(11) NOT NULL,
  PRIMARY KEY (`success_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `success_story`
--

LOCK TABLES `success_story` WRITE;
/*!40000 ALTER TABLE `success_story` DISABLE KEYS */;
INSERT INTO `success_story` VALUES (1,'29653','\"Pellithoranam gave me wider choices to choose my life partner\"','2019-07-31 00:00:00','Arjun','assets/uploads/success_story/1564382015_image(3).png','Pellithoranam',1,1);
/*!40000 ALTER TABLE `success_story` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `user_type` int(11) NOT NULL,
  `user_status` int(11) NOT NULL,
  `email_unique` varchar(250) NOT NULL,
  `email_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=latin1 COMMENT='User table includes credentials of members';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'admin@pt','3b606142551b13a23ae5c3578fd1658f626a02b44a85fdc552f077ff6bd8257a941fd964d054e792cd89f7b6b18de7e6cb6845b6678bc98b625aff2cf2208810muJrA8PLoV0Fd8twKm9N+PMczS4PIyJNBcHJEMQgVE0=','0000-00-00 00:00:00','0000-00-00 00:00:00',2,1,'',0),(52,'kbhavanishankar339@gmail.com','bafa4d08d21c1dee531afae42aeafb22ecf18a8a33d40e2a820fbbbb62c6b72765999af2a49fe107e1781a55f9426e215ebf2ca79570b41c495a678b444fd930pfHiYb2BKBrHBJtNGJ1zHET61PzLPpxPtT5nEq+eFQA=','2019-06-19 15:01:58','2019-06-19 15:01:58',1,1,'',0),(53,'ravivarma8293@gmail.com','82560dd44a55605f3f6eda4ff0be6dceee809ad8c3a43bfac1d8dcc0c2ed944cb09c946b008f3b79d194f008ed02456bde97bef77de7071f1afaf258a777277dEyeT0SqOHwdzQ5faE3xvqjYNAWpv2VJU3PLNAWjtfNY=','2019-06-19 15:16:44','2019-06-19 15:16:44',1,1,'',0),(54,'mounikanarayana8@gmail.com','e824b5a260a85bba6734493da014275028c27f2acae9ab70607437bff20e1c9fac467b094d5e14f6ea8943218285b4cdda0b718513a35ae8e6f6f455ad06c12473QMyTeNXmoG4A8dw7L4VxZv9O97PklFaCLd9Rbc+p0=','2019-06-19 15:20:39','2019-06-19 15:20:39',1,1,'',0),(55,'shankar@ooisolutions.com','d4dadb4865f56efc28c05e050f10d514eb5b34d4afd77a33ac11c9a3bb4d4c6e6403f824edcfd351eda831933f54050839919466a7b5bd90e07bd2e449e14780FHHmAR/7wrjKsrdiQSXtcNIwk9y2zl6bt9Kmw3M3dFc=','2019-06-19 17:23:08','2019-06-19 17:23:08',1,1,'',0),(56,'mypersonalmail12@gmail.com','e4dc5eb9ba0b50e72f5acecb5cb1ac0c548606668962be8a5200cf5bc697479d6a079b38e9940dc9f84fbeff9fed5aec632b8cdcb02bf0871f46cec415fc09f4Tgb5eUPmCmDBQnr4Sh1AUaugwU2FuxU1g9F+Nr3V3XY=','2019-06-19 18:20:18','2019-06-19 18:20:18',1,1,'',0),(57,'vattem.krishnna@gmail.com','52b451cf31f8650cac9f089efd3e6d8ffe957b31e181a8ee28c2c42d3ba1df98821659c61b2c01fd082ebc534cc10ea0d9bd4045dc1bde6b68d17cc1090f8720Lh/OZZlh6cXN707xhBoPyuOY93DH+TWRTzZgm8/E+OI=','2019-06-20 12:24:54','2019-06-20 12:24:54',1,1,'',0),(58,'susmitha567@gmail.com','2b2613a5955bfc316568090f69f96db3e746538d7f548c2a785e505a709ad16bf44e7c6e793b82c3d4a718da2e7dd82992da21426774d7daa050add8e87223535QqKdiOXgs66Thebx63R33Z3N4IOKKLbWB8jrLawGWI=','2019-06-20 17:50:01','2019-06-20 17:50:01',1,1,'',0),(59,'klynvk@gmail.com','c6bc6f9bc0793ba07c3a8b9d2a41a2ffb442280ec00a3a25ec779b2953bec6517909dacde1a74d8e7588146614d40f31ed1ce06ab7734ddd603bae147a5e27eaTBJkoTo9YZM8hCKCuZhMs1MKv4p2IyZHxWHGdzdnNZI=','2019-06-22 10:53:27','2019-06-22 10:53:27',1,1,'',0),(60,'raghavatangilla@gmail.com','2aa6770c424612620072f1da90f3dd0a478a6e2de8720ff81e0d355a1ff9742934bd365c109d9055687037606c0cb66462803e0562325f5db1a38f67ddbb89c5JGxB5C/lB1/zU47ntyUWxHEMBPJEI1L7oi3pTJGeZIw=','2019-06-22 12:34:42','2019-06-22 12:34:42',1,1,'',0),(61,'munipallerajesh@gmail.com','b924c829c222228b42af632502511af66e582fe6772706b629e0a3646f904f8c1e675d1a54f3b00be93c2251a7a3522b3865ee3506bf25e5a36da1e2f7381ac9/9dgw2xOpml9nZ1VAztCPuTmKoPCb7sPhOS0tEZe2Y8=','2019-06-26 11:15:10','2019-06-26 11:15:10',1,1,'',0),(62,'hellouday@live.com','6190423f6b4765cc73f9a9a6853ae3c390275c94f1e3ca2b960bb925c6cb77695a26ae896c48dec13471702d797513c738f8c413e73a19ef90962fe489e5013dzWEvZ00xREiqG2cP093526NHOYmTXs2hdrol2g1sXb4=','2019-06-27 10:44:35','2019-06-27 10:44:35',1,1,'',0),(63,'helouday@gmail.com','e8d92ad3f109c62f8b76f014dc48b72ad02af09fb86d4890f494b8cb0ae71bd08f5bebe6b47eded245098d217d7ab2982f96678ef68a910ce25d3162c1111ae2/QaWdpm1Bb3OHm+WS04rcztOKQRIpdsMbEqhHsOKvdA=','2019-06-28 11:38:16','2019-06-28 11:38:16',1,1,'',0),(64,'vattemswarajyalakshmi@gmail.com','11bd4bc0a88bcf56ea100967819aab25d61cdcc4654ceb204303f47229fe1510e0ae1bb9fa43c9e8d8afcdb7d04619994fd0198cac9b6ebeaff00ef84276cb75hECdXikmqWzw+Uglk8omwCi2J9R94UqwR8Wp70FRIYw=','2019-06-30 20:54:18','2019-06-30 20:54:18',1,1,'',0),(65,'shankar1@ooisolutions.com','96c02bee8ab30e33822fa1bcc3a3d2573377da005c64faa6f6ec205dfd779a36919f8d74cc8fc7338187482894462c5d9ba3b2fabb3296de19f241ef79e8dbc508jKwOGQtiK6uQLkoWc8tgHWs3p0pSlhtmMzS+Mu0po=','2019-07-01 12:46:28','2019-07-01 12:46:28',1,1,'',0),(66,'rajeshmvs@yahoo.com','316c8815f5ad91495b9a2392d921f81156bd3ee15133e5f6b71311c3fc2e29bb30852465c100a3959b66827f592c9432a8dbb24a86fdd1bbee280a3d5c4f75977g74GI8F0L5MXpb1ooJ67YkWSD66siaIDM+cv/JgS4E=','2019-07-10 19:46:29','2019-07-10 19:46:29',1,1,'',0),(67,'sudarsan_84vh@yahoo.co.in','257f67c5a8424d0b77b6c8d6a226158762cc426e68e46067f170fd5b6b4a60f4798390fff9aaadb9c63e764ef50bd0260357db98989eccea28da44ea8c7df50aC4nxDpCi6dx3ro17RMZrc3/AScboSYPvTOmajSx0umA=','2019-07-12 16:33:58','2019-08-23 14:52:04',1,1,'',0),(68,'krishnasai14209@gmail.com','64e5c58dddc478ce7df96adfee7ea2366395f1a8e60c9dd636ebe4f4d539ac68b215d1a01a7287066dad898ef49349b69f156900ae74b15e249ce89cf4c64904imaMKVReqC4BtE02j5+ub8gsnigE3ja8yOxXCZk2FM0=','2019-07-19 15:40:40','2019-07-19 15:40:40',1,1,'',0),(73,'tjthouhid@gmail.com','58f0ba0b3e300f41120aed92f3a254f0d3669a83a890976531ce3183ba481c12398197b88c3535e2d922a79d57e482d22685780b230c8da89190640d25045e5aI72vDxwpGHw6QLM9QrwmmhSDsXC4vYDb9WRgUnT4YLk=','2019-07-20 17:18:35','2019-07-20 17:18:35',1,1,'',0),(74,'dottodotooi@gmail.com','e0cba5d561f0c7f914e22eb0a9e57f57a04e68f1f5f151c367909dd0f49ede1c028a00fd75f3d5eaec7a8c5190b9fee0eb8ad3b439deddda16178d2bdb1b5159ZqnkIjd97KuSfgVLBVIH1SBLC615iMx/aFRzuNtkOZE=','2019-07-20 17:28:30','2019-07-20 17:28:30',1,1,'',0),(75,'rjhouse77@gmail.com','9e9fbf5e0ff1b048f0068f7a76a3be9011c58941ba0c67429de48b25bd0695ef9e22b769061d0243e5e8e9ba430c2aa523e5767c9a7dd32103b8733aadac4aa0OnoJnwtYssVd4/NYUr/7tbozK0YZ5DP1EB+0vhdN4Kg=','2019-07-22 10:38:58','2019-07-22 10:38:58',1,1,'',0),(76,'ooisolutionssg1@gmail.com','4e5964d42ef92cc030a200d2d70d3b4e7d4b9084aaec77b468aeae79a5fa764411bd94eeb7b944f7fc25bc00abc8ffa45954ca85cb6f6516abdaed65f2017088E8QRtyW3pAw/pxjL7D2RIFtsJ2G58mXR125Mx+oup8E=','2019-07-25 11:35:23','2019-07-25 11:35:23',1,1,'',0),(77,'devulapalli@gmail.com','2c116050475bdda991b510363f4b5522391a6ec5cfdec7e6ee2a4328440fe98f1c5c63868cea9709151fbd429d194d8e6f966267c3d755e57e9aa7a9d81101b2SlCQNksO3AwjqwFs3PSZYorXagWKwqbSo3WOzZR5rQQ=','2019-07-30 13:17:39','2019-07-30 13:17:39',1,1,'',0),(78,'raghavatangella14209@gmail.com','4cf7de5b4a8d695b57f0f66f7c07a8edd83845867c03dbb3cd9dbe3933bf633f52d43cf323d860e0a1436c76140889c5b9e11c946a93f5c9f40eed00ce91a7c2yW2zpHoKtzmlL+Djq47ynO8of9R33BxVEhtUNHuXrfg=','2019-08-07 11:45:29','2019-08-07 11:45:29',1,1,'',0),(79,'akkhhil12@gmail.com','ae3939d8e0e740b149621e2ddcca402dffde77c7ddb06f22a7a2254c4a8e98afca327963b4ac72d9f6091823050e7308601134eb66e6f8035f6cfcf2a319beb8ZyrCFxftn8S+VJ8YxohTW4FUhKKdumjNIECbpbgZ/P4=','2019-08-07 16:26:37','2019-08-07 16:26:37',1,1,'',0),(80,'saikrishna14209@gmail.com','28baf8245a075569e8e18dce58b32a8972872b9b8fe9682ce363296985e3b9d64e21907aef556301f085c2c4f99c87d41a89e5f1688d89f24d28d7bc6eed2eb1pcbeSWFOPvdUzma4fVqr3rGwBf9CfrcE+YR7zo4g4jU=','2019-08-07 16:30:29','2019-08-07 16:30:29',1,1,'',0),(81,'akkhhil.94@gmail.com','de1454acfcec292bd16a81bd0ad9c30a76d10ab4846c6aa1604619f05ab74d8d234b4a759974d8ce7eb8b07968031d175a725234d8251d7bde747117805a8f16BsM+/ITHiqXsJJN+KM/p+JeqTCYOSzBViBi6/CrNEks=','2019-08-07 16:36:17','2019-08-07 16:36:17',1,1,'',0),(82,'vrt0594@gmail.com','90249bc0554d1ff5697579354632bf413187a167f8cadfc982a71e6d93e760b679e733537f2cf03de701edd41d60c0115ef3ecfe97eab315a3af704342284497BvhwuNto9HDVixjsvSw3RUacNaRidDTHoFU5Xdc6MVo=','2019-08-10 12:30:52','2019-08-10 12:30:52',1,1,'',0),(84,'dvskhome@gmail.com','1288387c6c149a6c9dff60e35b7b065954c222699417eda43b28f37b12c3db467c8c8635a15e651b453d2c6082cbf40ce6e6fb7488d176c164656c9c31177e03I/BUiKcHUWtEMgqN4TaWmuMvS5iQ9zuVcfcI/K3Isnk=','2019-08-13 13:51:56','2019-08-13 13:51:56',1,1,'',0),(85,'srikanth.bharadwaj@gmail.com','7e098a048f041b9d7ed70caa6c10e2be3d0f02d12615cc673cddc53b33b0b77dbe23d7fabfb782db680a89b6c3f91f27bd79d41ef6d67fd31c5239549813cbd3tPgZoT76Xa40w/+d+AgDqElItFweUleNSC8ri1rcmfE=','2019-08-14 17:30:23','2019-08-14 17:30:23',1,1,'',0),(86,'kvattem@spglobal.com','33d5ba4281c61fcf9d7604dc5a775c4072ccc7cca8a44c6023fb02dafd6e9bcd6050ddc073e1a79060dc06e0aa7d5c66fd29a19c9da8ef9bf7cef058a1e68a324XN7nR2A6lmaSmlgCnmHHCoxY/uXXWIpwLdyaOEIbow=','2019-08-15 11:48:01','2019-08-15 11:48:01',1,1,'',0),(87,'srinu786@gmail.com','9be3a6daf1bf37d2e605e513c31502763134d24e3bb433487f8f69272439dd1b83333935758fd6a72f59c592acd92892c4e4405e9bee21489028ba0e55681ff1qq1gGDK4LpmcbfHynO5qjAnWrBHio2O6MLwF5FsCCJ0=','2019-08-15 12:51:03','2019-08-15 12:51:03',1,1,'',0),(88,'sreenivaas19@gmail.com','31bb02a6fb856d85388e6fad832f78325674aa2a1b662b54c3133b58c2ce25a19f99ad42dc203bd1f16fead9f2f011d707826a19e71d32223ea95c3da07158d4SyFQbolKpDlusi52ffwSgq+mHiTK73W4nwPkadbQwm0=','2019-08-15 21:40:04','2019-08-15 21:40:04',1,1,'',0),(89,'mathru.k@adityacc.com','b3d1182b46b870d16c7d6637d98673ffb40e024fab80595c071707c71df1aa2d95b0c3a70a97ff3994cd460dd08df60b15dede49bd800909afdec6bd22b7cc5exmeOU3rvZMOf7xZ5oB1WYlY5I3nogCblr1j7MCPgCJ4=','2019-08-21 12:20:08','2019-08-21 12:20:08',1,1,'',0),(92,'krrcan@gmail.com','444035bfb9ba23c1b907994cf93c4c265c48df383d497fc04c1daf0d1386d5f9b9043bb88d25720bf94b31dd2b516d0fbd0ed5f8fb2f4cf81a189d4b8ab0d92fNu03pp1r5RF0NZ3k7ISNX8zsIbCatNqZWIlvrdUv2gE=','2019-08-28 09:47:43','2019-08-28 09:47:43',1,1,'',0),(97,'venkatsk.wi@gmail.com','46e316363ca4fc536d379facba327d1c6f7f591e86f88921231c0f48ed7cb8562325c2ff219117e4d37f339e66683b5525da3c9fff242da5b0dc6cc522510bdeD5CuRRbM4QR1p9w8gRy8lJM3UKIM/r9nj2lCwM7QKKE=','2019-08-29 11:46:40','2019-08-29 11:46:40',1,1,'',0),(98,'pipejiwin@simplemail.top','6f3b1b7f5e69dbae67d4a04bd033fe49e19e5b5a4e221952b57c1a66794744c183eafe5f90b5eb605d0e1d7889dd4e985a4ce08b4026bf78fff4e396a2f0d21b/AARSsnfdfgDbL0T1lC9jom+pE6pDxBkT2/QLARfvy8=','2019-08-29 11:54:34','2019-08-29 11:54:34',1,1,'',0),(99,'wamujonelo@rmailgroup.in','6ea0c10c1121e30c118d0e3e1efd045b312fcb12551df59af4b8804a69e8c717a7f40ed4de3e275d020bf450118e8210efdd6e8d6b67b1a1c0c708b840924110umgRqfAwh4FZMKMZy5JB3pO1dbZPAxqoL14+avUJMI8=','2019-08-29 16:28:59','2019-08-29 16:28:59',1,1,'',0),(100,'gokorow@simplemail.top','57aa80b217f24dccdd72ef5ec3f1108fad755a821b7c780dc2b58e3c64db27f8a08dbd4f100008b5a66f949c76bd9c05969d1649aac226347afaf8831fd1884eXvNnAmrExIQoNpmfXXnaxms0/MRyQeFFjt0UPOyQhes=','2019-08-30 11:19:53','2019-08-30 11:19:53',1,1,'',0),(103,'kvs116.wi@gmail.com','a6b8a9ec3e137044bbfc2f79f589541bd263698c08173034c3112776d494a621cc95e32553c8cb2009788c2797a2a3feeec940a56e2ae231e48a7d6dae890377y/rlWsUl+VcT61JchZQSXJB0mE4JUm9HOUuzn3cX9c0=','2019-09-05 14:23:02','2019-09-05 14:23:02',1,1,'',0),(104,'susmitha567@gmail.com','5e343724191623192055de158f770fe25a09ca94e4fd6b4b0a3a69abbf762e31cd9cae109d25d943efd29a2ef4514166cee3dc49e8e03143b84a4b88a0bb6c43PjweFAzjd/jx0b+bjBtLte+qAAJTi/sBjmat53Lnleo=','2019-09-06 16:56:37','2019-09-06 16:56:37',1,1,'',0),(105,'rjyhouse77@gmail.com','37740df81587b8a4c14e2f947d2987917c7aea5b545bdb5f2ec41cea28d7571a8320cc980c18791b4cf7961d2756c545b5280a52320f3a70c7f8af1b499c0f51FqAGpmGXqVVtgNAVfPK/BKHEWWcuuPFoPhfzmpZSS/U=','2019-09-08 13:02:28','2019-09-08 13:02:28',1,1,'',0),(106,'neelimaroyal369@gmail.com','07431ac53a0acbb08d4a6841fb549635e1e4b99146ae72ab0c75502a5e02c65982e9a9d72793c22829e1c7bf03f57fa260b519703023ec272e944fe2fae7a70fuF/hxWfm86L2Ifn1mYt4O/jG8kgEF+FF3gih2N1eZeE=','2019-09-09 11:20:39','2019-09-09 11:20:39',1,1,'',0),(107,'atchutunisahi@gmail.com','db0c390fe52364b1f287c19f78dd3c7d4033f0c1440efa257bcbe6edae538d3931779ad49ea2a61e0712b141138d3de133379b2ea5647348315146b89cc6974bLWR/ZDtX0xm7JP4yNZX+o2uIt1h+FB0Jd+5elUYhIdk=','2019-09-14 14:19:21','2019-09-14 14:19:21',1,1,'',0),(108,'arimillikalyan@gmail.com','aa4e58dbd0ec95d39f89a1ad524c3e3eb196e64b4b8129a05bc463b4d5a5178dec742a2e7277af812aa86d12c7a42a82f73703f2fba368a6d2e965279803902842+21sbXFtLcMDO0PmHt0yJ/kjCcIVSXgYx94QXgz+A=','2019-09-22 12:37:02','2019-09-22 12:37:02',1,1,'',0),(109,'sandhyagayathrib@gmail.com','c1dcef614097c5156e5e877139e507c896bb7b1184459ef1c68400638e520e02757a8723629adb92f1938a8ac2395e1ec453d907a1ae4ea5fc8b4898bb835642906gjA2F9Zv8TCiFHcy8rAMwZREOJPkBG/eJbtZ8N3Q=','2019-09-22 20:49:16','2019-09-22 20:49:16',1,1,'',0),(114,'bilodi4531@3dmail.top','2c955fda31f9b4f2b8fb6990226d5bb9c41e9775519cc607f04f7d6a64443c532b3f2053932077b8b178fdadc3ff454b6152b16527a20559b25f255c26c26cc9DwjAA/PQr8yqYtkf24GcCoWk7RGzhXFLef4wnei1me8=','2019-11-07 18:27:04','2019-11-07 18:27:04',1,1,'',0),(115,'test@dmailpro.net','8532a06c9b01964368898aa38a006a4191faadd211259e4b2cef4147a90baddf352ed38f064e50e6f099722bd836ba2f5aa062848831c2bb99d9b4198b2ec063D0VTIaCr0joZwfq319tI631okT4l4Aw/9aJIWLVd/2w=','2019-11-07 18:41:05','2019-11-07 18:41:05',1,1,'',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weight`
--

DROP TABLE IF EXISTS `weight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weight` (
  `weight_id` int(10) NOT NULL AUTO_INCREMENT,
  `weight` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`weight_id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1 COMMENT='Weight Details';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weight`
--

LOCK TABLES `weight` WRITE;
/*!40000 ALTER TABLE `weight` DISABLE KEYS */;
INSERT INTO `weight` VALUES (1,'41 kg'),(2,'42 kg'),(3,'43 kg'),(4,'44 kg'),(5,'45 kg'),(6,'46 kg'),(7,'47 kg'),(8,'48 kg'),(9,'49 kg'),(10,'50 kg'),(11,'51 kg'),(12,'52 kg'),(13,'53 kg'),(14,'54 kg'),(15,'55 kg'),(16,'56 kg'),(17,'57 kg'),(18,'58 kg'),(19,'59 kg'),(20,'60 kg'),(21,'61 kg'),(22,'62 kg'),(23,'63 kg'),(24,'64 kg'),(25,'65 kg'),(26,'66 kg'),(27,'67 kg'),(28,'68 kg'),(29,'69 kg'),(30,'70 kg'),(31,'71 kg'),(32,'72 kg'),(33,'73 kg'),(34,'74 kg'),(35,'75 kg'),(36,'76 kg'),(37,'77 kg'),(38,'\r\n78 kg'),(39,'79 kg'),(40,'80 kg'),(41,'81 kg'),(42,'82 kg'),(43,'83 kg'),(44,'84 kg'),(45,'85 kg'),(46,'86 kg'),(47,'87 kg'),(48,'88 kg'),(49,'89 kg'),(50,'90 kg'),(51,'91 kg'),(52,'92 kg'),(53,'93 kg'),(54,'94 kg'),(55,'95 kg'),(56,'96 kg'),(57,'97 kg'),(58,'98 kg'),(59,'99 kg'),(60,'100 kg'),(61,'101 kg'),(62,'102 kg'),(63,'103 kg'),(64,'104 kg'),(65,'105 kg'),(66,'106 kg'),(67,'107 kg'),(68,'108 kg'),(69,'109 kg'),(70,'110 kg'),(71,'111 kg'),(72,'112 kg'),(73,'113 kg'),(74,'114 kg'),(75,'115 kg'),(76,'116 kg'),(77,'117 kg'),(78,'118 kg'),(79,'119 kg'),(80,'120 kg'),(81,'121 kg'),(82,'122 kg'),(83,'123 kg'),(84,'124 kg'),(85,'125 kg'),(86,'126 kg'),(87,'127 kg'),(88,'128 kg'),(89,'129 kg'),(90,'130 kg'),(91,'131 kg'),(92,'132 kg'),(93,'133 kg'),(94,'134 kg'),(95,'135 kg'),(96,'136 kg'),(97,'137 kg'),(98,'138 kg'),(99,'139 kg'),(100,'140 kg');
/*!40000 ALTER TABLE `weight` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-07 15:04:02
