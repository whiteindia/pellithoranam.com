<div class="email-temp-wrapper" style="width:800px;margin:0 auto;border:1px solid #c02c48;border-radius:5px;    padding: 10px;">
						<div class="email-temp-logo-div">
							<img src="<?php echo $logo; ?>" style="width:120px;">
							<!--	<img src="http://techlabz/public_html/solmatenew/solmate/admin/assets/uploads/logo/soul_logo.png" style="width:120px;">-->
						</div>
						<div class="email-temp-content" style="border:1px solid #c02c48;border-radius:3px;border-top-left-radius:20px;border-top-right-radius:5px;
							border-bottom-left-radius:5px;border-bottom-right-radius:20px;font-family: "Roboto", sans-serif;padding: 25px;">
							<strong style="font-style:italic;"></strong><br>
							<p style="color: #4d4d4d;"> </p>
							<p style="color: #4d4d4d;"></p>
							<br>
							<div><?php echo $news_letter; ?></div>
							<div style="clear:both;"></div>
						</div>
			        </div>