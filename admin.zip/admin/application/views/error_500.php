<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            You can't access
          </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">

          <div class="error-page" style="width:650px">
            <h2 class="headline text-red" style="margin-top:-10px; width:300px">Error!</h2>
            <div class="error-content">
              <h3><i class="fa fa-warning text-red"></i> Oops! Something went wrong.</h3>
              <p>
                You don't have permission to access this page <br>
                Please contact our administrator.
                
              </p>
              
            </div>
          </div><!-- /.error-page -->

        </section><!-- /.content -->
      </div>