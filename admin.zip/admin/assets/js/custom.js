
 
            // When the document is ready
            $(document).ready(function () {
                
                $('#start_date').datepicker({
                    format: "yyyy-mm-dd"
                });  
            
            });
			
			 $(document).ready(function () {
                
                $('#end_date').datepicker({
                    format: "yyyy-mm-dd"
                });  
            
            });
     

	
